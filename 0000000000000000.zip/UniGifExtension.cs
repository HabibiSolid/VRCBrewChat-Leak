﻿using Il2CppSystem;
using System;
using System.Collections;
using UnityEngine;

#nullable enable
public static class UniGifExtension
{
  public static int GetNumeral(this BitArray array, int startIndex, int bitLength)
  {
    BitArray array1 = new BitArray(bitLength);
    for (int index = 0; index < bitLength; ++index)
    {
      if (array.Length <= startIndex + index)
      {
        array1[index] = false;
      }
      else
      {
        bool flag = array.Get(startIndex + index);
        array1[index] = flag;
      }
    }
    return array1.ToNumeral();
  }

  public static int ToNumeral(this BitArray array)
  {
    if (array == null)
    {
      Debug.LogError(Object.op_Implicit("array is nothing."));
      return 0;
    }
    if (array.Length > 32 /*0x20*/)
    {
      Debug.LogError(Object.op_Implicit("must be at most 32 bits long."));
      return 0;
    }
    int[] numArray = new int[1];
    array.CopyTo((Array) numArray, 0);
    return numArray[0];
  }
}
