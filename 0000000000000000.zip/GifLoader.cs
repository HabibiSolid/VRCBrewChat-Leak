
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using UnityEngine;
using UnityEngine.UI;
using UNIXEngine.IL2CPPModding.Utils.Collections;

#nullable enable
public class GifLoader : MonoBehaviour
{
  private List<GifLoader.AnimatedGifData> gifs = new List<GifLoader.AnimatedGifData>();
  private static GifLoader? _instance;

  public static GifLoader Instance
  {
    get
    {
      if (Object.op_Equality((Object) GifLoader._instance, (Object) null))
        GifLoader._instance = Object.FindObjectOfType<GifLoader>();
      return GifLoader._instance;
    }
  }

  private void Awake()
  {
    if (Object.op_Inequality((Object) GifLoader._instance, (Object) null) && Object.op_Inequality((Object) GifLoader._instance, (Object) this))
    {
      Object.Destroy((Object) ((Component) this).gameObject);
    }
    else
    {
      GifLoader._instance = this;
      Object.DontDestroyOnLoad((Object) ((Component) this).gameObject);
    }
  }

  public void AddAnimatedGif(Image image, Uri? url)
  {
    this.StartCoroutine(CollectionExtensions.WrapToIl2Cpp(this.LoadGifCoroutine(image, url)));
  }

  private IEnumerator LoadGifCoroutine(Image image, Uri? url)
  {
    List<Sprite> frames = new List<Sprite>();
    List<float> delays = new List<float>();
    if (url == (Uri) null)
      throw new ArgumentNullException(nameof (url));
    byte[] bytes;
    if (url.IsFile)
    {
      bytes = File.ReadAllBytes(url.LocalPath);
    }
    else
    {
      if (!(url.Scheme == Uri.UriSchemeHttp) && !(url.Scheme == Uri.UriSchemeHttps))
        throw new NotSupportedException("Unsupported URI scheme: " + url.Scheme);
      using (HttpClient httpClient = new HttpClient())
        bytes = httpClient.GetByteArrayAsync(url.ToString()).GetAwaiter().GetResult();
    }
    yield return (object) UniGif.GetTextureListCoroutine(bytes, (Action<List<UniGif.GifTexture>, int, int, int>) ((gifTexList, loopCount, width, height) =>
    {
      foreach (UniGif.GifTexture gifTex in gifTexList)
      {
        Texture2D texture2d = gifTex.m_texture2d;
        Object.DontDestroyOnLoad((Object) texture2d);
        Sprite sprite = Sprite.Create(texture2d, new Rect(0.0f, 0.0f, (float) ((Texture) gifTex.m_texture2d).width, (float) ((Texture) gifTex.m_texture2d).height), new Vector2(0.5f, 0.5f));
        Object.DontDestroyOnLoad((Object) sprite);
        ((Object) texture2d).hideFlags = (HideFlags) 32 /*0x20*/;
        ((Object) sprite).hideFlags = (HideFlags) 32 /*0x20*/;
        frames.Add(sprite);
        delays.Add(gifTex.m_delaySec);
      }
      this.gifs.Add(new GifLoader.AnimatedGifData(image, frames, delays));
    }));
  }

  private void FixedUpdate()
  {
    foreach (GifLoader.AnimatedGifData gif in this.gifs)
    {
      if (gif.frames.Count != 0)
      {
        gif.timer += Time.deltaTime;
        if ((double) gif.timer >= (double) gif.delays[gif.currentFrame])
        {
          gif.timer = 0.0f;
          gif.currentFrame = (gif.currentFrame + 1) % gif.frames.Count;
        }
        gif.image.sprite = gif.frames[gif.currentFrame];
      }
    }
  }

  private void OnDestroy()
  {
    foreach (GifLoader.AnimatedGifData gif in this.gifs)
    {
      foreach (Sprite frame in gif.frames)
      {
        Object.DestroyImmediate((Object) frame.texture);
        Object.Destroy((Object) frame);
      }
    }
  }

  public static Image CreateIsolatedImage(Image reference)
  {
    GameObject gameObject = Object.Instantiate<GameObject>(((Component) reference).gameObject, ((Component) reference).transform.parent);
    ((Object) gameObject).name = ((Object) ((Component) reference).gameObject).name + "_ModClone";
    gameObject.transform.SetAsFirstSibling();
    Image component = gameObject.GetComponent<Image>();
    ((Graphic) component).color = Color.white;
    return component;
  }

  public class AnimatedGifData
  {
    public Image image;
    public List<Sprite> frames;
    public List<float> delays;
    public int currentFrame;
    public float timer;

    public AnimatedGifData(Image image, List<Sprite> frames, List<float> delays)
    {
      this.image = image;
      this.frames = frames;
      this.delays = delays;
      this.currentFrame = 0;
      this.timer = 0.0f;
    }
  }
}
