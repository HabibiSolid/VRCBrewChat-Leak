
using Il2CppSystem;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

#nullable enable
public class AnimationManager : MonoBehaviour
{
  private static Dictionary<string, AnimationManager.GifData> loadedGifs = new Dictionary<string, AnimationManager.GifData>();
  private Dictionary<Image, AnimationManager.AnimationState> activeAnimations = new Dictionary<Image, AnimationManager.AnimationState>();

  private void LateUpdate()
  {
    List<Image> imageList = new List<Image>();
    foreach (KeyValuePair<Image, AnimationManager.AnimationState> activeAnimation in this.activeAnimations)
    {
      Image key = activeAnimation.Key;
      AnimationManager.AnimationState animationState = activeAnimation.Value;
      if (Object.op_Equality((Object) key, (Object) null))
        imageList.Add(key);
      else if (((Component) key).gameObject.activeInHierarchy)
      {
        animationState.timer += Time.deltaTime;
        if ((double) animationState.timer >= (double) animationState.currentDelay)
        {
          animationState.currentFrame = (animationState.currentFrame + 1) % animationState.gifData.sprites.Count;
          key.sprite = animationState.gifData.sprites[animationState.currentFrame];
          animationState.currentDelay = animationState.gifData.delays[animationState.currentFrame];
          animationState.timer = 0.0f;
        }
      }
    }
    foreach (Image key in imageList)
      this.activeAnimations.Remove(key);
  }

  public void PlayAnimation(Image image, string gifPath)
  {
    if (Object.op_Equality((Object) image, (Object) null) || string.IsNullOrEmpty(gifPath))
    {
      Debug.LogError(Object.op_Implicit("Invalid image or gif path"));
    }
    else
    {
      if (this.activeAnimations.ContainsKey(image))
        this.activeAnimations.Remove(image);
      if (!AnimationManager.loadedGifs.ContainsKey(gifPath))
        this.LoadGifSync(gifPath);
      if (AnimationManager.loadedGifs.ContainsKey(gifPath))
      {
        AnimationManager.GifData loadedGif = AnimationManager.loadedGifs[gifPath];
        AnimationManager.AnimationState animationState = new AnimationManager.AnimationState()
        {
          gifData = loadedGif,
          currentFrame = 0,
          currentDelay = loadedGif.delays[0],
          timer = 0.0f
        };
        this.activeAnimations[image] = animationState;
        image.sprite = loadedGif.sprites[0];
        Debug.Log(Object.op_Implicit($"Started animation with {loadedGif.sprites.Count} frames"));
      }
      else
        Debug.LogError(Object.op_Implicit("Failed to load GIF: " + gifPath));
    }
  }

  private void LoadGifSync(string gifPath)
  {
    try
    {
      if (gifPath.StartsWith("http"))
        Debug.LogError(Object.op_Implicit("HTTP URLs not supported in sync loading. Use local files only."));
      else if (!File.Exists(gifPath))
      {
        Debug.LogError(Object.op_Implicit("GIF file not found: " + gifPath));
      }
      else
      {
        Debug.Log(Object.op_Implicit($"Loaded {File.ReadAllBytes(gifPath).Length} bytes from {gifPath}"));
        List<UniGif.GifTexture> gifTextureList = (List<UniGif.GifTexture>) null;
        UnityGIF.GetCurrentFrame();
        if (gifTextureList == null || gifTextureList.Count == 0)
        {
          Debug.LogError(Object.op_Implicit("No frames decoded from GIF"));
        }
        else
        {
          Debug.Log(Object.op_Implicit($"Decoded {gifTextureList.Count} frames from GIF"));
          List<Sprite> spriteList = new List<Sprite>();
          List<float> floatList = new List<float>();
          foreach (UniGif.GifTexture gifTexture in gifTextureList)
          {
            if (Object.op_Inequality((Object) gifTexture.m_texture2d, (Object) null))
            {
              Sprite sprite = Sprite.Create(gifTexture.m_texture2d, new Rect(0.0f, 0.0f, (float) ((Texture) gifTexture.m_texture2d).width, (float) ((Texture) gifTexture.m_texture2d).height), new Vector2(0.5f, 0.5f));
              spriteList.Add(sprite);
              floatList.Add((double) gifTexture.m_delaySec > 0.0 ? gifTexture.m_delaySec : 0.1f);
            }
          }
          AnimationManager.loadedGifs[gifPath] = new AnimationManager.GifData()
          {
            sprites = spriteList,
            delays = floatList
          };
          Debug.Log(Object.op_Implicit($"Successfully cached GIF with {spriteList.Count} sprites"));
        }
      }
    }
    catch (Exception ex)
    {
      Debug.LogError(Object.op_Implicit($"Error loading GIF: {ex.Message}\n{ex.StackTrace}"));
    }
  }

  public void StopAnimation(Image image)
  {
    if (!this.activeAnimations.ContainsKey(image))
      return;
    this.activeAnimations.Remove(image);
  }

  public bool IsAnimating(Image image) => this.activeAnimations.ContainsKey(image);

  private void OnDestroy() => this.activeAnimations.Clear();

  private class GifData
  {
    public List<Sprite> sprites;
    public List<float> delays;
  }

  private class AnimationState
  {
    public AnimationManager.GifData gifData;
    public int currentFrame;
    public float currentDelay;
    public float timer;
  }
}
