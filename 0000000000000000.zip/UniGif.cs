﻿using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Il2CppSystem;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

#nullable enable
public static class UniGif
{
  public static IEnumerator GetTextureListCoroutine(
    byte[] bytes,
    Action<List<UniGif.GifTexture>, int, int, int> callback,
    FilterMode filterMode = 1,
    TextureWrapMode wrapMode = 1,
    bool debugLog = false)
  {
    int loopCount = -1;
    int width = 0;
    int height = 0;
    UniGif.GifData gifData = new UniGif.GifData();
    if (!UniGif.SetGifData(bytes, ref gifData, debugLog))
    {
      Debug.LogError(Object.op_Implicit("GIF file data set error."));
      if (callback != null)
        callback((List<UniGif.GifTexture>) null, loopCount, width, height);
    }
    else
    {
      List<UniGif.GifTexture> gifTexList = (List<UniGif.GifTexture>) null;
      yield return (object) UniGif.DecodeTextureCoroutine(gifData, (Action<List<UniGif.GifTexture>>) (result => gifTexList = result), filterMode, wrapMode);
      if (gifTexList == null || gifTexList.Count <= 0)
      {
        Debug.LogError(Object.op_Implicit("GIF texture decode error."));
        if (callback != null)
          callback((List<UniGif.GifTexture>) null, loopCount, width, height);
      }
      else
      {
        loopCount = gifData.m_appEx.loopCount;
        width = (int) gifData.m_logicalScreenWidth;
        height = (int) gifData.m_logicalScreenHeight;
        if (callback != null)
          callback(gifTexList, loopCount, width, height);
      }
    }
  }

  private static IEnumerator DecodeTextureCoroutine(
    UniGif.GifData gifData,
    Action<List<UniGif.GifTexture>> callback,
    FilterMode filterMode,
    TextureWrapMode wrapMode)
  {
    if (gifData.m_imageBlockList != null && gifData.m_imageBlockList.Count >= 1)
    {
      List<UniGif.GifTexture> gifTexList = new List<UniGif.GifTexture>(gifData.m_imageBlockList.Count);
      List<ushort> disposalMethodList = new List<ushort>(gifData.m_imageBlockList.Count);
      int imgIndex = 0;
      for (int i = 0; i < gifData.m_imageBlockList.Count; ++i)
      {
        byte[] decodedData = UniGif.GetDecodedData(gifData.m_imageBlockList[i]);
        UniGif.GraphicControlExtension? graphicCtrlEx = UniGif.GetGraphicCtrlExt(gifData, imgIndex);
        int transparentIndex = UniGif.GetTransparentIndex(graphicCtrlEx);
        disposalMethodList.Add(UniGif.GetDisposalMethod(graphicCtrlEx));
        Color32 bgColor;
        List<byte[]> colorTable = UniGif.GetColorTableAndSetBgColor(gifData, gifData.m_imageBlockList[i], transparentIndex, out bgColor);
        yield return (object) 0;
        bool filledTexture;
        Texture2D tex = UniGif.CreateTexture2D(gifData, gifTexList, imgIndex, disposalMethodList, bgColor, filterMode, wrapMode, out filledTexture);
        yield return (object) 0;
        int dataIndex = 0;
        for (int y = ((Texture) tex).height - 1; y >= 0; --y)
          UniGif.SetTexturePixelRow(tex, y, gifData.m_imageBlockList[i], decodedData, ref dataIndex, colorTable, bgColor, transparentIndex, filledTexture);
        tex.Apply();
        yield return (object) 0;
        gifTexList.Add(new UniGif.GifTexture(tex, UniGif.GetDelaySec(graphicCtrlEx)));
        ++imgIndex;
        decodedData = (byte[]) null;
        colorTable = (List<byte[]>) null;
        tex = (Texture2D) null;
      }
      if (callback != null)
        callback(gifTexList);
    }
  }

  private static byte[] GetDecodedData(UniGif.ImageBlock imgBlock)
  {
    List<byte> compData = new List<byte>();
    for (int index1 = 0; index1 < imgBlock.m_imageDataList.Count; ++index1)
    {
      for (int index2 = 0; index2 < imgBlock.m_imageDataList[index1].m_imageData.Length; ++index2)
        compData.Add(imgBlock.m_imageDataList[index1].m_imageData[index2]);
    }
    int needDataSize = (int) imgBlock.m_imageHeight * (int) imgBlock.m_imageWidth;
    byte[] decodedData = UniGif.DecodeGifLZW(compData, (int) imgBlock.m_lzwMinimumCodeSize, needDataSize);
    if (imgBlock.m_interlaceFlag)
      decodedData = UniGif.SortInterlaceGifData(decodedData, (int) imgBlock.m_imageWidth);
    return decodedData;
  }

  private static List<byte[]> GetColorTableAndSetBgColor(
    UniGif.GifData gifData,
    UniGif.ImageBlock imgBlock,
    int transparentIndex,
    out Color32 bgColor)
  {
    List<byte[]> tableAndSetBgColor = imgBlock.m_localColorTableFlag ? imgBlock.m_localColorTable : (gifData.m_globalColorTableFlag ? gifData.m_globalColorTable : (List<byte[]>) null);
    if (tableAndSetBgColor != null)
    {
      byte[] numArray = tableAndSetBgColor[(int) gifData.m_bgColorIndex];
      bgColor = new Color32(numArray[0], numArray[1], numArray[2], transparentIndex == (int) gifData.m_bgColorIndex ? (byte) 0 : byte.MaxValue);
    }
    else
      bgColor = Color32.op_Implicit(Color.black);
    return tableAndSetBgColor;
  }

  private static UniGif.GraphicControlExtension? GetGraphicCtrlExt(
    UniGif.GifData gifData,
    int imgBlockIndex)
  {
    return gifData.m_graphicCtrlExList != null && gifData.m_graphicCtrlExList.Count > imgBlockIndex ? new UniGif.GraphicControlExtension?(gifData.m_graphicCtrlExList[imgBlockIndex]) : new UniGif.GraphicControlExtension?();
  }

  private static int GetTransparentIndex(UniGif.GraphicControlExtension? graphicCtrlEx)
  {
    int transparentIndex = -1;
    if (graphicCtrlEx.HasValue && graphicCtrlEx.Value.m_transparentColorFlag)
      transparentIndex = (int) graphicCtrlEx.Value.m_transparentColorIndex;
    return transparentIndex;
  }

  private static float GetDelaySec(UniGif.GraphicControlExtension? graphicCtrlEx)
  {
    float delaySec = graphicCtrlEx.HasValue ? (float) graphicCtrlEx.Value.m_delayTime / 100f : 0.0166666675f;
    if ((double) delaySec <= 0.0)
      delaySec = 0.1f;
    return delaySec;
  }

  private static ushort GetDisposalMethod(UniGif.GraphicControlExtension? graphicCtrlEx)
  {
    return !graphicCtrlEx.HasValue ? (ushort) 2 : graphicCtrlEx.Value.m_disposalMethod;
  }

  private static Texture2D CreateTexture2D(
    UniGif.GifData gifData,
    List<UniGif.GifTexture> gifTexList,
    int imgIndex,
    List<ushort> disposalMethodList,
    Color32 bgColor,
    FilterMode filterMode,
    TextureWrapMode wrapMode,
    out bool filledTexture)
  {
    filledTexture = false;
    Texture2D texture2D = new Texture2D((int) gifData.m_logicalScreenWidth, (int) gifData.m_logicalScreenHeight, (TextureFormat) 5, false);
    ((Texture) texture2D).filterMode = filterMode;
    ((Texture) texture2D).wrapMode = wrapMode;
    ushort num = imgIndex > 0 ? disposalMethodList[imgIndex - 1] : (ushort) 2;
    int index1 = -1;
    switch (num)
    {
      case 1:
        index1 = imgIndex - 1;
        break;
      case 2:
        filledTexture = true;
        Color32[] color32Array1 = new Color32[((Texture) texture2D).width * ((Texture) texture2D).height];
        for (int index2 = 0; index2 < color32Array1.Length; ++index2)
          color32Array1[index2] = bgColor;
        texture2D.SetPixels32(Il2CppStructArray<Color32>.op_Implicit(color32Array1));
        texture2D.Apply();
        break;
      case 3:
        for (int index3 = imgIndex - 1; index3 >= 0; --index3)
        {
          if (disposalMethodList[index3] == (ushort) 0 || disposalMethodList[index3] == (ushort) 1)
          {
            index1 = index3;
            break;
          }
        }
        break;
    }
    if (index1 >= 0)
    {
      filledTexture = true;
      Color32[] color32Array2 = Il2CppArrayBase<Color32>.op_Implicit((Il2CppArrayBase<Color32>) gifTexList[index1].m_texture2d.GetPixels32());
      texture2D.SetPixels32(Il2CppStructArray<Color32>.op_Implicit(color32Array2));
      texture2D.Apply();
    }
    return texture2D;
  }

  private static void SetTexturePixelRow(
    Texture2D tex,
    int y,
    UniGif.ImageBlock imgBlock,
    byte[] decodedData,
    ref int dataIndex,
    List<byte[]> colorTable,
    Color32 bgColor,
    int transparentIndex,
    bool filledTexture)
  {
    int num1 = ((Texture) tex).height - 1 - y;
    for (int index1 = 0; index1 < ((Texture) tex).width; ++index1)
    {
      int num2 = index1;
      if (num1 < (int) imgBlock.m_imageTopPosition || num1 >= (int) imgBlock.m_imageTopPosition + (int) imgBlock.m_imageHeight || num2 < (int) imgBlock.m_imageLeftPosition || num2 >= (int) imgBlock.m_imageLeftPosition + (int) imgBlock.m_imageWidth)
      {
        if (!filledTexture)
          tex.SetPixel(index1, y, Color32.op_Implicit(bgColor));
      }
      else if (dataIndex >= decodedData.Length)
      {
        if (!filledTexture)
        {
          tex.SetPixel(index1, y, Color32.op_Implicit(bgColor));
          if (dataIndex == decodedData.Length)
            Debug.LogError(Object.op_Implicit($"dataIndex exceeded the size of decodedData. dataIndex:{dataIndex.ToString()} decodedData.Length:{decodedData.Length.ToString()} y:{y.ToString()} x:{index1.ToString()}"));
        }
        ++dataIndex;
      }
      else
      {
        byte index2 = decodedData[dataIndex];
        if (colorTable == null || colorTable.Count <= (int) index2)
        {
          if (!filledTexture)
          {
            tex.SetPixel(index1, y, Color32.op_Implicit(bgColor));
            if (colorTable == null)
              Debug.LogError(Object.op_Implicit("colorIndex exceeded the size of colorTable. colorTable is null. colorIndex:" + index2.ToString()));
            else
              Debug.LogError(Object.op_Implicit($"colorIndex exceeded the size of colorTable. colorTable.Count:{colorTable.Count.ToString()} colorIndex:{index2.ToString()}"));
          }
          ++dataIndex;
        }
        else
        {
          byte[] numArray = colorTable[(int) index2];
          byte maxValue = transparentIndex < 0 || transparentIndex != (int) index2 ? byte.MaxValue : (byte) 0;
          if (!filledTexture || maxValue != (byte) 0)
          {
            Color32 color32;
            // ISSUE: explicit constructor call
            ((Color32) ref color32).\u002Ector(numArray[0], numArray[1], numArray[2], maxValue);
            tex.SetPixel(index1, y, Color32.op_Implicit(color32));
          }
          ++dataIndex;
        }
      }
    }
  }

  private static byte[] DecodeGifLZW(List<byte> compData, int lzwMinimumCodeSize, int needDataSize)
  {
    int clearCode = 0;
    int finishCode = 0;
    Dictionary<int, string> dic = new Dictionary<int, string>();
    int lzwCodeSize = 0;
    UniGif.InitDictionary(dic, lzwMinimumCodeSize, out lzwCodeSize, out clearCode, out finishCode);
    BitArray array = new BitArray(compData.ToArray());
    byte[] numArray = new byte[needDataSize];
    int index1 = 0;
    string str1 = (string) null;
    bool flag = false;
    int startIndex = 0;
    while (startIndex < array.Length)
    {
      if (flag)
      {
        UniGif.InitDictionary(dic, lzwMinimumCodeSize, out lzwCodeSize, out clearCode, out finishCode);
        flag = false;
      }
      int numeral = array.GetNumeral(startIndex, lzwCodeSize);
      if (numeral == clearCode)
      {
        flag = true;
        startIndex += lzwCodeSize;
        str1 = (string) null;
      }
      else
      {
        if (numeral == finishCode)
        {
          Debug.LogWarning(Object.op_Implicit($"early stop code. bitDataIndex:{startIndex.ToString()} lzwCodeSize:{lzwCodeSize.ToString()} key:{numeral.ToString()} dic.Count:{dic.Count.ToString()}"));
          break;
        }
        string s;
        char reference;
        if (dic.ContainsKey(numeral))
          s = dic[numeral];
        else if (numeral >= dic.Count)
        {
          if (str1 != null)
          {
            ReadOnlySpan<char> readOnlySpan1 = (ReadOnlySpan<char>) str1;
            reference = str1[0];
            ReadOnlySpan<char> readOnlySpan2 = new ReadOnlySpan<char>(in reference);
            s = readOnlySpan1.ToString() + readOnlySpan2;
          }
          else
          {
            Debug.LogWarning(Object.op_Implicit($"It is strange that come here. bitDataIndex:{startIndex.ToString()} lzwCodeSize:{lzwCodeSize.ToString()} key:{numeral.ToString()} dic.Count:{dic.Count.ToString()}"));
            startIndex += lzwCodeSize;
            continue;
          }
        }
        else
        {
          Debug.LogWarning(Object.op_Implicit($"It is strange that come here. bitDataIndex:{startIndex.ToString()} lzwCodeSize:{lzwCodeSize.ToString()} key:{numeral.ToString()} dic.Count:{dic.Count.ToString()}"));
          startIndex += lzwCodeSize;
          continue;
        }
        byte[] bytes = Encoding.Unicode.GetBytes(s);
        for (int index2 = 0; index2 < bytes.Length; ++index2)
        {
          if (index2 % 2 == 0)
          {
            numArray[index1] = bytes[index2];
            ++index1;
          }
        }
        if (index1 < needDataSize)
        {
          if (str1 != null)
          {
            Dictionary<int, string> dictionary = dic;
            int count = dic.Count;
            ReadOnlySpan<char> readOnlySpan3 = (ReadOnlySpan<char>) str1;
            reference = s[0];
            ReadOnlySpan<char> readOnlySpan4 = new ReadOnlySpan<char>(in reference);
            string str2 = readOnlySpan3.ToString() + readOnlySpan4;
            dictionary.Add(count, str2);
          }
          str1 = s;
          startIndex += lzwCodeSize;
          if (lzwCodeSize == 3 && dic.Count >= 8)
            lzwCodeSize = 4;
          else if (lzwCodeSize == 4 && dic.Count >= 16 /*0x10*/)
            lzwCodeSize = 5;
          else if (lzwCodeSize == 5 && dic.Count >= 32 /*0x20*/)
            lzwCodeSize = 6;
          else if (lzwCodeSize == 6 && dic.Count >= 64 /*0x40*/)
            lzwCodeSize = 7;
          else if (lzwCodeSize == 7 && dic.Count >= 128 /*0x80*/)
            lzwCodeSize = 8;
          else if (lzwCodeSize == 8 && dic.Count >= 256 /*0x0100*/)
            lzwCodeSize = 9;
          else if (lzwCodeSize == 9 && dic.Count >= 512 /*0x0200*/)
            lzwCodeSize = 10;
          else if (lzwCodeSize == 10 && dic.Count >= 1024 /*0x0400*/)
            lzwCodeSize = 11;
          else if (lzwCodeSize == 11 && dic.Count >= 2048 /*0x0800*/)
            lzwCodeSize = 12;
          else if (lzwCodeSize == 12 && dic.Count >= 4096 /*0x1000*/ && array.GetNumeral(startIndex, lzwCodeSize) != clearCode)
            flag = true;
        }
        else
          break;
      }
    }
    return numArray;
  }

  private static void InitDictionary(
    Dictionary<int, string> dic,
    int lzwMinimumCodeSize,
    out int lzwCodeSize,
    out int clearCode,
    out int finishCode)
  {
    int num = (int) Math.Pow(2.0, (double) lzwMinimumCodeSize);
    clearCode = num;
    finishCode = clearCode + 1;
    dic.Clear();
    for (int key = 0; key < num + 2; ++key)
      dic.Add(key, ((char) key).ToString());
    lzwCodeSize = lzwMinimumCodeSize + 1;
  }

  private static byte[] SortInterlaceGifData(byte[] decodedData, int xNum)
  {
    int num1 = 0;
    int index1 = 0;
    byte[] numArray = new byte[decodedData.Length];
    for (int index2 = 0; index2 < numArray.Length; ++index2)
    {
      if (num1 % 8 == 0)
      {
        numArray[index2] = decodedData[index1];
        ++index1;
      }
      if (index2 != 0 && index2 % xNum == 0)
        ++num1;
    }
    int num2 = 0;
    for (int index3 = 0; index3 < numArray.Length; ++index3)
    {
      if (num2 % 8 == 4)
      {
        numArray[index3] = decodedData[index1];
        ++index1;
      }
      if (index3 != 0 && index3 % xNum == 0)
        ++num2;
    }
    int num3 = 0;
    for (int index4 = 0; index4 < numArray.Length; ++index4)
    {
      if (num3 % 4 == 2)
      {
        numArray[index4] = decodedData[index1];
        ++index1;
      }
      if (index4 != 0 && index4 % xNum == 0)
        ++num3;
    }
    int num4 = 0;
    for (int index5 = 0; index5 < numArray.Length; ++index5)
    {
      if (num4 % 8 != 0 && num4 % 8 != 4 && num4 % 4 != 2)
      {
        numArray[index5] = decodedData[index1];
        ++index1;
      }
      if (index5 != 0 && index5 % xNum == 0)
        ++num4;
    }
    return numArray;
  }

  private static bool SetGifData(byte[] gifBytes, ref UniGif.GifData gifData, bool debugLog)
  {
    if (debugLog)
      Debug.Log(Object.op_Implicit("SetGifData Start."));
    if (gifBytes == null || gifBytes.Length == 0)
    {
      Debug.LogError(Object.op_Implicit("bytes is nothing."));
      return false;
    }
    int byteIndex = 0;
    if (!UniGif.SetGifHeader(gifBytes, ref byteIndex, ref gifData))
    {
      Debug.LogError(Object.op_Implicit("GIF header set error."));
      return false;
    }
    if (!UniGif.SetGifBlock(gifBytes, ref byteIndex, ref gifData))
    {
      Debug.LogError(Object.op_Implicit("GIF block set error."));
      return false;
    }
    if (debugLog)
    {
      gifData.Dump();
      Debug.Log(Object.op_Implicit("SetGifData Finish."));
    }
    return true;
  }

  private static bool SetGifHeader(byte[] gifBytes, ref int byteIndex, ref UniGif.GifData gifData)
  {
    if (gifBytes[0] != (byte) 71 || gifBytes[1] != (byte) 73 || gifBytes[2] != (byte) 70)
    {
      Debug.LogError(Object.op_Implicit("This is not GIF image."));
      return false;
    }
    gifData.m_sig0 = gifBytes[0];
    gifData.m_sig1 = gifBytes[1];
    gifData.m_sig2 = gifBytes[2];
    if ((gifBytes[3] != (byte) 56 || gifBytes[4] != (byte) 55 || gifBytes[5] != (byte) 97) && (gifBytes[3] != (byte) 56 || gifBytes[4] != (byte) 57 || gifBytes[5] != (byte) 97))
    {
      Debug.LogError(Object.op_Implicit("GIF version error.\nSupported only GIF87a or GIF89a."));
      return false;
    }
    gifData.m_ver0 = gifBytes[3];
    gifData.m_ver1 = gifBytes[4];
    gifData.m_ver2 = gifBytes[5];
    gifData.m_logicalScreenWidth = BitConverter.ToUInt16(gifBytes, 6);
    gifData.m_logicalScreenHeight = BitConverter.ToUInt16(gifBytes, 8);
    gifData.m_globalColorTableFlag = ((int) gifBytes[10] & 128 /*0x80*/) == 128 /*0x80*/;
    switch ((int) gifBytes[10] & 112 /*0x70*/)
    {
      case 16 /*0x10*/:
        gifData.m_colorResolution = 2;
        break;
      case 32 /*0x20*/:
        gifData.m_colorResolution = 3;
        break;
      case 48 /*0x30*/:
        gifData.m_colorResolution = 4;
        break;
      case 64 /*0x40*/:
        gifData.m_colorResolution = 5;
        break;
      case 80 /*0x50*/:
        gifData.m_colorResolution = 6;
        break;
      case 96 /*0x60*/:
        gifData.m_colorResolution = 7;
        break;
      case 112 /*0x70*/:
        gifData.m_colorResolution = 8;
        break;
      default:
        gifData.m_colorResolution = 1;
        break;
    }
    gifData.m_sortFlag = ((int) gifBytes[10] & 8) == 8;
    int y = ((int) gifBytes[10] & 7) + 1;
    gifData.m_sizeOfGlobalColorTable = (int) Math.Pow(2.0, (double) y);
    gifData.m_bgColorIndex = gifBytes[11];
    gifData.m_pixelAspectRatio = gifBytes[12];
    byteIndex = 13;
    if (gifData.m_globalColorTableFlag)
    {
      gifData.m_globalColorTable = new List<byte[]>();
      for (int index = byteIndex; index < byteIndex + gifData.m_sizeOfGlobalColorTable * 3; index += 3)
        gifData.m_globalColorTable.Add(new byte[3]
        {
          gifBytes[index],
          gifBytes[index + 1],
          gifBytes[index + 2]
        });
      byteIndex += gifData.m_sizeOfGlobalColorTable * 3;
    }
    return true;
  }

  private static bool SetGifBlock(byte[] gifBytes, ref int byteIndex, ref UniGif.GifData gifData)
  {
    try
    {
      int num = 0;
      while (true)
      {
        int index = byteIndex;
        if (gifBytes[index] == (byte) 44)
          UniGif.SetImageBlock(gifBytes, ref byteIndex, ref gifData);
        else if (gifBytes[index] == (byte) 33)
        {
          switch (gifBytes[index + 1])
          {
            case 1:
              UniGif.SetPlainTextExtension(gifBytes, ref byteIndex, ref gifData);
              break;
            case 249:
              UniGif.SetGraphicControlExtension(gifBytes, ref byteIndex, ref gifData);
              break;
            case 254:
              UniGif.SetCommentExtension(gifBytes, ref byteIndex, ref gifData);
              break;
            case byte.MaxValue:
              UniGif.SetApplicationExtension(gifBytes, ref byteIndex, ref gifData);
              break;
          }
        }
        else if (gifBytes[index] == (byte) 59)
          break;
        if (num != index)
          num = index;
        else
          goto label_12;
      }
      gifData.m_trailer = gifBytes[byteIndex];
      ++byteIndex;
      goto label_15;
label_12:
      Debug.LogError(Object.op_Implicit("Infinite loop error."));
      return false;
    }
    catch (Exception ex)
    {
      Debug.LogError(Object.op_Implicit(ex.Message));
      return false;
    }
label_15:
    return true;
  }

  private static void SetImageBlock(byte[] gifBytes, ref int byteIndex, ref UniGif.GifData gifData)
  {
    UniGif.ImageBlock imageBlock = new UniGif.ImageBlock();
    imageBlock.m_imageSeparator = gifBytes[byteIndex];
    ++byteIndex;
    imageBlock.m_imageLeftPosition = BitConverter.ToUInt16(gifBytes, byteIndex);
    byteIndex += 2;
    imageBlock.m_imageTopPosition = BitConverter.ToUInt16(gifBytes, byteIndex);
    byteIndex += 2;
    imageBlock.m_imageWidth = BitConverter.ToUInt16(gifBytes, byteIndex);
    byteIndex += 2;
    imageBlock.m_imageHeight = BitConverter.ToUInt16(gifBytes, byteIndex);
    byteIndex += 2;
    imageBlock.m_localColorTableFlag = ((int) gifBytes[byteIndex] & 128 /*0x80*/) == 128 /*0x80*/;
    imageBlock.m_interlaceFlag = ((int) gifBytes[byteIndex] & 64 /*0x40*/) == 64 /*0x40*/;
    imageBlock.m_sortFlag = ((int) gifBytes[byteIndex] & 32 /*0x20*/) == 32 /*0x20*/;
    int y = ((int) gifBytes[byteIndex] & 7) + 1;
    imageBlock.m_sizeOfLocalColorTable = (int) Math.Pow(2.0, (double) y);
    ++byteIndex;
    if (imageBlock.m_localColorTableFlag)
    {
      imageBlock.m_localColorTable = new List<byte[]>();
      for (int index = byteIndex; index < byteIndex + imageBlock.m_sizeOfLocalColorTable * 3; index += 3)
        imageBlock.m_localColorTable.Add(new byte[3]
        {
          gifBytes[index],
          gifBytes[index + 1],
          gifBytes[index + 2]
        });
      byteIndex += imageBlock.m_sizeOfLocalColorTable * 3;
    }
    imageBlock.m_lzwMinimumCodeSize = gifBytes[byteIndex];
    ++byteIndex;
    while (true)
    {
      byte gifByte = gifBytes[byteIndex];
      ++byteIndex;
      if (gifByte != (byte) 0)
      {
        UniGif.ImageBlock.ImageDataBlock imageDataBlock = new UniGif.ImageBlock.ImageDataBlock()
        {
          m_blockSize = gifByte
        };
        imageDataBlock.m_imageData = new byte[(int) imageDataBlock.m_blockSize];
        for (int index = 0; index < imageDataBlock.m_imageData.Length; ++index)
        {
          imageDataBlock.m_imageData[index] = gifBytes[byteIndex];
          ++byteIndex;
        }
        if (imageBlock.m_imageDataList == null)
          imageBlock.m_imageDataList = new List<UniGif.ImageBlock.ImageDataBlock>();
        imageBlock.m_imageDataList.Add(imageDataBlock);
      }
      else
        break;
    }
    if (gifData.m_imageBlockList == null)
      gifData.m_imageBlockList = new List<UniGif.ImageBlock>();
    gifData.m_imageBlockList.Add(imageBlock);
  }

  private static void SetGraphicControlExtension(
    byte[] gifBytes,
    ref int byteIndex,
    ref UniGif.GifData gifData)
  {
    UniGif.GraphicControlExtension controlExtension = new UniGif.GraphicControlExtension();
    controlExtension.m_extensionIntroducer = gifBytes[byteIndex];
    ++byteIndex;
    controlExtension.m_graphicControlLabel = gifBytes[byteIndex];
    ++byteIndex;
    controlExtension.m_blockSize = gifBytes[byteIndex];
    ++byteIndex;
    switch ((int) gifBytes[byteIndex] & 28)
    {
      case 4:
        controlExtension.m_disposalMethod = (ushort) 1;
        break;
      case 8:
        controlExtension.m_disposalMethod = (ushort) 2;
        break;
      case 12:
        controlExtension.m_disposalMethod = (ushort) 3;
        break;
      default:
        controlExtension.m_disposalMethod = (ushort) 0;
        break;
    }
    controlExtension.m_transparentColorFlag = ((int) gifBytes[byteIndex] & 1) == 1;
    ++byteIndex;
    controlExtension.m_delayTime = BitConverter.ToUInt16(gifBytes, byteIndex);
    byteIndex += 2;
    controlExtension.m_transparentColorIndex = gifBytes[byteIndex];
    ++byteIndex;
    controlExtension.m_blockTerminator = gifBytes[byteIndex];
    ++byteIndex;
    if (gifData.m_graphicCtrlExList == null)
      gifData.m_graphicCtrlExList = new List<UniGif.GraphicControlExtension>();
    gifData.m_graphicCtrlExList.Add(controlExtension);
  }

  private static void SetCommentExtension(
    byte[] gifBytes,
    ref int byteIndex,
    ref UniGif.GifData gifData)
  {
    UniGif.CommentExtension commentExtension = new UniGif.CommentExtension();
    commentExtension.m_extensionIntroducer = gifBytes[byteIndex];
    ++byteIndex;
    commentExtension.m_commentLabel = gifBytes[byteIndex];
    ++byteIndex;
    while (true)
    {
      byte gifByte = gifBytes[byteIndex];
      ++byteIndex;
      if (gifByte != (byte) 0)
      {
        UniGif.CommentExtension.CommentDataBlock commentDataBlock = new UniGif.CommentExtension.CommentDataBlock()
        {
          m_blockSize = gifByte
        };
        commentDataBlock.m_commentData = new byte[(int) commentDataBlock.m_blockSize];
        for (int index = 0; index < commentDataBlock.m_commentData.Length; ++index)
        {
          commentDataBlock.m_commentData[index] = gifBytes[byteIndex];
          ++byteIndex;
        }
        if (commentExtension.m_commentDataList == null)
          commentExtension.m_commentDataList = new List<UniGif.CommentExtension.CommentDataBlock>();
        commentExtension.m_commentDataList.Add(commentDataBlock);
      }
      else
        break;
    }
    if (gifData.m_commentExList == null)
      gifData.m_commentExList = new List<UniGif.CommentExtension>();
    gifData.m_commentExList.Add(commentExtension);
  }

  private static void SetPlainTextExtension(
    byte[] gifBytes,
    ref int byteIndex,
    ref UniGif.GifData gifData)
  {
    UniGif.PlainTextExtension plainTextExtension = new UniGif.PlainTextExtension();
    plainTextExtension.m_extensionIntroducer = gifBytes[byteIndex];
    ++byteIndex;
    plainTextExtension.m_plainTextLabel = gifBytes[byteIndex];
    ++byteIndex;
    plainTextExtension.m_blockSize = gifBytes[byteIndex];
    ++byteIndex;
    byteIndex += 2;
    byteIndex += 2;
    byteIndex += 2;
    byteIndex += 2;
    ++byteIndex;
    ++byteIndex;
    ++byteIndex;
    ++byteIndex;
    while (true)
    {
      byte gifByte = gifBytes[byteIndex];
      ++byteIndex;
      if (gifByte != (byte) 0)
      {
        UniGif.PlainTextExtension.PlainTextDataBlock plainTextDataBlock = new UniGif.PlainTextExtension.PlainTextDataBlock()
        {
          m_blockSize = gifByte
        };
        plainTextDataBlock.m_plainTextData = new byte[(int) plainTextDataBlock.m_blockSize];
        for (int index = 0; index < plainTextDataBlock.m_plainTextData.Length; ++index)
        {
          plainTextDataBlock.m_plainTextData[index] = gifBytes[byteIndex];
          ++byteIndex;
        }
        if (plainTextExtension.m_plainTextDataList == null)
          plainTextExtension.m_plainTextDataList = new List<UniGif.PlainTextExtension.PlainTextDataBlock>();
        plainTextExtension.m_plainTextDataList.Add(plainTextDataBlock);
      }
      else
        break;
    }
    if (gifData.m_plainTextExList == null)
      gifData.m_plainTextExList = new List<UniGif.PlainTextExtension>();
    gifData.m_plainTextExList.Add(plainTextExtension);
  }

  private static void SetApplicationExtension(
    byte[] gifBytes,
    ref int byteIndex,
    ref UniGif.GifData gifData)
  {
    gifData.m_appEx.m_extensionIntroducer = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_extensionLabel = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_blockSize = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appId1 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appId2 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appId3 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appId4 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appId5 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appId6 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appId7 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appId8 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appAuthCode1 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appAuthCode2 = gifBytes[byteIndex];
    ++byteIndex;
    gifData.m_appEx.m_appAuthCode3 = gifBytes[byteIndex];
    ++byteIndex;
    while (true)
    {
      byte gifByte = gifBytes[byteIndex];
      ++byteIndex;
      if (gifByte != (byte) 0)
      {
        UniGif.ApplicationExtension.ApplicationDataBlock applicationDataBlock = new UniGif.ApplicationExtension.ApplicationDataBlock()
        {
          m_blockSize = gifByte
        };
        applicationDataBlock.m_applicationData = new byte[(int) applicationDataBlock.m_blockSize];
        for (int index = 0; index < applicationDataBlock.m_applicationData.Length; ++index)
        {
          applicationDataBlock.m_applicationData[index] = gifBytes[byteIndex];
          ++byteIndex;
        }
        if (gifData.m_appEx.m_appDataList == null)
          gifData.m_appEx.m_appDataList = new List<UniGif.ApplicationExtension.ApplicationDataBlock>();
        gifData.m_appEx.m_appDataList.Add(applicationDataBlock);
      }
      else
        break;
    }
  }

  public class GifTexture
  {
    public Texture2D m_texture2d;
    public float m_delaySec;

    public GifTexture(Texture2D texture2d, float delaySec)
    {
      this.m_texture2d = texture2d;
      this.m_delaySec = delaySec;
    }
  }

  private struct GifData
  {
    public byte m_sig0;
    public byte m_sig1;
    public byte m_sig2;
    public byte m_ver0;
    public byte m_ver1;
    public byte m_ver2;
    public ushort m_logicalScreenWidth;
    public ushort m_logicalScreenHeight;
    public bool m_globalColorTableFlag;
    public int m_colorResolution;
    public bool m_sortFlag;
    public int m_sizeOfGlobalColorTable;
    public byte m_bgColorIndex;
    public byte m_pixelAspectRatio;
    public List<byte[]> m_globalColorTable;
    public List<UniGif.ImageBlock> m_imageBlockList;
    public List<UniGif.GraphicControlExtension> m_graphicCtrlExList;
    public List<UniGif.CommentExtension> m_commentExList;
    public List<UniGif.PlainTextExtension> m_plainTextExList;
    public UniGif.ApplicationExtension m_appEx;
    public byte m_trailer;

    public string signature
    {
      get
      {
        return new string(new char[3]
        {
          (char) this.m_sig0,
          (char) this.m_sig1,
          (char) this.m_sig2
        });
      }
    }

    public string version
    {
      get
      {
        return new string(new char[3]
        {
          (char) this.m_ver0,
          (char) this.m_ver1,
          (char) this.m_ver2
        });
      }
    }

    public void Dump()
    {
      Debug.Log(Object.op_Implicit($"GIF Type: {this.signature}-{this.version}"));
      Debug.Log(Object.op_Implicit($"Image Size: {this.m_logicalScreenWidth.ToString()}x{this.m_logicalScreenHeight.ToString()}"));
      Debug.Log(Object.op_Implicit("Animation Image Count: " + this.m_imageBlockList.Count.ToString()));
      Debug.Log(Object.op_Implicit("Animation Loop Count (0 is infinite): " + this.m_appEx.loopCount.ToString()));
      if (this.m_graphicCtrlExList != null && this.m_graphicCtrlExList.Count > 0)
      {
        StringBuilder stringBuilder = new StringBuilder("Animation Delay Time (1/100sec)");
        for (int index = 0; index < this.m_graphicCtrlExList.Count; ++index)
        {
          stringBuilder.Append(", ");
          stringBuilder.Append(this.m_graphicCtrlExList[index].m_delayTime);
        }
        Debug.Log(Object.op_Implicit(stringBuilder.ToString()));
      }
      Debug.Log(Object.op_Implicit("Application Identifier: " + this.m_appEx.applicationIdentifier));
      Debug.Log(Object.op_Implicit("Application Authentication Code: " + this.m_appEx.applicationAuthenticationCode));
    }
  }

  private struct ImageBlock
  {
    public byte m_imageSeparator;
    public ushort m_imageLeftPosition;
    public ushort m_imageTopPosition;
    public ushort m_imageWidth;
    public ushort m_imageHeight;
    public bool m_localColorTableFlag;
    public bool m_interlaceFlag;
    public bool m_sortFlag;
    public int m_sizeOfLocalColorTable;
    public List<byte[]> m_localColorTable;
    public byte m_lzwMinimumCodeSize;
    public List<UniGif.ImageBlock.ImageDataBlock> m_imageDataList;

    public struct ImageDataBlock
    {
      public byte m_blockSize;
      public byte[] m_imageData;
    }
  }

  private struct GraphicControlExtension
  {
    public byte m_extensionIntroducer;
    public byte m_graphicControlLabel;
    public byte m_blockSize;
    public ushort m_disposalMethod;
    public bool m_transparentColorFlag;
    public ushort m_delayTime;
    public byte m_transparentColorIndex;
    public byte m_blockTerminator;
  }

  private struct CommentExtension
  {
    public byte m_extensionIntroducer;
    public byte m_commentLabel;
    public List<UniGif.CommentExtension.CommentDataBlock> m_commentDataList;

    public struct CommentDataBlock
    {
      public byte m_blockSize;
      public byte[] m_commentData;
    }
  }

  private struct PlainTextExtension
  {
    public byte m_extensionIntroducer;
    public byte m_plainTextLabel;
    public byte m_blockSize;
    public List<UniGif.PlainTextExtension.PlainTextDataBlock> m_plainTextDataList;

    public struct PlainTextDataBlock
    {
      public byte m_blockSize;
      public byte[] m_plainTextData;
    }
  }

  private struct ApplicationExtension
  {
    public byte m_extensionIntroducer;
    public byte m_extensionLabel;
    public byte m_blockSize;
    public byte m_appId1;
    public byte m_appId2;
    public byte m_appId3;
    public byte m_appId4;
    public byte m_appId5;
    public byte m_appId6;
    public byte m_appId7;
    public byte m_appId8;
    public byte m_appAuthCode1;
    public byte m_appAuthCode2;
    public byte m_appAuthCode3;
    public List<UniGif.ApplicationExtension.ApplicationDataBlock> m_appDataList;

    public string applicationIdentifier
    {
      get
      {
        return new string(new char[8]
        {
          (char) this.m_appId1,
          (char) this.m_appId2,
          (char) this.m_appId3,
          (char) this.m_appId4,
          (char) this.m_appId5,
          (char) this.m_appId6,
          (char) this.m_appId7,
          (char) this.m_appId8
        });
      }
    }

    public string applicationAuthenticationCode
    {
      get
      {
        return new string(new char[3]
        {
          (char) this.m_appAuthCode1,
          (char) this.m_appAuthCode2,
          (char) this.m_appAuthCode3
        });
      }
    }

    public int loopCount
    {
      get
      {
        return this.m_appDataList == null || this.m_appDataList.Count < 1 || this.m_appDataList[0].m_applicationData.Length < 3 || this.m_appDataList[0].m_applicationData[0] != (byte) 1 ? 0 : (int) BitConverter.ToUInt16(this.m_appDataList[0].m_applicationData, 1);
      }
    }

    public struct ApplicationDataBlock
    {
      public byte m_blockSize;
      public byte[] m_applicationData;
    }
  }
}
