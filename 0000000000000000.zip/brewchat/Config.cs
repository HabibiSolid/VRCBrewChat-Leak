
using Brewchat.Game.Wrappers;
using System.Runtime.InteropServices;
using UnityEngine;

#nullable enable
namespace Brewchat;

public class Config
{
  public static string? QM_BG;
  public static string? MM_BG;

  public enum Properties
  {
    Fly,
    Speed,
    abruptness2motion,
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Movement
  {
    public static bool fly { get; set; }

    public static bool abruptness2motion { get; set; } = false;

    public static float? speed { get; set; } = new float?(6.5f);
  }

  public static class testconfig
  {
    public static bool player_wallhack { get; set; }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Render
  {
    public static bool player_wallhack { get; set; }

    public static bool esp { get; set; }

    public static bool nameplate_wallhack { get; set; }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Logging
  {
    public static bool Photon { get; set; }

    public static bool RPC { get; set; }

    public static bool Udon { get; set; }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Protection
  {
    public static bool block_voicedata_event1 { get; set; }

    public static bool block_event11 { get; set; }

    public static bool block_movementdata_event12 { get; set; }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Appearance
  {
    public static string QueueAudio { get; set; } = "https://github.com/riotlu/fake-cdn/raw/refs/heads/master/Audio/raygun.ogg?raw=true";

    public static string FlatLoadingOverlay { get; set; } = "C:\\Users\\riot\\Pictures\\Saved Pictures\\20250310_031133.gif";

    public static string Mm_Background { get; set; } = "https://github.com/smooshs/fake-cdn/blob/master/bbb/GpowaDuXgAA77ES.jpg?raw=true";

    public static string Qm_Background { get; set; } = "https://github.com/smooshs/fake-cdn/blob/master/bbb/GpowaDuXgAA77ES.jpg?raw=true";

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct Platte
    {
      public static Color Main { get; set; } = EngineUtils.Conversion.HexToColor("#c60e7b");

      public static Color Nameplate { get; set; } = EngineUtils.Conversion.HexToColor("#c60e7b");

      public static Color Chatbox { get; set; } = EngineUtils.Conversion.HexToColor("#c60e7b");

      public static Color HighlightFX { get; set; } = EngineUtils.Conversion.HexToColor("#c60e7b");
    }

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct Hiders
    {
      public static bool HideLoadingOverlay { get; set; }
    }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Exploits
  {
    public static bool RPC_ForceGlobal { get; set; }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Advanced
  {
    public static bool DebugMode { get; set; }
  }
}
