
#nullable disable
namespace Brewchat.Cheats.SDK3.World;

public static class OptimizeBox
{
}
