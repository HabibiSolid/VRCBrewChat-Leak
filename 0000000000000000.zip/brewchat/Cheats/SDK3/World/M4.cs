
using System.Collections;
using UnityEngine;
using VRC.SDK3.Components;
using VRC.Udon;

#nullable enable
namespace Brewchat.Cheats.SDK3.World;

public class M4
{
  public static string? uddies;

  public static IEnumerator UdonNukeCoroutine()
  {
    foreach (UdonBehaviour behaviour in Object.FindObjectsOfType<UdonBehaviour>())
    {
      foreach (string key in behaviour._eventTable.Keys)
      {
        ((AbstractUdonBehaviour) behaviour).SendCustomEvent(key);
        yield return (object) null;
      }
    }
  }
}
