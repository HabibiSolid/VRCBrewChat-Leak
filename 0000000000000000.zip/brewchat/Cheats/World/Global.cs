
#nullable disable
namespace Brewchat.Cheats.World;

public class Global
{
}
