
using UnityEngine;

#nullable enable
namespace Brewchat.Game.Wrappers;

public static class TextureExtensions
{
  public static Sprite ToSprite(this Texture2D? texture)
  {
    return Sprite.Create(texture, new Rect(0.0f, 0.0f, (float) ((Texture) texture).width, (float) ((Texture) texture).height), Vector2.zero);
  }

  public static Texture2D? Change(this Texture2D texture, string dir)
  {
    return EngineUtils.Assets.Texture(dir);
  }
}
