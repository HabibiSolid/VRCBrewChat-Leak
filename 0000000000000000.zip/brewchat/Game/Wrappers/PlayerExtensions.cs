
using System;
using UnityEngine;
using VRC;
using VRC.Core;

#nullable enable
namespace Brewchat.Game.Wrappers;

public static class PlayerExtensions
{
  public static Color GetTrustColor(this Player player)
  {
    APIUser apiUser = player.APIUser;
    Color trustColor;
    if (apiUser != null)
    {
      if (!apiUser.hasTrustedTrustLevel)
      {
        if (!apiUser.hasKnownTrustLevel)
        {
          if (!apiUser.hasBasicTrustLevel)
          {
            if (!apiUser.isNewUser)
            {
              if (!apiUser.hasNegativeTrustLevel)
              {
                if (apiUser.hasVeryNegativeTrustLevel)
                {
                  trustColor = VRCPlayer.field_Internal_Static_Color_0;
                  goto label_14;
                }
              }
              else
              {
                trustColor = VRCPlayer.field_Internal_Static_Color_9;
                goto label_14;
              }
            }
            else
            {
              trustColor = VRCPlayer.field_Internal_Static_Color_3;
              goto label_14;
            }
          }
          else
          {
            trustColor = VRCPlayer.field_Internal_Static_Color_4;
            goto label_14;
          }
        }
        else
        {
          trustColor = VRCPlayer.field_Internal_Static_Color_5;
          goto label_14;
        }
      }
      else
      {
        trustColor = VRCPlayer.field_Internal_Static_Color_6;
        goto label_14;
      }
    }
    trustColor = Color.white;
label_14:
    return trustColor;
  }

  public static string? GetTrustRank(this Player player)
  {
    APIUser apiUser = player.APIUser;
    string trustRank;
    if (apiUser != null)
    {
      if (!apiUser.hasTrustedTrustLevel)
      {
        if (!apiUser.hasKnownTrustLevel)
        {
          if (!apiUser.isNewUser)
          {
            if (!apiUser.hasBasicTrustLevel)
            {
              if (!apiUser.hasNegativeTrustLevel)
              {
                if (apiUser.hasVeryNegativeTrustLevel)
                {
                  trustRank = "Very Retarded";
                  goto label_14;
                }
              }
              else
              {
                trustRank = "Nuisance";
                goto label_14;
              }
            }
            else
            {
              trustRank = "User";
              goto label_14;
            }
          }
          else
          {
            trustRank = "New User";
            goto label_14;
          }
        }
        else
        {
          trustRank = "Known";
          goto label_14;
        }
      }
      else
      {
        trustRank = "Trusted";
        goto label_14;
      }
    }
    trustRank = "Visitor";
label_14:
    return trustRank;
  }

  public static string IsFriend(this Player player)
  {
    return !player.APIUser.isFriend ? (string) null : "Friend";
  }

  public static string IsAdult(this Player player) => !player.APIUser.ageVerified ? "-18" : "+18";

  public static Player? GetPlayer(this string name)
  {
    if (string.IsNullOrEmpty(name))
      return (Player) null;
    foreach (Player getAllPlayer in GameUtils.PlayerModel.Matchmaking.GetAllPlayers)
    {
      if (!getAllPlayer.APIUser.IsSelf && !Object.op_Equality((Object) getAllPlayer._vrcplayer, (Object) null) && !Object.op_Equality((Object) getAllPlayer._vrcplayer._player, (Object) null) && string.Equals(getAllPlayer.APIUser.displayName, name, StringComparison.OrdinalIgnoreCase))
        return getAllPlayer._vrcplayer._player;
    }
    return (Player) null;
  }

  public static Player? GetPlayerFromActor(this int id)
  {
    foreach (Player getAllPlayer in GameUtils.PlayerModel.Matchmaking.GetAllPlayers)
    {
      if (getAllPlayer.VRCPlayerApi.playerId == id)
        return getAllPlayer;
    }
    return (Player) null;
  }
}
