
using BlanketSDK.Core;
using ExitGames.Client.Photon;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Pasted.WTFBlaze.Utils.Managers;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine;
using VRC;
using VRC.Animation;
using VRC.Core;
using VRC.DataModel;
using VRC.Localization;
using VRC.Networking;
using VRC.SDKBase;
using VRC.UI;
using VRC.UI.Client;
using VRC.UI.Client.HUD;
using VRC.UI.Elements;
using VRC.UI.Elements.Controls;
using VRCSDK2;

#nullable enable
namespace Brewchat.Game.Wrappers;

internal class GameUtils
{
  public class Gameplay
  {
    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct RenderLayers
    {
      public static LayerMask InternalUI = LayerMask.op_Implicit(LayerMask.NameToLayer(nameof (InternalUI)));
      public static LayerMask Default = LayerMask.op_Implicit(LayerMask.NameToLayer(nameof (Default)));
    }

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct CallbackEvents
    {
      private static QuickMenu? QuickMenu_Cache;
      private static MainMenu? MainMenu_Cache;

      public static bool IsInQuickMenu
      {
        get
        {
          if (GameUtils.Gameplay.CallbackEvents.QuickMenu_Cache == null)
            GameUtils.Gameplay.CallbackEvents.QuickMenu_Cache = Object.FindObjectOfType<QuickMenu>();
          return Object.op_Inequality((Object) GameUtils.Gameplay.CallbackEvents.QuickMenu_Cache, (Object) null) && ((Behaviour) GameUtils.Gameplay.CallbackEvents.QuickMenu_Cache).enabled;
        }
      }

      public static bool IsInMainMenu
      {
        get
        {
          if (GameUtils.Gameplay.CallbackEvents.MainMenu_Cache == null)
            GameUtils.Gameplay.CallbackEvents.MainMenu_Cache = Object.FindObjectOfType<MainMenu>();
          return Object.op_Inequality((Object) GameUtils.Gameplay.CallbackEvents.MainMenu_Cache, (Object) null) && ((Behaviour) GameUtils.Gameplay.CallbackEvents.MainMenu_Cache).enabled;
        }
      }
    }

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct NetworkUtils
    {
      private static int _eintMValue;

      public static void SendEmojiRPC(int emoji)
      {
        Int32 int32 = new Int32();
        GameUtils.Gameplay.NetworkUtils._eintMValue = int32.m_value;
        GameUtils.Gameplay.NetworkUtils._eintMValue = emoji;
        ((Int32) ref int32).BoxIl2CppObject();
        VRC.SDKBase.Networking.RPC((RPC.Destination) 0, ((Component) GameUtils.PlayerModel.Get()).gameObject, nameof (SendEmojiRPC), new Object[1]
        {
          Object.op_Implicit(emoji)
        });
      }

      public static string Join(string worldId)
      {
        VRC.SDKBase.Networking.GoToRoom(worldId);
        return worldId;
      }

      [StructLayout(LayoutKind.Sequential, Size = 1)]
      public struct Player
      {
        public static void SpawnEmoji(string id)
        {
        }

        public static void SpawnPrint(string id)
        {
        }

        public static void SpawnPortal(string id)
        {
        }

        public static void SpawnDrone(int actor)
        {
        }
      }
    }

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct PhotonUtils
    {
      public static void SendRaiseEvent(byte code, object payload, SendOptions sendOptions)
      {
        Object il2Cpp = SerializationManager.FromManagedToIL2CPP<Object>(payload);
        int num = (int) code;
        Object @object = il2Cpp;
        RaiseEventOptions raiseEventOptions = new RaiseEventOptions();
        raiseEventOptions.field_Public_ReceiverGroup_0 = (ReceiverGroup) 0;
        raiseEventOptions.field_Public_EventCaching_0 = (EventCaching) 0;
        SendOptions sendOptions1 = sendOptions;
        PhotonNetwork.RaiseEvent((byte) num, @object, raiseEventOptions, sendOptions1);
      }

      public enum Events : byte
      {
        VoiceData = 1,
        EV = 11, // 0x0B
        MovementData = 12, // 0x0C
        MovementData2 = 13, // 0x0D
        Chatbox = 43, // 0x2B
        Social = 74, // 0x4A
        PlayerPrefab = 202, // 0xCA
        OnPlayerJoin = 253, // 0xFD
        OnPlayerLeft = 254, // 0xFE
        OnPlayerFailedJoin = 255, // 0xFF
      }
    }
  }

  public class Camera
  {
    public static UnityEngine.Camera Get { get; set; } = UnityEngine.Camera.main;

    public static GameObject CameraObj => GameObject.Find(nameof (Camera));
  }

  public class PlayerModel
  {
    public static Player Get() => Player.Method_Internal_Static_get_Player_0();

    public static Player? GrabPlayerFromDisplayName(string name)
    {
      if (string.IsNullOrEmpty(name))
        return (Player) null;
      foreach (Player getAllPlayer in GameUtils.PlayerModel.Matchmaking.GetAllPlayers)
      {
        if (!getAllPlayer.APIUser.IsSelf && Object.op_Implicit((Object) getAllPlayer._vrcplayer) && Object.op_Implicit((Object) getAllPlayer._vrcplayer._player) && string.Equals(getAllPlayer.APIUser.displayName, name, StringComparison.OrdinalIgnoreCase))
          return getAllPlayer._vrcplayer._player;
      }
      return (Player) null;
    }

    public static Player? GetPlayerFromActor(int id)
    {
      foreach (Player getAllPlayer in GameUtils.PlayerModel.Matchmaking.GetAllPlayers)
      {
        if (getAllPlayer.VRCPlayerApi.playerId == id)
          return getAllPlayer;
      }
      return (Player) null;
    }

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct _components
    {
      public static VRCMotionState _motion = ((Component) GameUtils.PlayerModel.Get()).GetComponent<VRCMotionState>();
      public static FlatBufferNetworkSerializer _serializer = ((Component) GameUtils.PlayerModel.Get()).GetComponent<FlatBufferNetworkSerializer>();
      public static SyncPhysics _SyncPhysics = ((Component) GameUtils.PlayerModel.Get()).GetComponent<SyncPhysics>();
    }

    public static class Motion
    {
      [StructLayout(LayoutKind.Sequential, Size = 1)]
      public struct Networking
      {
        public static VRCPlayerApi Run_Speed(float v = 2f)
        {
          VRCPlayerApi vrcPlayerApi = GameUtils.PlayerModel.Get().VRCPlayerApi;
          vrcPlayerApi.SetRunSpeed(v);
          return vrcPlayerApi;
        }

        public static VRCPlayerApi Walk_Speed(float v = 2f)
        {
          VRCPlayerApi vrcPlayerApi = GameUtils.PlayerModel.Get().VRCPlayerApi;
          vrcPlayerApi.SetWalkSpeed(v);
          return vrcPlayerApi;
        }

        public static VRCPlayerApi Jump_Impulse(float v = 3f)
        {
          VRCPlayerApi vrcPlayerApi = GameUtils.PlayerModel.Get().VRCPlayerApi;
          vrcPlayerApi.SetJumpImpulse(v);
          return vrcPlayerApi;
        }

        public static VRCPlayerApi Velocity(Vector3 v)
        {
          VRCPlayerApi vrcPlayerApi = GameUtils.PlayerModel.Get().VRCPlayerApi;
          vrcPlayerApi.SetVelocity(v);
          return vrcPlayerApi;
        }

        public static VRCPlayerApi Gravity(float v = 1f)
        {
          VRCPlayerApi vrcPlayerApi = GameUtils.PlayerModel.Get().VRCPlayerApi;
          vrcPlayerApi.SetGravityStrength(v);
          return vrcPlayerApi;
        }
      }
    }

    public static class Avatar
    {
      public static ApiAvatar SetAvatar(string id)
      {
        ApiAvatar apiAvatar = new ApiAvatar();
        ((ApiModel) apiAvatar).id = id;
        PageAvatar.Method_Public_Static_Void_ApiAvatar_String_0(apiAvatar, "AvatarMenu");
        return apiAvatar;
      }

      public static ApiAvatar GetAvatar()
      {
        return GameUtils.PlayerModel.Get().Method_Public_get_ApiAvatar_PDM_0();
      }

      public static void AvatarScale(float v = 4f)
      {
        GameUtils.PlayerModel.Get().VRCPlayerApi.SetAvatarEyeHeightByMeters(v);
      }

      public static void AllowAvatarScaling(bool v = true)
      {
        GameUtils.PlayerModel.Get().VRCPlayerApi.SetManualAvatarScalingAllowed(v);
      }

      public static void AvatarScaleMax(float v)
      {
        GameUtils.PlayerModel.Get().VRCPlayerApi.SetAvatarEyeHeightMaximumByMeters(v);
      }

      public static void AvatarScaleMin(float v)
      {
        GameUtils.PlayerModel.Get().VRCPlayerApi.SetAvatarEyeHeightMinimumByMeters(v);
      }

      public static void AllowScaling(bool v)
      {
        GameUtils.PlayerModel.Get().VRCPlayerApi.SetManualAvatarScalingAllowed(v);
      }
    }

    public static class Matchmaking
    {
      public static Player? GetSelectedUser()
      {
        return Object.FindObjectOfType<QuickMenu>().field_Private_IUser_0.Method_Public_Abstract_Virtual_New_get_String_1().GetPlayer()?._vrcplayer._player;
      }

      public static List<Player> GetAllPlayers
      {
        get => PlayerManager.Method_Private_Static_get_PlayerManager_0().PlayerList;
      }
    }
  }

  public class World
  {
    public static string GetID()
    {
      return ((ApiModel) RoomManager.field_Private_Static_ApiWorldInstance_1).id;
    }

    public static bool IsLoaded()
    {
      return RoomManager.Method_Internal_Static_get_ApiWorldInstance_PDM_0() != null || RoomManager.currentApiWorld != null;
    }

    public class SDK2
    {
      public static void InteractWithTrigger(string triggerobj)
      {
        foreach (VRC_Trigger vrcTrigger in Object.FindObjectsOfType<VRC_Trigger>())
        {
          if (((Object) ((Component) vrcTrigger).gameObject).name.Contains(triggerobj))
          {
            ((VRC_Interactable) vrcTrigger).Interact();
            if (Config.Advanced.DebugMode)
              break;
            GameUtils.UI.HUD.ToastV2("Sent Trigger", ((Object) ((Component) vrcTrigger).gameObject).name);
            break;
          }
        }
      }
    }

    public class SDK3
    {
    }
  }

  public static class UI
  {
    public class HUD
    {
      public static void ToastV1(string content, float duration = 3f, Sprite? sprite = null)
      {
        try
        {
          HudController.field_Public_Static_HudController_0.userEventCarousel.Method_Private_Void_LocalizableString_Sprite_Single_0(LocalizableStringExtensions.Localize(content, (Object) null, (Object) null, (Object) null), sprite, duration);
        }
        catch (Exception ex)
        {
          Debug.LogError(Object.op_Implicit("[NotificationManager] Message error: " + ex.Message));
        }
      }

      public static void ToastV2(string? title, string? content = null, float duration = 2f, Sprite? sprite = null)
      {
        HudController.field_Public_Static_HudController_0.notification?.ShowNotification(sprite, LocalizableStringExtensions.Localize(title, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(content, (Object) null, (Object) null, (Object) null), duration, (Object1PublicTBoTUnique<bool>) null);
      }

      public static string Alert(string content)
      {
        VRCUIManager.Method_Public_Static_get_VRCUIManager_0().Method_Public_Virtual_Final_New_Void_LocalizableString_0(LocalizableStringExtensions.Localize(content, (Object) null, (Object) null, (Object) null));
        return content;
      }

      public static void PopUp(string title = null, string content = null, float duration = 10f)
      {
        VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().Method_Internal_get_VRCUiPopupManager_0().Method_Public_Void_LocalizableString_LocalizableString_Single_0(LocalizableStringExtensions.Localize(title, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(content, (Object) null, (Object) null, (Object) null), duration);
      }

      public static void PopUp2(string title = null, string content = null, string? uhz = null, Action func = null)
      {
        VRCUiManager.Method_Internal_Static_get_VRCUiManager_PDM_0().Method_Internal_get_VRCUiPopupManager_0().Method_Public_Void_LocalizableString_LocalizableString_LocalizableString_Action_Action_1_VRCUiPopup_0(LocalizableStringExtensions.Localize(title, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(content, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(uhz, (Object) null, (Object) null, (Object) null), Action.op_Implicit(func), (Action<VRCUiPopup>) null);
      }

      public static void LoadingPopUp2(
        string? title,
        string? content,
        string? button_text,
        Action func,
        Action<VRCUiPopup> idk,
        float duration = 10f)
      {
        VRCUiManager.field_Private_Static_VRCUiManager_0.Method_Internal_get_VRCUiPopupManager_0().Method_Public_Void_LocalizableString_LocalizableString_LocalizableString_Action_LocalizableString_Action_Action_1_VRCUiPopup_0(LocalizableStringExtensions.Localize(title, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(content, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(button_text, (Object) null, (Object) null, (Object) null), Action.op_Implicit(func), LocalizableStringExtensions.Localize(button_text, (Object) null, (Object) null, (Object) null), (Action) null, (Action<VRCUiPopup>) null);
      }

      public static void LoadingPopUp(
        string? title,
        string? content,
        string? button_text,
        Action func,
        Action<VRCUiPopup> idk,
        float duration = 10f)
      {
        VRCUiManager.field_Private_Static_VRCUiManager_0.Method_Internal_get_VRCUiPopupManager_0().Method_Public_Void_LocalizableString_LocalizableString_LocalizableString_Action_Action_1_VRCUiPopup_0(LocalizableStringExtensions.Localize(title, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(content, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(button_text, (Object) null, (Object) null, (Object) null), Action.op_Implicit(func), Action<VRCUiPopup>.op_Implicit(idk));
      }

      public enum AlertType
      {
        QuickMenu,
        MainMenu,
      }
    }
  }

  public class VRChatUtils
  {
    public static class InputManager
    {
      public static VRCInput GetInput(string name)
      {
        return VRCInputManager.field_Private_Static_Dictionary_2_String_VRCInput_0[name];
      }

      public static VRCInput GetInput(GameUtils.VRChatUtils.InputManager.Get name)
      {
        return VRCInputManager.field_Private_Static_Dictionary_2_String_VRCInput_0[name.ToString()];
      }

      public enum Get
      {
        Horizontial,
        Vertical,
      }
    }

    public static class VRCKeyboard
    {
      private static VRCInputField? inputfield;
      private static GameObject? Object;

      public static void InputPopup(
        string Title,
        Action<string> EndString,
        Action<string>? RealTimeString = null,
        Action? OnClose = null,
        GameUtils.VRChatUtils.VRCKeyboard.KeyBoardType keyBoardType = GameUtils.VRChatUtils.VRCKeyboard.KeyBoardType.Standard,
        string Placeholder = "Enter Text",
        string OkButton = "OK",
        string CancelButton = "Cancel",
        bool MultiLine = true,
        int CharLimit = 0,
        bool KeepOpen = false,
        bool ReadOnly = false)
      {
        if (Object.op_Equality((Object) GameUtils.VRChatUtils.VRCKeyboard.inputfield, (Object) null))
        {
          GameUtils.VRChatUtils.VRCKeyboard.Object = new GameObject("[Astriek] Keyboard");
          GameUtils.VRChatUtils.VRCKeyboard.Object.transform.parent = IMainMenuElements.MMParent();
          Object.DontDestroyOnLoad((Object) GameUtils.VRChatUtils.VRCKeyboard.Object);
          GameUtils.VRChatUtils.VRCKeyboard.inputfield = ExtensionMethods.GetOrAddComponent<VRCInputField>(GameUtils.VRChatUtils.VRCKeyboard.Object);
        }
        KeyboardData keyboardData = new KeyboardData().Method_Public_KeyboardData_LocalizableString_LocalizableString_String_LocalizableString_LocalizableString_0(LocalizableStringExtensions.Localize(Title, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(Placeholder, (Object) null, (Object) null, (Object) null), "", LocalizableStringExtensions.Localize(OkButton, (Object) null, (Object) null, (Object) null), LocalizableStringExtensions.Localize(CancelButton, (Object) null, (Object) null, (Object) null)).Method_Public_KeyboardData_Action_1_String_Action_1_String_Action_Boolean_PDM_0(Action<string>.op_Implicit(RealTimeString), Action<string>.op_Implicit(EndString), Action.op_Implicit(OnClose), KeepOpen).Method_Public_KeyboardData_InputPopupType_Boolean_PDM_0((InputPopupType) keyBoardType, true).Method_Public_KeyboardData_InputType_ContentType_Int32_Boolean_Boolean_InterfacePublicAbstractBoStVoAc1VoAcSt1BoUnique_PDM_0((TMP_InputField.InputType) 0, (TMP_InputField.ContentType) 0, CharLimit, MultiLine, ReadOnly, (InterfacePublicAbstractBoStVoAc1VoAcSt1BoUnique) null);
        keyboardData._isWorldKeyboard = true;
        GameUtils.VRChatUtils.VRCKeyboard.inputfield._keyboardData = keyboardData;
        GameUtils.VRChatUtils.VRCKeyboard.inputfield.Method_Private_Void_0();
      }

      public enum KeyBoardType
      {
        Standard,
        Numeric,
        Search,
      }
    }

    public static class RPCs
    {
    }

    public static class Events
    {
      public static string SendEvent43_Chatbox(string msg)
      {
        GameUtils.Gameplay.PhotonUtils.SendRaiseEvent((byte) 43, (object) msg, new SendOptions());
        return msg;
      }
    }
  }
}
