
using Cysharp.Threading.Tasks;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using System;
using System.IO;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Threading;
using UnityEngine;
using UnityEngine.Networking;
using WebSocketSharp;

#nullable enable
namespace Brewchat.Game.Wrappers;

internal static class EngineUtils
{
  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Conversion
  {
    public static Color HexToColor(string hex)
    {
      Color color;
      ColorUtility.TryParseHtmlString(hex, ref color);
      return color;
    }

    public static string ColorToHex(Color color) => ColorUtility.ToHtmlStringRGB(color);
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct Assets
  {
    public static AudioClip? AudioClip(Uri url)
    {
      UnityWebRequest unityWebRequest = UnityWebRequest.Get(url.ToString());
      UnityWebRequestAsyncOperation requestAsyncOperation = unityWebRequest.SendWebRequest();
      while (!((AsyncOperation) requestAsyncOperation).isDone)
        Thread.Sleep(1);
      if (unityWebRequest.result != 1)
        return (AudioClip) null;
      AudioClip audioClipUsingDh = WebRequestWWW.InternalCreateAudioClipUsingDH(unityWebRequest.downloadHandler, unityWebRequest.url, false, false, (AudioType) 0);
      if (Object.op_Equality((Object) audioClipUsingDh, (Object) null))
        return (AudioClip) null;
      if (url.IsFile)
        ((Object) audioClipUsingDh).name = Path.GetFileNameWithoutExtension(url.LocalPath);
      return audioClipUsingDh;
    }

    public static GameObject? CreateAudio(Uri url, float volume = 1f, bool loop = true, bool bypassAllEffects = true)
    {
      UnityWebRequest unityWebRequest = UnityWebRequest.Get(url.ToString());
      UnityWebRequestAsyncOperation requestAsyncOperation = unityWebRequest.SendWebRequest();
      while (!((AsyncOperation) requestAsyncOperation).isDone)
        Thread.Sleep(1);
      if (unityWebRequest.result != 1)
        return (GameObject) null;
      AudioClip audioClipUsingDh = WebRequestWWW.InternalCreateAudioClipUsingDH(unityWebRequest.downloadHandler, unityWebRequest.url, false, false, (AudioType) 0);
      if (Object.op_Equality((Object) audioClipUsingDh, (Object) null))
        return (GameObject) null;
      AudioSource audioSource1 = new GameObject($"Audio: [{url.LocalPath}]").AddComponent<AudioSource>();
      if (url.IsFile)
      {
        ((Object) audioSource1).name = Path.GetFileNameWithoutExtension(url.LocalPath);
        ((Object) audioClipUsingDh).name = ((Object) audioSource1).name;
      }
      audioSource1.clip = audioClipUsingDh;
      AudioSource audioSource2 = audioSource1;
      ((Object) audioSource2).hideFlags = (HideFlags) (((Object) audioSource2).hideFlags + 32 /*0x20*/);
      audioSource1.loop = loop;
      audioSource1.volume = volume;
      audioSource1.bypassListenerEffects = bypassAllEffects;
      audioSource1.bypassReverbZones = bypassAllEffects;
      audioSource1.Play();
      Object.DontDestroyOnLoad((Object) audioSource1);
      return ((Component) audioSource1).gameObject;
    }

    public static AudioSource? AudioOverride(Uri url)
    {
      UnityWebRequest unityWebRequest = UnityWebRequest.Get(url.ToString());
      UnityWebRequestAsyncOperation requestAsyncOperation = unityWebRequest.SendWebRequest();
      while (!((AsyncOperation) requestAsyncOperation).isDone)
        Thread.Sleep(1);
      if (unityWebRequest.result != 1)
        return (AudioSource) null;
      AudioClip audioClipUsingDh = WebRequestWWW.InternalCreateAudioClipUsingDH(unityWebRequest.downloadHandler, unityWebRequest.url, false, false, (AudioType) 0);
      AudioSource audioSource1 = (AudioSource) null;
      if (Object.op_Equality((Object) audioSource1, (Object) null) || Object.op_Equality((Object) audioClipUsingDh, (Object) null))
        return (AudioSource) null;
      if (url.IsFile)
        ((Object) audioClipUsingDh).name = Path.GetFileNameWithoutExtension(url.LocalPath);
      audioSource1.clip = audioClipUsingDh;
      AudioSource audioSource2 = audioSource1;
      ((Object) audioSource2).hideFlags = (HideFlags) (((Object) audioSource2).hideFlags + 32 /*0x20*/);
      audioSource1.Play();
      return audioSource1;
    }

    public static Texture2D? INTERNAL_Texture(byte[] data)
    {
      Texture2D texture2D = new Texture2D(0, 0);
      ImageConversion.LoadImage(texture2D, Il2CppStructArray<byte>.op_Implicit(data));
      if (Object.op_Inequality((Object) texture2D, (Object) null))
        ((Object) texture2D).name = "resources.dev";
      return texture2D;
    }

    [Obsolete("We used Uri Now.")]
    public static Texture2D? Texture(string dir)
    {
      byte[] result = File.ReadAllBytesAsync(dir).GetAwaiter().GetResult();
      Texture2D texture2D = new Texture2D(0, 0);
      ImageConversion.LoadImage(texture2D, Il2CppStructArray<byte>.op_Implicit(result));
      if (Object.op_Inequality((Object) texture2D, (Object) null))
        ((Object) texture2D).name = Path.GetFileNameWithoutExtension(dir);
      return texture2D;
    }

    public static Texture2D? Texture(Uri? url)
    {
      if (url == (Uri) null)
        throw new ArgumentNullException(nameof (url));
      byte[] numArray;
      if (url.IsFile)
      {
        numArray = File.ReadAllBytes(url.LocalPath);
      }
      else
      {
        if (!(url.Scheme == Uri.UriSchemeHttp) && !(url.Scheme == Uri.UriSchemeHttps))
          throw new NotSupportedException("Unsupported URI scheme: " + url.Scheme);
        using (HttpClient httpClient = new HttpClient())
          numArray = httpClient.GetByteArrayAsync(url.ToString()).GetAwaiter().GetResult();
      }
      Texture2D texture2D = new Texture2D(2048 /*0x0800*/, 2048 /*0x0800*/);
      ImageConversion.LoadImage(texture2D, Il2CppStructArray<byte>.op_Implicit(numArray));
      ((Object) texture2D).name = Path.GetFileNameWithoutExtension(url.LocalPath);
      return texture2D;
    }

    [Obsolete("We used Uri Now.")]
    public static Sprite Sprite(string dir) => EngineUtils.Assets.Texture(dir).ToSprite();

    public static Sprite Data_LoadSprite(Uri? dir) => EngineUtils.Assets.Texture(dir).ToSprite();

    public static GameObject INTERNAL_AssetBundle(byte[]? data, string? name, bool? keep)
    {
      if (data != null && data.Length == 0)
        return (GameObject) null;
      AssetBundle result = UnityAsyncExtensions.GetAwaiter(AssetBundle.LoadFromMemoryAsync(Il2CppStructArray<byte>.op_Implicit(data))).GetResult();
      GameObject gameObject1 = result.LoadAsset<GameObject>(name);
      GameObject gameObject2 = Object.Instantiate<GameObject>(gameObject1);
      if (keep.HasValue && keep.GetValueOrDefault())
        Object.DontDestroyOnLoad((Object) gameObject1);
      result.Unload(false);
      return gameObject2;
    }

    [Obsolete]
    public static Object AssetBundle(string? dir, string? prefab_name, bool? keep)
    {
      if (Ext.IsNullOrEmpty(dir))
        return (Object) null;
      Object result = UnityAsyncExtensions.GetAwaiter(UnityAsyncExtensions.GetAwaiter(AssetBundle.LoadFromFileAsync(dir)).GetResult().LoadAssetAsync<GameObject>(prefab_name)).GetResult();
      if (keep.GetValueOrDefault())
        Object.DontDestroyOnLoad(result);
      return result;
    }

    public static GameObject AssetBundle(Uri? url, string? prefab_name, bool? keep)
    {
      AssetBundle assetBundle = AssetBundle.LoadFromMemory(Il2CppStructArray<byte>.op_Implicit(new HttpClient().GetByteArrayAsync(url).Result));
      GameObject gameObject = Object.Instantiate<GameObject>(assetBundle.LoadAsset<GameObject>(prefab_name));
      if (keep.HasValue && keep.GetValueOrDefault())
        Object.DontDestroyOnLoad((Object) gameObject);
      assetBundle.Unload(false);
      return gameObject;
    }
  }
}
