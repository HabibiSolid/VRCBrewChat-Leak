
using UnityEngine;
using VRC;

#nullable enable
namespace Brewchat.Game.Monobehaviours;

public class RecordsTags : MonoBehaviour
{
  public Player _player;

  private void Start()
  {
  }
}
