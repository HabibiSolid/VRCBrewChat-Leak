
using Brewchat.Game.Wrappers;
using UnityEngine;

#nullable disable
namespace Brewchat.Game.Monobehaviours;

internal class FlyManager : MonoBehaviour
{
  private Vector3 velocity = Vector3.zero;
  private float acceleration = 10f;
  private float deceleration = 5f;

  public bool AllowRotation { get; set; }

  public bool Player { get; set; }

  private void Update() => this.Controller();

  private void Controller()
  {
    float? nullable1;
    float? nullable2;
    if (!Input.GetKey((KeyCode) 304))
    {
      nullable2 = Config.Movement.speed;
    }
    else
    {
      nullable1 = Config.Movement.speed;
      float num = 5f;
      nullable2 = nullable1.HasValue ? new float?(nullable1.GetValueOrDefault() * num) : new float?();
    }
    nullable1 = nullable2;
    float num1 = nullable1.Value;
    if (((Component) this).transform == null || GameUtils.Gameplay.CallbackEvents.IsInMainMenu)
      return;
    Vector3 vector3_1 = Vector3.zero;
    if (Input.GetKey((KeyCode) 113))
      vector3_1 = Vector3.op_Addition(vector3_1, Vector3.down);
    if (Input.GetKey((KeyCode) 101))
      vector3_1 = Vector3.op_Addition(vector3_1, Vector3.up);
    Vector3 vector3_2 = Vector3.op_Addition(Vector3.op_Addition(vector3_1, Vector3.op_Multiply(((Component) GameUtils.Camera.Get).transform.forward, GameUtils.VRChatUtils.InputManager.GetInput("Vertical").Method_Public_get_Single_PDM_0())), Vector3.op_Multiply(((Component) GameUtils.Camera.Get).transform.right, GameUtils.VRChatUtils.InputManager.GetInput("Horizontal").Method_Public_get_Single_PDM_0()));
    ((Vector3) ref vector3_2).Normalize();
    Transform transform = ((Component) this).transform;
    transform.position = Vector3.op_Addition(transform.position, Vector3.op_Multiply(vector3_2, num1 * Time.deltaTime));
    if (!this.AllowRotation)
      return;
    ((Component) this).transform.rotation = ((Component) GameUtils.Camera.Get).transform.rotation;
  }
}
