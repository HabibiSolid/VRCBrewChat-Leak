
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

#nullable enable
namespace Brewchat.Game.Monobehaviours;

public class UniversialTags : MonoBehaviour
{
  public static Dictionary<GameObject, string>? Objects { get; } = new Dictionary<GameObject, string>();

  public void AddTagToObject(string tag)
  {
    UniversialTags.Objects?.Add(((Component) ((Component) this).transform).gameObject, tag);
  }

  public static void Destory(string id)
  {
    Dictionary<GameObject, string> objects = UniversialTags.Objects;
    if (objects == null)
      return;
    objects.ToList<KeyValuePair<GameObject, string>>().ForEach((Action<KeyValuePair<GameObject, string>>) (x =>
    {
      if (!(x.Value == id))
        return;
      Object.Destroy((Object) x.Key);
    }));
  }
}
