
using Brewchat.Cheat;
using Brewchat.Cheat.Modules;
using Brewchat.Game.Wrappers;
using Syrup.IMGUI;
using System;
using UnityEngine;

#nullable enable
namespace Brewchat.Game.Monobehaviours;

internal class KeybindManager : MonoBehaviour
{
  private void Awake()
  {
    sconsole.print(" Monobehaviours", "/KeybindManager", nameof (KeybindManager), 0);
  }

  private void LateUpdate()
  {
    if (!GameUtils.World.IsLoaded())
      return;
    this.CommandHandler();
    if (GameUtils.Gameplay.CallbackEvents.IsInMainMenu || GameUtils.Gameplay.CallbackEvents.IsInQuickMenu)
      return;
    if (Input.GetKey((KeyCode) 306) && Input.GetKeyDown((KeyCode) 325))
      PlayerModule.Movement.ClickTP();
    if (Input.GetKey((KeyCode) 306) && Input.GetKeyDown((KeyCode) 102))
    {
      Config.Movement.fly = !Config.Movement.fly;
      UIRefs.Fly.SetState(Config.Movement.fly);
    }
    if (!Input.GetKeyDown((KeyCode) 286))
      return;
    PlayerModule.CCamera.CameraController();
  }

  private void CommandHandler()
  {
    if (!Input.GetKeyDown((KeyCode) 290))
      return;
    GameUtils.VRChatUtils.VRCKeyboard.InputPopup("Enter a Command ", (Action<string>) (id => { }), Placeholder: "type *help", MultiLine: false);
  }
}
