
using Brewchat.Game.Wrappers;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

#nullable enable
namespace Brewchat.Game.Monobehaviours;

public class CameraModule : MonoBehaviour
{
  private float targetFOV;
  private float CacheFOV;
  public float zoomedFOV = 30f;
  private float zspeed = 5f;

  private Camera[]? Cameras { get; set; }

  private void Start()
  {
    if (Object.op_Inequality((Object) Camera.main, (Object) null))
      this.CacheFOV = Camera.main.fieldOfView;
    this.targetFOV = this.CacheFOV;
    this.Cameras = Il2CppArrayBase<Camera>.op_Implicit((Il2CppArrayBase<Camera>) Camera.allCameras);
  }

  private void Update()
  {
    this.targetFOV = Input.GetKey((KeyCode) 308) ? this.zoomedFOV : this.CacheFOV;
    ((IEnumerable<Camera>) this.Cameras).ToList<Camera>().ForEach((Action<Camera>) (x => x.fieldOfView = Mathf.Lerp(GameUtils.Camera.Get.fieldOfView, this.targetFOV, Time.deltaTime * this.zspeed)));
  }
}
