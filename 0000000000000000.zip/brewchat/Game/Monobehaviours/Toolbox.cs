
using Brewchat.Game.Wrappers;
using brewchat.hybridxcore.bep.Properties;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

#nullable enable
namespace Brewchat.Game.Monobehaviours;

internal class Toolbox : MonoBehaviour
{
  public static Toolbox? Instance { get; private set; }

  private void Awake()
  {
    if (Toolbox.Instance == null)
    {
      Toolbox.Instance = this;
      Object.DontDestroyOnLoad((Object) this);
    }
    else
      Object.Destroy((Object) this);
  }

  public void PopUpLoading()
  {
    GameUtils.UI.HUD.LoadingPopUp("", "", "", (Action) null, (Action<VRCUiPopup>) null);
  }

  public void PopUp2Loading()
  {
    GameUtils.UI.HUD.LoadingPopUp2("", "", "", (Action) null, (Action<VRCUiPopup>) null);
  }

  public static void LoadMyUI()
  {
    ((Behaviour) EngineUtils.Assets.AssetBundle(new Uri("https://cdn.discordapp.com/attachments/1365105880965713960/1365105938251386890/intro?ex=6832fdba&is=6831ac3a&hm=9d35ad83670e7d0ab3f01d835e16d77d3016b3f53028ca40125667940c960522&"), "february introduction", new bool?(false)).GetComponentInChildren<GraphicRaycaster>()).enabled = false;
  }

  public void LoadMyUI_Console()
  {
    GameObject gameObject = EngineUtils.Assets.INTERNAL_AssetBundle(Resources.assetbundle_console, "Console", new bool?(false));
    ((Object) gameObject).name = "[Console]";
    ((TMP_Text) ((Component) ((Component) gameObject.transform.FindChild("+Root+")).transform.FindChild("GroupLayout")).GetComponentInChildren<TextMeshProUGUI>()).text = (string) null;
  }
}
