
using System.Collections.Generic;
using TMPro;
using UnityEngine;

#nullable enable
namespace brewchat.hybridxcore.bep.Cheat.IMGUI;

public class LimeConsole
{
  private static List<string> TEXT_LIST = new List<string>();

  public static string Text(string text, Logging logtype)
  {
    LimeConsole.TEXT_LIST.Add($"[{logtype}] {text}");
    ((TMP_Text) ((Component) ((Component) GameObject.Find("[Console]").transform.FindChild("+Root+")).transform.FindChild("GroupLayout")).GetComponentInChildren<TextMeshProUGUI>()).text = string.Join("", (IEnumerable<string>) LimeConsole.TEXT_LIST);
    return text;
  }

  public static void Clear() => LimeConsole.TEXT_LIST.Clear();
}
