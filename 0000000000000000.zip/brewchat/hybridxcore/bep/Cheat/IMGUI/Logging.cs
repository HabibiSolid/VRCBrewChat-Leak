
#nullable disable
namespace brewchat.hybridxcore.bep.Cheat.IMGUI;

public enum Logging
{
  Debug,
  Error,
  Info,
  Player,
  Dectection,
  Operator,
  World,
  Udon,
  SDK3,
  Hooks,
  Photon,
  GameServer,
}
