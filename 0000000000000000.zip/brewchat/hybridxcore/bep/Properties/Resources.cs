
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace brewchat.hybridxcore.bep.Properties;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Resources
{
  private static ResourceManager resourceMan;
  private static CultureInfo resourceCulture;

  internal Resources()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager
  {
    get
    {
      if (brewchat.hybridxcore.bep.Properties.Resources.resourceMan == null)
        brewchat.hybridxcore.bep.Properties.Resources.resourceMan = new ResourceManager("brewchat.hybridxcore.bep.Properties.Resources", typeof (brewchat.hybridxcore.bep.Properties.Resources).Assembly);
      return brewchat.hybridxcore.bep.Properties.Resources.resourceMan;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo Culture
  {
    get => brewchat.hybridxcore.bep.Properties.Resources.resourceCulture;
    set => brewchat.hybridxcore.bep.Properties.Resources.resourceCulture = value;
  }

  internal static byte[] action_menu_bg
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject("action-menu_bg", brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] action_menu_divider
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject("action-menu_divider", brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] action_menu_joystick
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject("action-menu_joystick", brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] assetbundle_console
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject("assetbundle-console", brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] capsule_background
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (capsule_background), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] capsule_background_bar
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (capsule_background_bar), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] capsule_voice_glow
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (capsule_voice_glow), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] capsule_voice_glow_half
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (capsule_voice_glow_half), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] capsule_voice_glow_half_groups
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (capsule_voice_glow_half_groups), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] capsule_voice_pulse
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (capsule_voice_pulse), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] capsule_voice_pulse_left
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (capsule_voice_pulse_left), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static string D_Contact
  {
    get => brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetString("D-Contact", brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
  }

  internal static byte[] Logo
  {
    get => (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (Logo), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
  }

  internal static byte[] sprite_music
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (sprite_music), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] sprite_video
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (sprite_video), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }

  internal static byte[] sprite_video_slash
  {
    get
    {
      return (byte[]) brewchat.hybridxcore.bep.Properties.Resources.ResourceManager.GetObject(nameof (sprite_video_slash), brewchat.hybridxcore.bep.Properties.Resources.resourceCulture);
    }
  }
}
