
using Brewchat;
using Brewchat.Cheat;
using Brewchat.Cheat.Modules;
using Brewchat.Game.Monobehaviours;
using Brewchat.Game.Wrappers;
using brewchat.hybridxcore.bep.Cheat.IMGUI;
using ExitGames.Client.Photon;
using HarmonyLib;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Pasted.WTFBlaze.Utils.Managers;
using Photon.Realtime;
using Syrup.IMGUI;
using System;
using System.Text.Json;
using UnityEngine;
using UnityEngine.UI;
using VRC;
using VRC.Core;
using VRC.SDKBase;
using VRC.UI.Elements;
using VRC.UI.Elements.Menus;

#nullable enable
namespace brewchat.hybridxcore.bep;

[HarmonyPatch]
internal class Hooks
{
  private static bool OverlayLoadedLoaded;
  private static bool OfflineUILoaded;
  private static bool OnlineUILoaded;

  [HarmonyPostfix]
  [HarmonyPatch(typeof (VRCApplication), "Awake")]
  public static void DomainApp_Initialize_HOOK(ref VRCUiPageLoading? __instance)
  {
    if (__instance == null)
      return;
    VRCUiPageLoading vrcUiPageLoading1 = __instance;
    if (vrcUiPageLoading1 != null)
      ExtensionMethods.GetOrAddComponent<CSS>(((Component) vrcUiPageLoading1).gameObject);
    VRCUiPageLoading vrcUiPageLoading2 = __instance;
    if (vrcUiPageLoading2 != null)
      ExtensionMethods.GetOrAddComponent<GifLoader>(((Component) vrcUiPageLoading2).gameObject);
    ExtensionMethods.GetOrAddComponent<KeybindManager>(((Component) __instance).gameObject);
    ExtensionMethods.GetOrAddComponent<Toolbox>(((Component) __instance).gameObject);
    Toolbox.Instance?.LoadMyUI_Console();
    CSS.Offline();
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (LoadingOverlayController), "Start")]
  public static void FlatLoadingOverlay_Initialize_HOOK(ref LoadingOverlayController __instance)
  {
    if (__instance == null && !Hooks.OverlayLoadedLoaded)
      return;
    Image component = ((Component) ((Component) ((Component) __instance).gameObject.transform.Find("FlatLoadingOverlay(Clone)/Container")).transform.FindChild("Canvas/Background")).GetComponent<Image>();
    Hooks.OverlayLoadedLoaded = true;
    if (Config.Appearance.Hiders.HideLoadingOverlay)
    {
      Object.DestroyImmediate((Object) component, true);
    }
    else
    {
      if (Config.Appearance.FlatLoadingOverlay == null)
        return;
      ((Graphic) component).color = new Color(0.0f, 0.0f, 0.0f, 0.9f);
      GifLoader.Instance.AddAnimatedGif(GifLoader.CreateIsolatedImage(component), new Uri(Config.Appearance.FlatLoadingOverlay));
    }
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (VRCUiPageLoading), "OnEnable")]
  public static void VRCLoadingSequence_IsEnable_HOOK(ref VRCUiPageLoading? __instance)
  {
    if (__instance == null && !Hooks.OfflineUILoaded)
      return;
    CSS.Offline();
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (VRCUiPageLoading), "Start")]
  public static void VRCLoadingSequence_Initialize_HOOK(ref VRCUiPageLoading? __instance)
  {
    if (__instance == null && !Hooks.OfflineUILoaded)
      return;
    Object.DestroyImmediate((Object) ((Component) ((Component) __instance).gameObject.transform.GetChild(1)).GetComponent<AudioSource>());
    EngineUtils.Assets.CreateAudio(new Uri(Config.Appearance.QueueAudio)).transform.parent = ((Component) __instance).gameObject.transform;
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (QuickMenu), "Start")]
  public static void QuickMenu_Initialize_HOOK(ref QuickMenu? __instance)
  {
    if (Object.op_Equality((Object) __instance, (Object) null) && !Hooks.OnlineUILoaded)
      return;
    Object.DestroyImmediate((Object) Object.FindObjectOfType<MainMenuContent>()._bannerCarousel, true);
    Widgets.QM.Initalize();
    QM._Pinkstar.Apply();
    QM.SelectedMenu.Apply();
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (MainMenu), "Start")]
  public static void MainMenu_Initialize_HOOK(ref MainMenu? __instance)
  {
    if (Object.op_Equality((Object) __instance, (Object) null) && !Hooks.OnlineUILoaded)
      return;
    MM._Pinkstar.Apply();
    MM.SelectedUserMenu.Apply();
    MM.AvatarAVMMenu.Apply();
    MM.SelectedWorldMenu.Apply();
    Console.Clear();
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (VRCUIBackground), "Start")]
  public static void QuickMenuBackground_Initialize_HOOK(ref VRCUIBackground? __instance)
  {
    if (Object.op_Equality((Object) __instance, (Object) null) && !Hooks.OnlineUILoaded)
      return;
    Hooks.OnlineUILoaded = true;
    CSS.Online();
  }

  [HarmonyPostfix]
  [HarmonyPatch]
  public static void ExSpoof_VRChatPlus_HOOK(ref Object1PublicTBoTUnique<bool> __result)
  {
    if (__result == null || APIUser.CurrentUser.isSupporter)
      return;
    __result.field_Protected_T_0 = true;
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (NetworkManager), "OnPlayerJoined")]
  public static void PlayerJoined_HOOK(Player __0)
  {
    if (!Object.op_Inequality((Object) __0, (Object) null) || __0.APIUser.IsSelf)
      return;
    Player player = __0;
    if (!player.APIUser.allowAvatarCopying)
      player.APIUser.allowAvatarCopying = true;
    LimeConsole.Text($"Player Joined: <color=#ff0000>[{player.IsAdult()}]</color> <color=#{EngineUtils.Conversion.ColorToHex(player.GetTrustColor())}>[{player.GetTrustRank()}]</color> {player.VRCPlayerApi.displayName} : ({((ApiModel) player.APIUser).id}) | ACTOR: {player.VRCPlayerApi.playerId}", brewchat.hybridxcore.bep.Cheat.IMGUI.Logging.GameServer);
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (NetworkManager), "OnPlayerLeave")]
  public static void PlayerLeft_HOOK(Player __0)
  {
    if (!Object.op_Inequality((Object) __0, (Object) null) || __0.APIUser.IsSelf)
      return;
    Player player = __0;
    LimeConsole.Text($"Player Left: {player.VRCPlayerApi.displayName} : ({((ApiModel) player.APIUser).id})", brewchat.hybridxcore.bep.Cheat.IMGUI.Logging.GameServer);
  }

  [HarmonyPostfix]
  [HarmonyPatch(typeof (LoadBalancingClient), "OnEvent")]
  public static void __PhotonLogging_HOOK(EventData __0)
  {
    if (__0 == null && __0.CustomData == null || !Config.Logging.Photon)
      return;
    bool flag = false;
    foreach (KeyValuePair<byte, Object> parameter in __0.Parameters)
    {
      if (!flag)
      {
        string str = JsonSerializer.Serialize<object>(SerializationManager.FromIL2CPPToManaged<object>(parameter.Value), new JsonSerializerOptions()
        {
          AllowTrailingCommas = true
        });
        sconsole.print("hook", "/photon", $" Player: {GameUtils.PlayerModel.GetPlayerFromActor(__0.Sender)?.VRCPlayerApi.displayName} Sent! | EV {__0.Code} [Key:{__0.CustomDataKey}] Event Data: \n {str}", 0);
        flag = true;
      }
    }
  }

  [HarmonyPrefix]
  [HarmonyPatch(typeof (VRC_EventDispatcherRFC), "Method_Public_Void_Player_VrcEvent_VrcBroadcastType_Int32_Single_0")]
  private static bool __RFCPatch_HOOK(
    ref Player __0,
    ref VRC_EventHandler.VrcEvent __1,
    ref VRC_EventHandler.VrcBroadcastType __2,
    ref int __3,
    ref float __4)
  {
    if (Config.Exploits.RPC_ForceGlobal || !(__0?.VRCPlayerApi?.displayName == APIUser.CurrentUser?.displayName))
      return true;
    // ISSUE: cast to a reference type
    // ISSUE: explicit reference operation
    ^(int&) ref __2 = 4;
    return true;
  }
}
