
using UnityEngine;

#nullable disable
namespace brewchat.hybridxcore.bep.Game.Monobehaviours;

public class PlayerDataInfo : MonoBehaviour
{
  public void Start()
  {
  }

  private void LateUpdate()
  {
  }
}
