
using UnityEngine;

#nullable disable
namespace brewchat.hybridxcore.bep.Game.Monobehaviours;

public class ThirdPersonController : MonoBehaviour
{
  public static void Start()
  {
  }
}
