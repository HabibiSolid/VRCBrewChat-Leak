
using Brewchat.Game.Wrappers;
using brewchat.hybridxcore.bep.Properties;
using UnityEngine;
using UnityEngine.UI;

#nullable disable
namespace brewchat.hybridxcore.bep.Game.Monobehaviours;

public class Nameplates : MonoBehaviour
{
  private void Start() => this.SetupPlayerInfo();

  public void SetupPlayerInfo()
  {
    Transform transform = ((Component) this).gameObject.transform.Find("PlayerNameplate/Canvas/NameplateGroup/Nameplate/Contents");
    Color trustColor = VRCPlayer.GetTrustColor(GameUtils.PlayerModel.Get().APIUser);
    ((Graphic) ((Component) transform.Find("Main/Background")).GetComponent<ImageThreeSlice>()).color = trustColor;
    ((Graphic) ((Component) transform.Find("Main/Pulse")).GetComponent<ImageThreeSlice>()).color = trustColor;
    ImageThreeSlice component1 = ((Component) transform.Find("Main/Glow")).GetComponent<ImageThreeSlice>();
    Image component2 = ((Component) transform.Find("Icon/Background")).GetComponent<Image>();
    ((Graphic) ((Component) transform.Find("Icon/Pulse")).GetComponent<ImageThreeSlice>()).color = trustColor;
    ((Graphic) ((Component) transform.Find("Icon/Glow")).GetComponent<ImageThreeSlice>()).color = trustColor;
    ((Graphic) ((Component) transform.Find("Quick Stats")).GetComponent<ImageThreeSlice>()).color = trustColor;
    ((Graphic) component2).color = trustColor;
    ((Graphic) component1).color = trustColor;
    component2.overrideSprite = EngineUtils.Assets.INTERNAL_Texture(Resources.capsule_background_bar).ToSprite();
  }
}
