
using BlanketSDK.Core;
using BlanketSDK.MM.Elements;
using BlanketSDK.MM.Elements.Controls;
using BlanketSDK.MM.Elements.Controls.AvatarMenu;
using BlanketSDK.Utilities;
using Brewchat.Game.Wrappers;
using brewchat.hybridxcore.bep.Properties;
using Brewchat.Wrappers;
using Syrup.IMGUI;
using System;
using UnityEngine;
using Visionary;

#nullable enable
namespace Brewchat.Cheat;

internal class MM : IMainMenuElements
{
  public class _Pinkstar
  {
    public static void Apply()
    {
      try
      {
        VRCPage page = new VRCPage("Astriek", EngineUtils.Assets.INTERNAL_Texture(Resources.Logo).ToSprite());
        VRCTab vrcTab = new VRCTab(page, "Astriek", "The passion project.", sprite: EngineUtils.Assets.INTERNAL_Texture(Resources.Logo).ToSprite());
        VRCWingButton vrcWingButton = new VRCWingButton(IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_WingButtons("Left"), SDKUtils.Wing.Position.Left, "Test", "Test", (Action) (() => { }));
        VRCSmallButton vrcSmallButton = new VRCSmallButton(IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_ExpandButtons(), "The passion project.", 5, (Action) (() => GameUtils.UI.HUD.Alert("bitch2")), EngineUtils.Assets.INTERNAL_Texture(Resources.Logo).ToSprite());
        VRCCellContainer Menu1 = new VRCCellContainer(page, "Properties [QOL]");
        VRCCellContainer Menu2 = new VRCCellContainer(page, "HANDLERS [PERFORMANCE]");
        VRCCellContainer Menu3 = new VRCCellContainer(page, "Music");
        VRCCellButton vrcCellButton1 = new VRCCellButton(page, Menu1, "Properties", "[Properties]");
        VRCCellButton vrcCellButton2 = new VRCCellButton(page, Menu2, "Handlers", "[Handlers]");
        VRCCellButton vrcCellButton3 = new VRCCellButton(page, Menu3, "Music", "[Music]", AstriekLib.Sprites.Music());
      }
      catch (Exception ex)
      {
        sconsole.print($"{ex.Message}\n{ex.Source}", 2);
      }
      finally
      {
        sconsole.print("Created The MainMenu+BlanketSDK.UI", 1);
      }
    }
  }

  public class AvatarAVMMenu
  {
    public static void Apply()
    {
      VRCAvatarButtonSmall avatarButtonSmall = new VRCAvatarButtonSmall("AvatarSwitchID", "Select Avatar Through ID", (Action) (() => GameUtils.VRChatUtils.VRCKeyboard.InputPopup("Change Avatar", (Action<string>) (id => GameUtils.PlayerModel.Avatar.SetAvatar(id)), Placeholder: "avtr_*", MultiLine: false)), EngineUtils.Assets.INTERNAL_Texture(Resources.Logo).ToSprite());
      VRCAvatarButton vrcAvatarButton = new VRCAvatarButton("GetAvatarID", "Get Avatar ID", (Action) (() => { }), EngineUtils.Assets.INTERNAL_Texture(Resources.Logo).ToSprite(), 5);
    }
  }

  public class SelectedUserMenu : IMainMenuElements
  {
    public static void Apply()
    {
      try
      {
        VRCBigButton vrcBigButton1 = new VRCBigButton(new VRCRowGroup(IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_ProfileRows(), "Astriek Actions"), "Teleport", "Teleport to this player's Position", (Action) (() => ((Component) GameUtils.PlayerModel.Get()).transform.position = ((Component) GameUtils.PlayerModel.Matchmaking.GetSelectedUser()).transform.position));
        VRCBigButton vrcBigButton2 = new VRCBigButton(new VRCRowGroup(IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_ProfileRows(), "<color=red>Astriek</color>"), "Give Tag", "Give a Specific Tag to User", (Action) (() => Vision.API.GiveTag()));
      }
      catch (Exception ex)
      {
        sconsole.print($"{ex.Message}\n{ex.Source}", 2);
      }
      finally
      {
        sconsole.print("Created The Selected_MainMenu+BlanketSDK.UI", 1);
      }
    }
  }

  public class SelectedWorldMenu : IMainMenuElements
  {
    public static void Apply()
    {
      VRCBigButton vrcBigButton = new VRCBigButton(IMainMenuElements.MMElements.WorldRow(), "Get World ID", "Get World ID", (Action) (() => Console.WriteLine("WORLD ID: " + GameUtils.World.GetID())));
    }
  }
}
