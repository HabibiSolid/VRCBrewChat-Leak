
using BlanketSDK.Origin.Elements.Controls;
using System;
using UnityEngine;

#nullable disable
namespace Brewchat.Cheat;

public class Origin
{
  public static void Apply()
  {
    OButton obutton = new OButton(((Component) VRCUiManager.field_Private_Static_VRCUiManager_0).transform.FindChild("MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress"), 1.5f, 1.5f, "End Mission", (Action) (() => Entry.Console.LogMessage((object) "Disposable Waste")));
  }
}
