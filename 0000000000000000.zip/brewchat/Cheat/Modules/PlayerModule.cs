
using Brewchat.Game.Monobehaviours;
using Brewchat.Game.Wrappers;
using Brewchat.Wrappers;
using Syrup.IMGUI;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VRC;
using VRC.Animation;
using VRC.Core;
using VRC.SDKBase;

#nullable enable
namespace Brewchat.Cheat.Modules;

internal class PlayerModule
{
  public class Movement
  {
    private static readonly List<string> _disabledColliders = new List<string>();
    private static Coroutine _spinbotCoroutine;

    public static void Fly()
    {
      Player player = GameUtils.PlayerModel.Get();
      if (!Object.op_Implicit((Object) player) && !GameUtils.World.IsLoaded())
        return;
      VRCMotionState component1 = ((Component) player).GetComponent<VRCMotionState>();
      FlyManager orAddComponent = ExtensionMethods.GetOrAddComponent<FlyManager>(((Component) player).gameObject);
      CharacterController component2 = ((Component) player).GetComponent<CharacterController>();
      if (Config.Movement.fly)
      {
        ((Behaviour) orAddComponent).enabled = true;
        ((Collider) component2).enabled = false;
        foreach (Collider collider in ((IEnumerable<Collider>) ((Component) player).GetComponents<Collider>()).ToList<Collider>())
        {
          if (!PlayerModule.Movement._disabledColliders.Contains(((Object) ((Component) collider).gameObject).name))
            PlayerModule.Movement._disabledColliders.Add(((Object) ((Component) collider).gameObject).name);
        }
      }
      else
      {
        ((Behaviour) orAddComponent).enabled = true;
        ((Collider) component2).enabled = true;
        component1.Reset();
        Object.DestroyImmediate((Object) orAddComponent);
      }
      sconsole.print($"[LOCAL_PLAYER] Fly is Set to {Config.Movement.fly}", 1);
      GameUtils.UI.HUD.ToastV2("Player+Movement", $"Fly is set to {Config.Movement.fly}");
      GameUtils.UI.HUD.Alert($"Fly is set to {Config.Movement.fly}");
    }

    public static void ForceJump(bool state)
    {
      Player player = GameUtils.PlayerModel.Get();
      VRCPlayerApi vrcPlayerApi = GameUtils.PlayerModel.Motion.Networking.Jump_Impulse();
      float jumpImpulse = vrcPlayerApi.GetJumpImpulse();
      if (!Object.op_Implicit((Object) player) && !GameUtils.World.IsLoaded())
        return;
      if (state)
        vrcPlayerApi.SetJumpImpulse(3f);
      else
        vrcPlayerApi.SetJumpImpulse(jumpImpulse);
      sconsole.print($"Jump+Impulse is set to {state}", 1);
      GameUtils.UI.HUD.ToastV2("Player+Movement", $"Jump+Impulse is set to {state}");
      GameUtils.UI.HUD.Alert($"Jump+Impulse is set to {state}");
    }

    public static void ClickTP()
    {
      Player player = GameUtils.PlayerModel.Get();
      RaycastHit raycastHit;
      if (!Object.op_Implicit((Object) player) && !GameUtils.World.IsLoaded() || GameUtils.Gameplay.CallbackEvents.IsInMainMenu || !Physics.Raycast(((Component) GameUtils.Camera.Get).transform.position, ((Component) GameUtils.Camera.Get).transform.forward, ref raycastHit))
        return;
      ((Component) player).transform.position = ((RaycastHit) ref raycastHit).point;
    }
  }

  public class CCamera
  {
    private static int currentView = -1;
    public static Camera[]? camera = new Camera[3];

    private static Camera MakeCameras(PlayerModule.CCamera.View view)
    {
      GameObject gameObject = new GameObject($"{view}_Camera");
      gameObject.AddComponent<UniversialTags>().AddTagToObject("V-Cams");
      if (Object.op_Inequality((Object) GameUtils.Camera.Get, (Object) null))
      {
        Camera get = GameUtils.Camera.Get;
        if (Object.op_Inequality((Object) get, (Object) null))
        {
          gameObject.transform.localScale = ((Component) get).transform.localScale;
          gameObject.transform.parent = ((Component) get).transform;
          gameObject.transform.rotation = ((Component) get).transform.rotation;
          Camera camera = gameObject.AddComponent<Camera>();
          camera.fieldOfView = get.fieldOfView;
          camera.nearClipPlane /= 4f;
          if (Object.op_Inequality((Object) get, (Object) null))
            camera.cullingMask = -524289;
          switch (view)
          {
            case PlayerModule.CCamera.View.second_person:
              gameObject.transform.Rotate(new Vector3(0.0f, 180f, 0.0f));
              gameObject.transform.position = Vector3.op_Addition(((Component) get).transform.position, Vector3.op_Multiply(((Component) get).transform.forward, 2f));
              return camera;
            case PlayerModule.CCamera.View.third_person:
              gameObject.transform.Rotate(Vector3.zero);
              gameObject.transform.position = Vector3.op_Addition(((Component) get).transform.position, Vector3.op_Multiply(Vector3.op_UnaryNegation(((Component) get).transform.forward), 2f));
              return camera;
            case PlayerModule.CCamera.View.freecam:
              gameObject.transform.parent = (Transform) null;
              gameObject.transform.position = Vector3.op_Addition(((Component) get).transform.position, Vector3.op_Multiply(Vector3.op_UnaryNegation(gameObject.transform.forward), 2f));
              gameObject.AddComponent<AudioListener>();
              gameObject.AddComponent<FlyManager>().AllowRotation = true;
              gameObject.transform.position = GameUtils.PlayerModel.Get().VRCPlayerApi.GetBonePosition((HumanBodyBones) 10);
              return camera;
          }
        }
      }
      return (Camera) null;
    }

    public static void CameraController()
    {
      if (PlayerModule.CCamera.camera == null)
        PlayerModule.CCamera.camera = new Camera[3];
      if (Object.op_Equality((Object) PlayerModule.CCamera.camera[0], (Object) null) && Object.op_Equality((Object) PlayerModule.CCamera.camera[1], (Object) null) && Object.op_Equality((Object) PlayerModule.CCamera.camera[2], (Object) null))
      {
        PlayerModule.CCamera.camera[0] = PlayerModule.CCamera.MakeCameras(PlayerModule.CCamera.View.third_person);
        PlayerModule.CCamera.camera[1] = PlayerModule.CCamera.MakeCameras(PlayerModule.CCamera.View.second_person);
        PlayerModule.CCamera.camera[2] = PlayerModule.CCamera.MakeCameras(PlayerModule.CCamera.View.freecam);
      }
      Widgets.QM.cameramode_widget.SetState(true);
      PlayerModule.CCamera.currentView = (PlayerModule.CCamera.currentView + 1) % 4;
      if (!Object.op_Inequality((Object) PlayerModule.CCamera.camera[0], (Object) null) || !Object.op_Inequality((Object) PlayerModule.CCamera.camera[1], (Object) null) || !Object.op_Inequality((Object) PlayerModule.CCamera.camera[2], (Object) null))
        return;
      Sprite sprite1 = AstriekLib.Sprites.Video();
      Sprite sprite2 = AstriekLib.Sprites.Video(false);
      switch (PlayerModule.CCamera.currentView)
      {
        case 0:
          Widgets.QM.cameramode_widget.SetText("Third Person");
          GameUtils.UI.HUD.ToastV1("Third Person Activated!", sprite: sprite1);
          ((Behaviour) PlayerModule.CCamera.camera[0]).enabled = true;
          ((Behaviour) PlayerModule.CCamera.camera[1]).enabled = false;
          ((Behaviour) PlayerModule.CCamera.camera[2]).enabled = false;
          break;
        case 1:
          Widgets.QM.cameramode_widget.SetText("Second Person");
          GameUtils.UI.HUD.ToastV1("Second Person Activated!", sprite: sprite1);
          ((Behaviour) PlayerModule.CCamera.camera[0]).enabled = false;
          ((Behaviour) PlayerModule.CCamera.camera[1]).enabled = true;
          ((Behaviour) PlayerModule.CCamera.camera[2]).enabled = false;
          break;
        case 2:
          Widgets.QM.cameramode_widget.SetText("FreeCam");
          GameUtils.UI.HUD.ToastV1("FreeCam Activated! Right Click (To Move Camera)", sprite: sprite1);
          ((Behaviour) PlayerModule.CCamera.camera[0]).enabled = false;
          ((Behaviour) PlayerModule.CCamera.camera[1]).enabled = false;
          ((Behaviour) PlayerModule.CCamera.camera[2]).enabled = true;
          break;
        case 3:
          GameUtils.UI.HUD.ToastV1("Cameras Destoryed", sprite: sprite2);
          PlayerModule.CCamera.DestoryCameras();
          Widgets.QM.cameramode_widget.SetState(false);
          break;
      }
    }

    public static void DestoryCameras() => UniversialTags.Destory("V-Cams");

    public enum View
    {
      second_person,
      third_person,
      freecam,
    }
  }

  public static class Body
  {
    private static GameObject AvatarObj;

    public static GameObject Clone(Player player)
    {
      player._vrcplayer.VRCPlayerApi.GetBoneTransform((HumanBodyBones) 10).localScale = new Vector3(1f, 1f, 1f);
      if (Object.op_Equality((Object) PlayerModule.Body.AvatarObj, (Object) null))
      {
        PlayerModule.Body.AvatarObj = Object.Instantiate<GameObject>(player._vrcplayer.field_Private_VRCAvatarManager_0.field_Private_GameObject_0);
        PlayerModule.Body.AvatarObj.transform.position = ((Component) player).transform.position;
      }
      return PlayerModule.Body.AvatarObj;
    }
  }
}
