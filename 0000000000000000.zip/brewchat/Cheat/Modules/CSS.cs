
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using Brewchat.Game.Wrappers;
using brewchat.hybridxcore.bep.Properties;
using Il2CppInterop.Runtime.InteropTypes;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using MaterialEditing.UI;
using Syrup.IMGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Core.Styles;
using VRC.UI.Elements;

#nullable enable
namespace Brewchat.Cheat.Modules;

internal class CSS : MonoBehaviour
{
  public static PlayerNameplate _nameplate;

  public static CSS? Instance { get; private set; }

  private void Awake()
  {
    if (CSS.Instance == null)
    {
      CSS.Instance = this;
      Object.DontDestroyOnLoad((Object) this);
    }
    else
      Object.Destroy((Object) this);
  }

  public static void Offline()
  {
    ((IEnumerable<Button>) Object.FindObjectsOfType<Button>()).ToList<Button>().ForEach((Action<Button>) (button_colors =>
    {
      ColorBlock colors = ((Selectable) button_colors).colors;
      ((ColorBlock) ref colors).normalColor = EngineUtils.Conversion.HexToColor("#c60e7b");
      ((ColorBlock) ref colors).highlightedColor = EngineUtils.Conversion.HexToColor("#ff14a0");
      ((ColorBlock) ref colors).selectedColor = EngineUtils.Conversion.HexToColor("#c60e7b");
      ((ColorBlock) ref colors).disabledColor = Color.white;
      ((Selectable) button_colors).colors = colors;
    }));
  }

  public static void Online()
  {
    foreach (GameObject advancedMenu in Templates.AdvancedMenus)
    {
      VRCUIBackground componentInChildren = advancedMenu.GetComponentInChildren<VRCUIBackground>();
      if (componentInChildren == null)
        return;
      Texture texture = (Texture) EngineUtils.Assets.Texture(new Uri("https://github.com/riotlu/fake-cdn/blob/master/FurryOrgy_1.png?raw=true"));
      Material material = ((Graphic) componentInChildren.field_Private_Image_0).material;
      material.mainTexture = texture;
      material.Background_Parallax(texture);
    }
    foreach (Transform actionMenu in IActionMenuElements.ActionMenus())
    {
      if (Object.op_Inequality((Object) actionMenu, (Object) null))
      {
        IEnumerable ienumerable = ((Il2CppObjectBase) ((Component) actionMenu).transform.GetChild(0).GetChild(2)).Cast<IEnumerable>();
        if (ienumerable == null)
        {
          sconsole.print("Container children collection is null", 2);
          return;
        }
        foreach (Object @object in ienumerable)
        {
          if (@object != null)
          {
            Transform transform = ((Il2CppObjectBase) @object).Cast<Transform>();
            if (!Object.op_Equality((Object) transform, (Object) null))
            {
              foreach (Component component in ((IEnumerable<Transform>) ((Component) transform).GetComponentsInChildren<Transform>(true)).Where<Transform>((Func<Transform, bool>) (t => Object.op_Inequality((Object) t, (Object) null) && ((Object) t).name == "Divider(Clone)")).ToArray<Transform>())
              {
                Image componentInChildren = component.GetComponentInChildren<Image>(true);
                if (Object.op_Inequality((Object) componentInChildren, (Object) null))
                {
                  ((Graphic) componentInChildren).color = Config.Appearance.Platte.Main;
                  componentInChildren.sprite = EngineUtils.Assets.INTERNAL_Texture(Resources.action_menu_divider).ToSprite();
                }
              }
            }
          }
        }
        PedalGraphic component1 = ((Component) ((Component) actionMenu).transform.GetChild(0).GetChild(1)).GetComponent<PedalGraphic>();
        component1._texture = (Texture) EngineUtils.Assets.INTERNAL_Texture(Resources.action_menu_bg);
        ((Graphic) component1).color = EngineUtils.Conversion.HexToColor("#c60e7b");
        Image component2 = ((Component) ((Component) actionMenu).transform.GetChild(0).GetChild(4)).GetComponent<Image>();
        component2.sprite = EngineUtils.Assets.INTERNAL_Texture(Resources.action_menu_joystick).ToSprite();
        ((Graphic) component2).color = EngineUtils.Conversion.HexToColor("#c60e7b");
        Object.DestroyImmediate((Object) ((Component) ((Component) actionMenu).transform.GetChild(0).GetChild(0)).GetComponent<PedalGraphic>(), true);
      }
    }
    foreach (StyleEngine styleEngine in Object.FindObjectsOfType<StyleEngine>())
    {
      foreach (KeyValuePair<string, Color> keyValuePair in styleEngine.field_Private_Dictionary_2_String_Color_0)
        keyValuePair.Key.Contains("Active");
      styleEngine.field_Private_Dictionary_2_String_Color_0["Highlight"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["Active"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["Active2"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["BottomTabSelected"] = new Color(0.9f, 0.1f, 0.8f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Subheader"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["Hover"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["ActiveDark"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["BottomTabHover"] = new Color(0.8f, 0.3f, 0.5f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["IconActive"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["IconWhite"] = new Color(0.95f, 0.95f, 0.95f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["IconHover"] = new Color(1f, 0.8f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["CategorySelectorIcon"] = new Color(0.8f, 0.3f, 0.5f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["IconHighlight"] = new Color(1f, 0.5f, 0.0f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["IconInactive"] = new Color(0.6f, 0.6f, 0.6f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["IconGrey"] = new Color(0.5f, 0.5f, 0.5f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["NavigationButton"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["ButtonHover"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["ButtonHoverTeal"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["ButtonBorder"] = new Color(0.3f, 0.3f, 0.3f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["ButtonHighlight"] = new Color(0.9f, 0.7f, 0.1f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["ButtonBg"] = new Color(0.15f, 0.15f, 0.15f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["ButtonCell"] = new Color(0.25f, 0.25f, 0.25f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["ButtonQMSelected"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["WingBG"] = new Color(0.12f, 0.12f, 0.15f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["ButtonOutline"] = new Color(0.4f, 0.4f, 0.4f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["WhiteBG"] = new Color(0.9f, 0.9f, 0.9f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["NavigationBG"] = new Color(0.18f, 0.18f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Outline"] = new Color(0.7f, 0.7f, 0.7f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["BG"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["MenuBG"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["BottomTab"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["Backgrounds"] = EngineUtils.Conversion.HexToColor("#c60e7b");
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font1"] = new Color(0.9f, 0.9f, 0.9f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font2"] = new Color(0.8f, 0.8f, 0.8f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font3"] = new Color(0.7f, 0.7f, 0.7f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font4"] = new Color(0.6f, 0.6f, 0.6f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font5"] = new Color(0.5f, 0.5f, 0.5f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font6"] = new Color(0.4f, 0.4f, 0.4f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font7"] = new Color(0.85f, 0.7f, 0.5f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font8"] = new Color(0.7f, 0.5f, 0.85f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font9"] = new Color(0.5f, 0.85f, 0.7f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font10"] = new Color(0.6f, 0.8f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font11"] = new Color(0.2f, 0.6f, 0.8f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Font12"] = new Color(0.8f, 0.2f, 0.6f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Subtext1"] = new Color(0.78f, 0.75f, 0.82f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Subtext2"] = new Color(0.65f, 0.65f, 0.7f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Subtext3"] = new Color(0.55f, 0.55f, 0.6f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Subtext4"] = new Color(0.5f, 0.5f, 0.55f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Trusted"] = new Color(0.2f, 0.4f, 1f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Known"] = new Color(0.3f, 0.8f, 0.4f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["AlertBg"] = new Color(0.9f, 0.2f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["NegativeBalance"] = new Color(0.95f, 0.3f, 0.3f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["PositiveBalance"] = new Color(0.3f, 0.95f, 0.3f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["VRCPlusTutorial"] = new Color(0.95f, 0.8f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Yellow"] = new Color(1f, 0.92f, 0.16f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Blue"] = new Color(0.15f, 0.6f, 0.95f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["TextHighlight"] = new Color(0.9f, 0.9f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Notification"] = new Color(1f, 0.3f, 0.3f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["DisabledRedBg"] = new Color(0.5f, 0.2f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["FriendRequest"] = new Color(0.1f, 0.7f, 0.3f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["VRChatPlusYellow"] = new Color(1f, 0.84f, 0.0f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["FriendSafeAlert"] = new Color(0.2f, 0.8f, 0.8f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["DiscountBG"] = new Color(0.2f, 0.5f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Black"] = new Color(0.05f, 0.05f, 0.05f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["NearBlack"] = new Color(0.1f, 0.1f, 0.1f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Grey1"] = new Color(0.2f, 0.2f, 0.2f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Grey2"] = new Color(0.3f, 0.3f, 0.3f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Grey3"] = new Color(0.4f, 0.4f, 0.4f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Grey4"] = new Color(0.5f, 0.5f, 0.5f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["Grey5"] = new Color(0.6f, 0.6f, 0.6f, 1f);
      styleEngine.field_Private_Dictionary_2_String_Color_0["White"] = Color.white;
    }
  }
}
