
using BlanketSDK.Core;
using BlanketSDK.QM.Elements;
using BlanketSDK.QM.Elements.Controls;
using BlanketSDK.QM.Elements.Controls.V2;
using BlanketSDK.QM.Elements.Modals;
using BlanketSDK.QM.Elements.V2;
using BlanketSDK.Utilities;
using BlanketSDK.Utilities.VRC;
using Brewchat.Cheat.Modules;
using Brewchat.Game.Wrappers;
using brewchat.hybridxcore.bep.Cheat.IMGUI;
using brewchat.hybridxcore.bep.Properties;
using Syrup.IMGUI;
using System;
using UnityEngine;
using VRC;
using VRC.Networking;

#nullable disable
namespace Brewchat.Cheat;

internal class QM
{
  public class _Pinkstar
  {
    public static void Apply()
    {
      try
      {
        VRCPage page = new VRCPage("Astriek");
        VRCTab vrcTab = new VRCTab(page, "The passion project.", sprite: EngineUtils.Assets.INTERNAL_Texture(Resources.Logo).ToSprite());
        VRCWingButton vrcWingButton1 = new VRCWingButton((Transform) null, SDKUtils.Wing.Position.Left, "Astriek", "The passion project.", (Action) (() => sconsole.print("passion_fruit", 1)));
        VRCWingButton vrcWingButton2 = new VRCWingButton((Transform) null, SDKUtils.Wing.Position.Right, "Astriek", "The passion project.", (Action) (() => sconsole.print("passion_fruit", 1)));
        VRCGroupLayout vrcGroupLayout = new VRCGroupLayout(page, "Main");
        VRCModalContainer vrcModalContainer = new VRCModalContainer("Player+Movement");
        vrcGroupLayout.AddButton("Player", "Modify The Player", new Action(vrcModalContainer.Open), true);
        VRCSmallButton vrcSmallButton1 = new VRCSmallButton(vrcModalContainer, "Injection", (Action) (() => sconsole.print("passion_fruit", 1)));
        UIRefs.Fly = vrcModalContainer.AddToggle("Fly", "Turn Fly On", "Turn Fly Off", (Action<bool>) (x =>
        {
          Config.Movement.fly = !Config.Movement.fly;
          PlayerModule.Movement.Fly();
        }));
        vrcModalContainer.AddToggle("Force Jump", "Force Jump Off", "Fly Off", (Action<bool>) (x => PlayerModule.Movement.ForceJump(x)));
        vrcModalContainer.AddToggle("Ghost", "Booo I'm a ghostttt", "awh I'm solid again", (Action<bool>) (x =>
        {
          Widgets.QM.ghostmode_widget.SetState(x);
          Player player = GameUtils.PlayerModel.Get();
          GameObject gameObject = PlayerModule.Body.Clone(player);
          if (Object.op_Inequality((Object) gameObject, (Object) null) && !x)
            Object.Destroy((Object) gameObject);
          ((Behaviour) ((Component) player).GetComponent<FlatBufferNetworkSerializer>()).enabled = !x;
        }));
        VRCModalContainer Logging = new VRCModalContainer("Logging");
        VRCButton vrcButton = new VRCButton(vrcGroupLayout, "Logging", "Configure Logging", (Action) (() => Logging.Open()), true);
        Logging.AddMiniButton("Configure Events List", (Action) (() => Console.Beep()));
        Logging.AddMiniButton("Configure RPCs List", (Action) (() => Console.Beep()));
        Logging.AddMiniButton("Configure Udon Events List", (Action) (() => Console.Beep()));
        Logging.AddToggle("RPC", "parse", "parse", (Action<bool>) (x => Config.Logging.RPC = !Config.Logging.RPC));
        Logging.AddToggle("Photon", "parse", "parse", (Action<bool>) (x => Config.Logging.Photon = !Config.Logging.Photon));
        Logging.AddToggle("Udon", "parse", "parse", (Action<bool>) (x => Config.Logging.Udon = !Config.Logging.Udon));
        VRCModalContainer LoggingP2 = new VRCModalContainer("Logging Page 2");
        VRCSmallButton vrcSmallButton2 = new VRCSmallButton(Logging, "Next", (Action) (() => LoggingP2.Open()));
        LoggingP2.AddToggle("Debug", "parse", "parse", (Action<bool>) (x => Config.Advanced.DebugMode = !Config.Advanced.DebugMode));
        VRCModalContainer Renders = new VRCModalContainer("Renderer");
        vrcGroupLayout.AddButton("Renders", "Render Properties", (Action) (() => Renders.Open()), true);
        Renders.AddToggle("ESP", "parse", "parse", (Action<bool>) (x => Config.Render.esp = !Config.Render.esp));
        Renders.AddToggle("Wallhacks", "parse", "parse", (Action<bool>) (x => Config.Render.player_wallhack = !Config.Render.player_wallhack));
        VRCPanelRoot vrcPanelRoot = new VRCPanelRoot();
        VRCPanel vrcPanel = new VRCPanel();
        new VRCRadialSelect(vrcPanel, "Wallhacks", "Shows Players Through Walls with there Avatar Meshs (Buggy)").AddChoice("Nameplates + Players", (Action) (() => sconsole.internal_log("1"))).AddChoice("Nameplates", (Action) (() => sconsole.internal_log("2"))).AddChoice("Players", (Action) (() => sconsole.internal_log("3")));
        vrcPanel.AddSeperator();
        VRCToggleOperator vrcToggleOperator = new VRCToggleOperator(vrcPanel, "[GLOBAL BROADCASTING]", (Action<bool>) (x => sconsole.internal_log(x ? "Enabled" : "Disabled")));
        vrcGroupLayout.AddButton("Clear", "test", (Action) (() => LimeConsole.Clear()), false);
      }
      catch (Exception ex)
      {
        sconsole.print($"{ex.Message}\n{ex.Source}", 2);
      }
      finally
      {
        sconsole.print("Created The QuickMenu+BlanketSDK.UI", 1);
      }
    }
  }

  public class SelectedMenu : IQuickMenuElements
  {
    public static void Apply()
    {
      try
      {
        VRCToggle vrcToggle = new VRCToggle(IQuickMenuElements.QMElements.SelectedUser.SelectedUser_ButtonContainer(), "FREEZE!", "FREEZE CRIMINAL SCUM, ", "UNFREEZE NICE INDIVIUAL!", (Action<bool>) (x =>
        {
          Player selectedUser = GameUtils.PlayerModel.Matchmaking.GetSelectedUser();
          if (!Object.op_Inequality((Object) selectedUser, (Object) null))
            return;
          sconsole.print(x ? "<color=red>[Frozen]</color>: " + selectedUser.APIUser.displayName : "<color=red>[UnFrozen]</color>: " + selectedUser.APIUser.displayName, 0);
          ((Behaviour) ((Component) selectedUser).GetComponent<FlatBufferNetworkSerializer>()).enabled = !x;
        }));
      }
      catch (Exception ex)
      {
        sconsole.print($"{ex.Message}\n{ex.Source}", 2);
      }
      finally
      {
        sconsole.print("Created The Selected_QuickMenu+BlanketSDK.UI", 1);
      }
    }
  }
}
