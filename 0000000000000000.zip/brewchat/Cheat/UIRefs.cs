
using BlanketSDK.QM.Elements.Controls;

#nullable enable
namespace Brewchat.Cheat;

internal class UIRefs
{
  public static VRCToggle Fly { get; set; }
}
