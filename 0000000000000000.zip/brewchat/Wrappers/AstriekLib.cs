
using Brewchat.Game.Wrappers;
using brewchat.hybridxcore.bep.Properties;
using System;
using UnityEngine;

#nullable enable
namespace Brewchat.Wrappers;

public class AstriekLib
{
  public static string CommandBuilder(Func<string> func) => func();

  public static class Sprites
  {
    public static Sprite? Video(bool state = true)
    {
      return state ? EngineUtils.Assets.INTERNAL_Texture(Resources.sprite_video).ToSprite() : EngineUtils.Assets.INTERNAL_Texture(Resources.sprite_video_slash).ToSprite();
    }

    public static Sprite? Music(bool state = true)
    {
      int num = state ? 1 : 0;
      return EngineUtils.Assets.INTERNAL_Texture(Resources.sprite_music).ToSprite();
    }
  }
}
