﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UNIXEngine.IL2CPPModding.Utils.Collections;

#nullable enable
public static class UnityGIF
{
  private static Texture2D[] gifFrames;
  private static float[] frameDelays;
  private static int currentFrame;
  private static bool isPlaying;

  public static void LoadGif(Uri path)
  {
    byte[] gifData = File.ReadAllBytes(path.LocalPath);
    ((MonoBehaviour) Object.FindObjectOfType<FlatLoadingOverlay>()).StartCoroutine(CollectionExtensions.WrapToIl2Cpp(UnityGIF.DecodeGif(gifData)));
  }

  private static IEnumerator DecodeGif(byte[] gifData)
  {
    List<UniGif.GifTexture> frames = new List<UniGif.GifTexture>();
    yield return (object) UniGif.GetTextureListCoroutine(gifData, (Action<List<UniGif.GifTexture>, int, int, int>) ((textures, loopCount, width, height) => frames = textures));
    if (frames.Count > 0)
    {
      UnityGIF.gifFrames = frames.Select<UniGif.GifTexture, Texture2D>((Func<UniGif.GifTexture, Texture2D>) (f => f.m_texture2d)).ToArray<Texture2D>();
      UnityGIF.frameDelays = frames.Select<UniGif.GifTexture, float>((Func<UniGif.GifTexture, float>) (f => f.m_delaySec)).ToArray<float>();
      ((MonoBehaviour) Object.FindObjectOfType<FlatLoadingOverlay>()).StartCoroutine(CollectionExtensions.WrapToIl2Cpp(UnityGIF.PlayGifAnimation()));
    }
  }

  private static IEnumerator PlayGifAnimation()
  {
    UnityGIF.isPlaying = true;
    while (UnityGIF.isPlaying)
    {
      UnityGIF.currentFrame = (UnityGIF.currentFrame + 1) % UnityGIF.gifFrames.Length;
      yield return (object) new WaitForSeconds(UnityGIF.frameDelays[UnityGIF.currentFrame]);
    }
  }

  public static Texture2D GetCurrentFrame() => UnityGIF.gifFrames?[UnityGIF.currentFrame];

  public static void StopAnimation() => UnityGIF.isPlaying = false;
}
