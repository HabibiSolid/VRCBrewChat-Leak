
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

#nullable enable
public static class EnhancedSerializationManager
{
  public static object IL2CPPToManaged(object il2cppObject)
  {
    if (il2cppObject == null)
      return (object) null;
    Type type = il2cppObject.GetType();
    string fullName = type.FullName;
    if (!type.IsPrimitive)
    {
      if (!(il2cppObject is string))
      {
        try
        {
          if (EnhancedSerializationManager.IsIL2CPPDictionary(il2cppObject))
            return EnhancedSerializationManager.ConvertIL2CPPDictionary(il2cppObject);
          if (EnhancedSerializationManager.IsIL2CPPList(il2cppObject))
            return EnhancedSerializationManager.ConvertIL2CPPList(il2cppObject);
          if (EnhancedSerializationManager.IsIL2CPPArray(il2cppObject))
            return EnhancedSerializationManager.ConvertIL2CPPArray(il2cppObject);
          if (fullName.Contains("ParameterDictionary"))
            return EnhancedSerializationManager.ConvertParameterDictionary(il2cppObject);
          return fullName.Contains("EventData") ? EnhancedSerializationManager.ConvertEventData(il2cppObject) : EnhancedSerializationManager.ConvertGenericIL2CPPObject(il2cppObject);
        }
        catch (Exception ex)
        {
          return (object) $"[Conversion Error: {ex.Message}]";
        }
      }
    }
    return il2cppObject;
  }

  private static bool IsIL2CPPDictionary(object obj)
  {
    Type type = obj.GetType();
    string str = type.FullName ?? string.Empty;
    if (str.Contains("Dictionary") || str.Contains("IDictionary") || str.Contains("Map"))
      return true;
    return EnhancedSerializationManager.HasMethod(type, "get_Item") && EnhancedSerializationManager.HasMethod(type, "ContainsKey");
  }

  private static bool IsIL2CPPList(object obj)
  {
    Type type = obj.GetType();
    string str = type.FullName ?? string.Empty;
    if (str.Contains("List") || str.Contains("IList") || str.Contains("Collection"))
      return true;
    return EnhancedSerializationManager.HasMethod(type, "get_Item") && EnhancedSerializationManager.HasMethod(type, "get_Count") && !EnhancedSerializationManager.HasMethod(type, "ContainsKey");
  }

  private static bool IsIL2CPPArray(object obj)
  {
    Type type = obj.GetType();
    if (type.IsArray)
      return true;
    string fullName = type.FullName;
    return fullName != null && fullName.Contains("[]");
  }

  private static bool HasMethod(Type type, string methodName)
  {
    return type.GetMethod(methodName) != (MethodInfo) null;
  }

  private static object ConvertIL2CPPDictionary(object il2cppDict)
  {
    Dictionary<object, object> dictionary1 = new Dictionary<object, object>();
    try
    {
      if (il2cppDict is IDictionary dictionary2)
      {
        foreach (DictionaryEntry dictionaryEntry in dictionary2)
        {
          object managed1 = EnhancedSerializationManager.IL2CPPToManaged(dictionaryEntry.Key);
          object managed2 = EnhancedSerializationManager.IL2CPPToManaged(dictionaryEntry.Value);
          dictionary1[managed1] = managed2;
        }
        return (object) dictionary1;
      }
      Type type1 = il2cppDict.GetType();
      PropertyInfo property1 = type1.GetProperty("Keys");
      if (property1 != (PropertyInfo) null && property1.GetValue(il2cppDict) is IEnumerable enumerable)
      {
        foreach (object il2cppObject1 in enumerable)
        {
          MethodInfo method = type1.GetMethod("get_Item");
          if (method != (MethodInfo) null)
          {
            object il2cppObject2 = method.Invoke(il2cppDict, new object[1]
            {
              il2cppObject1
            });
            dictionary1[EnhancedSerializationManager.IL2CPPToManaged(il2cppObject1)] = EnhancedSerializationManager.IL2CPPToManaged(il2cppObject2);
          }
        }
        return (object) dictionary1;
      }
      MethodInfo method1 = type1.GetMethod("GetEnumerator");
      if (method1 != (MethodInfo) null)
      {
        object obj1 = method1.Invoke(il2cppDict, (object[]) null);
        Type type2 = obj1.GetType();
        MethodInfo method2 = type2.GetMethod("MoveNext");
        PropertyInfo property2 = type2.GetProperty("Current");
        if (method2 != (MethodInfo) null && property2 != (PropertyInfo) null)
        {
          while ((bool) method2.Invoke(obj1, (object[]) null))
          {
            object obj2 = property2.GetValue(obj1);
            Type type3 = obj2.GetType();
            PropertyInfo property3 = type3.GetProperty("Key");
            PropertyInfo property4 = type3.GetProperty("Value");
            if (property3 != (PropertyInfo) null && property4 != (PropertyInfo) null)
            {
              object il2cppObject3 = property3.GetValue(obj2);
              object il2cppObject4 = property4.GetValue(obj2);
              dictionary1[EnhancedSerializationManager.IL2CPPToManaged(il2cppObject3)] = EnhancedSerializationManager.IL2CPPToManaged(il2cppObject4);
            }
          }
          return (object) dictionary1;
        }
      }
      throw new InvalidOperationException("Could not extract dictionary entries");
    }
    catch (Exception ex)
    {
      dictionary1[(object) "[ERROR]"] = (object) ("Dictionary conversion error: " + ex.Message);
      return (object) dictionary1;
    }
  }

  private static object ConvertIL2CPPList(object il2cppList)
  {
    List<object> objectList = new List<object>();
    try
    {
      if (il2cppList is IEnumerable enumerable)
      {
        foreach (object il2cppObject in enumerable)
          objectList.Add(EnhancedSerializationManager.IL2CPPToManaged(il2cppObject));
        return (object) objectList;
      }
      Type type1 = il2cppList.GetType();
      PropertyInfo property1 = type1.GetProperty("Count");
      MethodInfo method1 = type1.GetMethod("get_Item");
      if (property1 != (PropertyInfo) null && method1 != (MethodInfo) null)
      {
        int num = (int) property1.GetValue(il2cppList);
        for (int index = 0; index < num; ++index)
        {
          object il2cppObject = method1.Invoke(il2cppList, new object[1]
          {
            (object) index
          });
          objectList.Add(EnhancedSerializationManager.IL2CPPToManaged(il2cppObject));
        }
        return (object) objectList;
      }
      MethodInfo method2 = type1.GetMethod("GetEnumerator");
      if (method2 != (MethodInfo) null)
      {
        object obj = method2.Invoke(il2cppList, (object[]) null);
        Type type2 = obj.GetType();
        MethodInfo method3 = type2.GetMethod("MoveNext");
        PropertyInfo property2 = type2.GetProperty("Current");
        if (method3 != (MethodInfo) null && property2 != (PropertyInfo) null)
        {
          while ((bool) method3.Invoke(obj, (object[]) null))
          {
            object il2cppObject = property2.GetValue(obj);
            objectList.Add(EnhancedSerializationManager.IL2CPPToManaged(il2cppObject));
          }
          return (object) objectList;
        }
      }
      throw new InvalidOperationException("Could not extract list items");
    }
    catch (Exception ex)
    {
      objectList.Add((object) $"[List conversion error: {ex.Message}]");
      return (object) objectList;
    }
  }

  private static object ConvertIL2CPPArray(object il2cppArray)
  {
    try
    {
      if (!(il2cppArray is Array array))
        throw new InvalidOperationException("Not a valid array");
      List<object> objectList = new List<object>();
      foreach (object il2cppObject in array)
        objectList.Add(EnhancedSerializationManager.IL2CPPToManaged(il2cppObject));
      return (object) objectList.ToArray();
    }
    catch (Exception ex)
    {
      return (object) $"[Array conversion error: {ex.Message}]";
    }
  }

  private static object ConvertParameterDictionary(object paramDictObj)
  {
    Dictionary<object, object> dictionary = new Dictionary<object, object>();
    try
    {
      Type type = paramDictObj.GetType();
      object il2cppDict = (object) null;
      PropertyInfo property1 = type.GetProperty("paramDict");
      if (property1 != (PropertyInfo) null)
      {
        il2cppDict = property1.GetValue(paramDictObj);
      }
      else
      {
        FieldInfo field = type.GetField("paramDict", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        if (field != (FieldInfo) null)
          il2cppDict = field.GetValue(paramDictObj);
      }
      if (il2cppDict != null)
        return EnhancedSerializationManager.ConvertIL2CPPDictionary(il2cppDict);
      if (paramDictObj is IDictionary || EnhancedSerializationManager.HasMethod(type, "ContainsKey"))
        return EnhancedSerializationManager.ConvertIL2CPPDictionary(paramDictObj);
      MethodInfo method = type.GetMethod("TryGetValue");
      PropertyInfo property2 = type.GetProperty("Keys");
      if (method != (MethodInfo) null && property2 != (PropertyInfo) null && property2.GetValue(paramDictObj) is IEnumerable enumerable)
      {
        foreach (object il2cppObject in enumerable)
        {
          object[] parameters = new object[2]
          {
            il2cppObject,
            null
          };
          if ((bool) method.Invoke(paramDictObj, parameters))
            dictionary[EnhancedSerializationManager.IL2CPPToManaged(il2cppObject)] = EnhancedSerializationManager.IL2CPPToManaged(parameters[1]);
        }
        return (object) dictionary;
      }
      dictionary[(object) "[WARNING]"] = (object) "Could not extract ParameterDictionary values through known methods";
      return (object) dictionary;
    }
    catch (Exception ex)
    {
      dictionary[(object) "[ERROR]"] = (object) ("ParameterDictionary conversion error: " + ex.Message);
      return (object) dictionary;
    }
  }

  private static object ConvertEventData(object eventDataObj)
  {
    Dictionary<string, object> dictionary = new Dictionary<string, object>();
    try
    {
      Type type = eventDataObj.GetType();
      PropertyInfo property1 = type.GetProperty("Code");
      PropertyInfo property2 = type.GetProperty("Sender");
      PropertyInfo property3 = type.GetProperty("CustomData");
      PropertyInfo property4 = type.GetProperty("Parameters");
      if (property1 != (PropertyInfo) null)
        dictionary["Code"] = property1.GetValue(eventDataObj);
      if (property2 != (PropertyInfo) null)
        dictionary["Sender"] = property2.GetValue(eventDataObj);
      if (property3 != (PropertyInfo) null)
      {
        object il2cppObject = property3.GetValue(eventDataObj);
        dictionary["CustomData"] = EnhancedSerializationManager.IL2CPPToManaged(il2cppObject);
      }
      if (property4 != (PropertyInfo) null)
      {
        object il2cppObject = property4.GetValue(eventDataObj);
        dictionary["Parameters"] = EnhancedSerializationManager.IL2CPPToManaged(il2cppObject);
      }
      return (object) dictionary;
    }
    catch (Exception ex)
    {
      dictionary["[ERROR]"] = (object) ("EventData conversion error: " + ex.Message);
      return (object) dictionary;
    }
  }

  private static object ConvertGenericIL2CPPObject(object il2cppObject)
  {
    Dictionary<string, object> dictionary = new Dictionary<string, object>();
    try
    {
      Type type = il2cppObject.GetType();
      dictionary["[Type]"] = (object) type.FullName;
      foreach (PropertyInfo property in type.GetProperties(BindingFlags.Instance | BindingFlags.Public))
      {
        try
        {
          if (property.GetIndexParameters().Length == 0)
          {
            object il2cppObject1 = property.GetValue(il2cppObject);
            dictionary[property.Name] = EnhancedSerializationManager.IL2CPPToManaged(il2cppObject1);
          }
        }
        catch
        {
          dictionary[property.Name] = (object) "[Property access error]";
        }
      }
      foreach (FieldInfo field in type.GetFields(BindingFlags.Instance | BindingFlags.Public))
      {
        try
        {
          object il2cppObject2 = field.GetValue(il2cppObject);
          dictionary[field.Name] = EnhancedSerializationManager.IL2CPPToManaged(il2cppObject2);
        }
        catch
        {
          dictionary[field.Name] = (object) "[Field access error]";
        }
      }
      return (object) dictionary;
    }
    catch (Exception ex)
    {
      dictionary["[ERROR]"] = (object) ("Object conversion error: " + ex.Message);
      return (object) dictionary;
    }
  }

  public static string SerializeObject(object obj, int depth = 0, HashSet<object> visited = null)
  {
    if (visited == null)
      visited = new HashSet<object>((IEqualityComparer<object>) new EnhancedSerializationManager.ReferenceEqualityComparer());
    if (obj == null)
      return "null";
    if (depth > 5)
      return "[Max depth reached]";
    if (!obj.GetType().IsValueType && !obj.GetType().IsPrimitive && !(obj is string))
    {
      if (visited.Contains(obj))
        return "[Circular reference]";
      visited.Add(obj);
    }
    switch (obj)
    {
      case string str:
        return $"\"{str}\"";
      case bool flag3:
        return flag3.ToString().ToLower();
      case byte _:
      case short _:
      case int _:
      case long _:
      case float _:
      case double _:
      case Decimal _:
        return obj.ToString();
      case IDictionary dictionary:
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.Append("{ ");
        bool flag1 = true;
        foreach (DictionaryEntry dictionaryEntry in dictionary)
        {
          if (!flag1)
            stringBuilder1.Append(", ");
          flag1 = false;
          string str1 = EnhancedSerializationManager.SerializeObject(dictionaryEntry.Key, depth + 1, visited);
          string str2 = EnhancedSerializationManager.SerializeObject(dictionaryEntry.Value, depth + 1, visited);
          StringBuilder stringBuilder2 = stringBuilder1;
          StringBuilder stringBuilder3 = stringBuilder2;
          StringBuilder.AppendInterpolatedStringHandler interpolatedStringHandler = new StringBuilder.AppendInterpolatedStringHandler(2, 2, stringBuilder2);
          interpolatedStringHandler.AppendFormatted(str1);
          interpolatedStringHandler.AppendLiteral(": ");
          interpolatedStringHandler.AppendFormatted(str2);
          ref StringBuilder.AppendInterpolatedStringHandler local = ref interpolatedStringHandler;
          stringBuilder3.Append(ref local);
        }
        stringBuilder1.Append(" }");
        return stringBuilder1.ToString();
      case IEnumerable enumerable when !(obj is string):
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.Append("[ ");
        bool flag2 = true;
        foreach (object obj1 in enumerable)
        {
          if (!flag2)
            stringBuilder4.Append(", ");
          flag2 = false;
          stringBuilder4.Append(EnhancedSerializationManager.SerializeObject(obj1, depth + 1, visited));
        }
        stringBuilder4.Append(" ]");
        return stringBuilder4.ToString();
      default:
        return obj.ToString();
    }
  }

  public class ReferenceEqualityComparer : EqualityComparer<object>
  {
    public override bool Equals(object x, object y) => x == y;

    public override int GetHashCode(object obj) => RuntimeHelpers.GetHashCode(obj);
  }
}
