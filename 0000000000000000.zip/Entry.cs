
using HarmonyLib;
using Il2CppInterop.Runtime.Injection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UNIXEngine;
using UNIXEngine.Core.Logging.Interpolation;
using UNIXEngine.IL2CPPModding;
using UNIXEngine.Logging;

#nullable enable
[UnixModDescriptor("0000000000", "astriek", "0.0.0.0")]
public class Entry : UnixMod
{
  public const string NAME = "Astriek";
  public const string FULLNAME = "Astriek";
  private Harmony h = new Harmony(Guid.NewGuid().ToString());
  public static ManualLogSource Console = new ManualLogSource("astriek");

  public virtual void Load()
  {
    Logger.Sources.Add((ILogSource) Entry.Console);
    bool flag;
    foreach (Type type in ((IEnumerable<Type>) Assembly.GetExecutingAssembly().GetTypes()).Where<Type>((Func<Type, bool>) (x => x.IsClass && !x.IsAbstract && x.IsSubclassOf(typeof (MonoBehaviour)))))
    {
      ManualLogSource console = Entry.Console;
      BepInExMessageLogInterpolatedStringHandler interpolatedStringHandler1 = new BepInExMessageLogInterpolatedStringHandler(28, 1, ref flag);
      if (flag)
      {
        ((BepInExLogInterpolatedStringHandler) interpolatedStringHandler1).AppendLiteral("Registering Monobehaviours: ");
        ((BepInExLogInterpolatedStringHandler) interpolatedStringHandler1).AppendFormatted<string>(type.Name);
      }
      BepInExMessageLogInterpolatedStringHandler interpolatedStringHandler2 = interpolatedStringHandler1;
      console.LogMessage(interpolatedStringHandler2);
      ClassInjector.RegisterTypeInIl2Cpp(type);
    }
    ManualLogSource console1 = Entry.Console;
    BepInExMessageLogInterpolatedStringHandler interpolatedStringHandler3 = new BepInExMessageLogInterpolatedStringHandler(16 /*0x10*/, 0, ref flag);
    if (flag)
      ((BepInExLogInterpolatedStringHandler) interpolatedStringHandler3).AppendLiteral("Setting Hooks...");
    BepInExMessageLogInterpolatedStringHandler interpolatedStringHandler4 = interpolatedStringHandler3;
    console1.LogMessage(interpolatedStringHandler4);
    this.h.PatchAll();
  }
}
