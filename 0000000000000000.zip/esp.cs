
using Brewchat;
using Brewchat.Game.Wrappers;
using System.Collections.Generic;
using UnityEngine;
using VRC;

#nullable enable
internal class esp : MonoBehaviour
{
  private SkinnedMeshRenderer[] _avatarender;
  private HighlightsFXStandalone FX;
  public static Dictionary<Player, esp> _esp = new Dictionary<Player, esp>();

  public Player _player { get; set; }

  private void LateUpdate()
  {
    Config.Render.esp = !Config.Render.esp;
    this._player = ((Component) ((Component) this).transform).GetComponent<Player>();
    this.GetSelectRegion(this._player);
  }

  private void GetSelectRegion(Player player)
  {
    PlayerSelector laserSelectRegion = player._laserSelectRegion;
    if (!Object.op_Inequality((Object) GameUtils.Camera.Get, (Object) null))
      return;
    this.FX = ((Component) GameUtils.Camera.Get).GetComponent<HighlightsFXStandalone>();
    ((HighlightsFX) this.FX).Method_Public_Void_MeshFilter_PDM_0(((Component) laserSelectRegion).GetComponent<MeshFilter>());
    this.FX.highlightColor = Config.Appearance.Platte.HighlightFX;
    this.FX.blurSize = 0.3f;
  }
}
