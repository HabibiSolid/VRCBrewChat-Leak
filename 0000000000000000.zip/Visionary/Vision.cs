
using Brewchat.Game.Wrappers;
using System;
using System.Runtime.InteropServices;

#nullable enable
namespace Visionary;

public static class Vision
{
  [StructLayout(LayoutKind.Sequential, Size = 1)]
  public struct API
  {
    public static void GiveTag()
    {
      GameUtils.VRChatUtils.VRCKeyboard.InputPopup("Enter Tag", (Action<string>) (x => { }), Placeholder: "This sets the players tag", MultiLine: false);
    }
  }
}
