
using UnityEngine;

#nullable enable
namespace MaterialEditing.UI;

public static class MaterialUtils
{
  public static Material? Background_Parallax(this Material target, Texture2D? texture)
  {
    if (Object.op_Equality((Object) target, (Object) null) || Object.op_Equality((Object) texture, (Object) null))
      return (Material) null;
    target.SetTexture("_ParallaxBackground", (Texture) texture);
    target.SetTexture("_ParallaxMidground", (Texture) texture);
    target.SetTexture("_ParallaxForeground", (Texture) texture);
    return target;
  }

  public static Material? Background_Parallax(this Material target, Texture? texture)
  {
    if (Object.op_Equality((Object) target, (Object) null) || Object.op_Equality((Object) texture, (Object) null))
      return (Material) null;
    target.SetTexture("_ParallaxBackground", texture);
    target.SetTexture("_ParallaxMidground", texture);
    target.SetTexture("_ParallaxForeground", texture);
    return target;
  }
}
