﻿using Brewchat.Game.Wrappers;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using UnityEngine;
using VRC;

internal class wallhacks : MonoBehaviour
{
  private SkinnedMeshRenderer[] _avatarender;
  private SkinnedMeshRenderer _meshs;

  public GameObject canvas_nameplate { get; set; }

  public PlayerNameplate _nameplate { get; set; }

  public Player _player { get; set; }

  private void Start()
  {
    this._player = ((Component) ((Component) this).transform).GetComponent<Player>();
    this._avatarender = Il2CppArrayBase<SkinnedMeshRenderer>.op_Implicit(((Component) this._player).GetComponentsInChildren<SkinnedMeshRenderer>(false));
    if (this._avatarender == null)
      return;
    foreach (SkinnedMeshRenderer skinnedMeshRenderer in this._avatarender)
    {
      if (((Component) skinnedMeshRenderer).gameObject.layer != LayerMask.op_Implicit(GameUtils.Gameplay.RenderLayers.InternalUI))
        ((Component) skinnedMeshRenderer).gameObject.layer = LayerMask.op_Implicit(GameUtils.Gameplay.RenderLayers.InternalUI);
    }
    if (Object.op_Equality((Object) this._player._vrcplayer.Nameplate, (Object) null))
      return;
    this._nameplate = this._player._vrcplayer.Nameplate;
    ((Component) ((Component) this._nameplate.NameplatePositioner).transform.GetChild(0)).gameObject.layer = LayerMask.op_Implicit(GameUtils.Gameplay.RenderLayers.InternalUI);
  }
}
