﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Permissions;

[assembly: Extension]
[assembly: AssemblyCompany("division club")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+a5e2556e05ee72534e2b08ce7de6ed53e874237e")]
[assembly: AssemblyProduct("guild")]
[assembly: AssemblyTitle("000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
