
#nullable enable
namespace Syrup;

public class Colors
{
  public static string Font = "#ffffff";
  public static string Main = "#ffffff";
  public static string Error = "#ffffff";
  public static string Warning = "#ffffff";
}
