
using Il2CppSystem;
using System;
using UnityEngine;

#nullable enable
namespace Syrup;

internal class sparameters
{
  public static GUIStyle Text(int fontSize)
  {
    GUIStyle guiStyle = new GUIStyle();
    try
    {
      guiStyle.fontSize = fontSize;
      guiStyle.normal.textColor = Color.white;
      guiStyle.wordWrap = true;
    }
    catch (Exception ex)
    {
      Debug.LogError(Object.op_Implicit("Error in _Text: " + ex.Message));
      guiStyle = new GUIStyle(GUI.skin.label);
      guiStyle.fontSize = fontSize;
    }
    return guiStyle;
  }
}
