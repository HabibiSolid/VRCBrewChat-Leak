
#nullable enable
namespace Syrup;

public class ColorPalette
{
  public static string[] CArray = new string[6]
  {
    "#ffffff",
    "#ffffff",
    "#ffffff",
    "#ffffff",
    "#ffffff",
    "#ffffff"
  };
}
