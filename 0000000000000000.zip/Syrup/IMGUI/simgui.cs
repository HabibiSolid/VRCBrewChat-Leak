
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UNIXEngine.IL2CPPModding.Utils.Collections;

#nullable enable
namespace Syrup.IMGUI;

public class simgui : MonoBehaviour
{
  private static string console_flag = "[SYSTEM]";
  private Rect console_container_rect = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
  private bool CONSOLE_UI;
  private int fontSize = 11;
  private Dictionary<int, float> textAlpha = new Dictionary<int, float>();
  private string v = string.Empty;
  public static Vector2 scrollPosition = Vector2.zero;
  private float SH;
  private int i;
  private float yOffset = 5f;
  private float y = 13f;
  private float xOffset;
  private float x = 5f;

  private List<string> console { get; set; } = sconsole.text;

  private void Awake()
  {
    string msg = $"{Guid.NewGuid().ToString()} {simgui.console_flag} HI!!!! <color=#9185E6><b>{Environment.UserName}</b></color> !!! get ready to make some noise :D";
    sconsole.print(msg, 0);
    sconsole.internal_log(new string('─', msg.Length));
  }

  private void Update() => this.KeysHandler();

  private void OnGUI()
  {
    if (this.CONSOLE_UI)
      return;
    this.SH = (float) sconsole.text.Count * this.y;
    simgui.scrollPosition = GUI.BeginScrollView(new Rect(0.0f, 0.0f, (float) Screen.width, 470f), simgui.scrollPosition, new Rect(0.0f, 0.0f, ((Rect) ref this.console_container_rect).width, this.SH), false, false, GUIStyle.none, GUIStyle.none);
    for (this.i = 0; this.i < sconsole.text.Count; ++this.i)
    {
      if (!this.textAlpha.ContainsKey(this.i))
      {
        this.textAlpha[this.i] = 0.0f;
        this.StartCoroutine(CollectionExtensions.WrapToIl2Cpp(this.AnimateText(this.i)));
      }
      GUIStyle guiStyle = new GUIStyle(sparameters.Text(this.fontSize));
      guiStyle.normal.textColor = new Color(guiStyle.normal.textColor.r, guiStyle.normal.textColor.g, guiStyle.normal.textColor.b, this.textAlpha[this.i]);
      GUI.Label(new Rect(this.x, this.yOffset + (float) this.i * this.y, ((Rect) ref this.console_container_rect).width - 20f, float.MaxValue), sconsole.text[this.i], guiStyle);
    }
    GUI.EndScrollView();
  }

  private IEnumerator AnimateText(int index)
  {
    while ((double) this.textAlpha[index] < 1.0)
    {
      this.textAlpha[index] = Mathf.Min(this.textAlpha[index] + Time.deltaTime * 2f, 1f);
      yield return (object) null;
    }
  }

  private void KeysHandler()
  {
    if (Input.GetKeyDown((KeyCode) 278))
      this.CONSOLE_UI = !this.CONSOLE_UI;
    if (!Input.GetKeyDown((KeyCode) 280))
      return;
    sconsole.clr();
  }
}
