
using System;
using System.Collections.Generic;

#nullable enable
namespace Syrup.IMGUI;

internal static class sconsole
{
  public static List<string> text = new List<string>();

  private static string[] glyphs { get; } = new string[4]
  {
    "<color=#ed1093>#</color>",
    "<color=#9cd1a2>+</color>",
    "<color=#fe0f05>-</color>",
    "<color=#db4d52>!</color>"
  };

  private static List<string> States { get; } = new List<string>();

  private static string GetTime() => DateTime.Now.ToString("hh.mm:ss:fff");

  public static void internal_log(string str)
  {
    sconsole.text.Add(str);
    simgui.scrollPosition.y = float.PositiveInfinity;
  }

  public static void prefix(this string child) => sconsole.internal_log(child);

  public static void clr() => sconsole.text.Clear();

  public static string print(string msg, int v)
  {
    sconsole.internal_log($"<color=#ffffff>{sconsole.GetTime()}</color> {sconsole.glyphs[v]} ->  | {msg}");
    return msg;
  }

  public static string print(string flag, string direction, string msg, int v)
  {
    sconsole.internal_log($"<color=#ffffff>{sconsole.GetTime()}</color> {sconsole.glyphs[v]} ->  {$"[{flag}{direction}"}] | {msg}");
    return msg;
  }
}
