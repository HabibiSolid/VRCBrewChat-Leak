
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.QM.Elements.Controls;

internal class VRCWingButton : IQuickMenuElements
{
  public VRCWingButton(
    Transform parent,
    SDKUtils.Wing.Position position,
    string? name,
    string? tooltip,
    Action func,
    Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QuickMenu()) | !Object.op_Implicit((Object) IQuickMenuElements.QMControls.Buttons.WingButton("Left")) || !Object.op_Implicit((Object) IQuickMenuElements.QMControls.Buttons.WingButton("Right")))
      throw new Exception("wing button has moved to a different location or index contact: " + Resources.D_Contact);
    if (parent == null)
      parent = IQuickMenuElements.QMFallbacks._Fallback_Dashboard_Group_QM_UI_WingButtons($"{position}");
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMControls.Buttons.WingButton($"{position}"), parent);
    ((Object) transform).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.QM_WINGBUTTON_BUTTON";
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    ImageEx component2 = ((Component) transform.GetChild(0).GetChild(1)).GetComponent<ImageEx>();
    ToolTip component3 = ((Component) transform).GetComponent<ToolTip>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform).GetComponentInChildren<TextMeshProUGUIEx>();
    Button.ButtonClickedEvent onClick = ((Button) component1).onClick;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    component3._localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) component2).sprite = sprite;
  }
}
