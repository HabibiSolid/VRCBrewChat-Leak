
using BlanketSDK.Core;
using BlanketSDK.QM.Elements.Modals;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.QM.Elements.Controls;

internal class VRCButton : IQuickMenuElements
{
  private TextMeshProUGUIEx TMPro;
  private Button.ButtonClickedEvent? BUTTONCLICKED_EVENT_0;

  public VRCButton(
    Transform parent,
    string? name,
    string? tooltip,
    Action func,
    bool submenu = false,
    Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QuickMenu()) | !Object.op_Implicit((Object) IQuickMenuElements.QMControls.Buttons.SingleButton()))
      throw new Exception("button has moved to a different location or index contact: " + Resources.D_Contact);
    if (parent == null)
      parent = IQuickMenuElements.QMFallbacks._Fallback_Dashboard_Group_QM_UI_Buttons();
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMControls.Buttons.SingleButton(), parent);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.QM_SINGLE_BUTTON-{name}";
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform).GetComponentInChildren<TextMeshProUGUIEx>(true);
    ImageEx component2 = ((Component) transform.GetChild(3).GetChild(0)).GetComponent<ImageEx>();
    ((Component) ((Component) transform.GetChild(4)).GetComponent<ImageEx>()).gameObject.SetActive(submenu);
    Object.DestroyImmediate((Object) ((Component) transform).GetComponent<ToolTip>());
    ToolTip component3 = ((Component) transform).GetComponent<ToolTip>();
    this.BUTTONCLICKED_EVENT_0 = ((Button) component1).onClick;
    ((UnityEventBase) this.BUTTONCLICKED_EVENT_0).RemoveAllListeners();
    ((UnityEvent) this.BUTTONCLICKED_EVENT_0).AddListener(UnityAction.op_Implicit(func));
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    this.TMPro = componentInChildren;
    if (component3.GetType() == typeof (ToolTip))
      component3._localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) component2).sprite = sprite;
  }

  public VRCButton(
    VRCModalContainer modal,
    string? name,
    string? tooltip,
    Action func,
    Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QuickMenu()) | !Object.op_Implicit((Object) IQuickMenuElements.QMControls.Buttons.SingleButton()))
      throw new Exception("button has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMControls.Buttons.SingleButton(), modal._verticallayoutgroup);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.QM_SINGLE_BUTTON-{name}";
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform).GetComponentInChildren<TextMeshProUGUIEx>(true);
    ImageEx component2 = ((Component) transform.GetChild(3).GetChild(0)).GetComponent<ImageEx>();
    Object.DestroyImmediate((Object) ((Component) transform).GetComponent<ToolTip>());
    ToolTip component3 = ((Component) transform).GetComponent<ToolTip>();
    this.BUTTONCLICKED_EVENT_0 = ((Button) component1).onClick;
    ((UnityEventBase) this.BUTTONCLICKED_EVENT_0).RemoveAllListeners();
    ((UnityEvent) this.BUTTONCLICKED_EVENT_0).AddListener(UnityAction.op_Implicit(func));
    component1._controlName = modal.Name;
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    this.TMPro = componentInChildren;
    if (component3.GetType() == typeof (ToolTip))
      component3._localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) component2).sprite = sprite;
  }

  public VRCButton(
    VRCPage page,
    Transform parent,
    string? name,
    string? tooltip,
    Action func = null,
    Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QuickMenu()) | !Object.op_Implicit((Object) IQuickMenuElements.QMControls.Buttons.SingleButton()))
      throw new Exception("button has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMControls.Buttons.SingleButton(), parent);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.QM_SINGLE_BUTTON-{name}";
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform).GetComponentInChildren<TextMeshProUGUIEx>(true);
    ImageEx component2 = ((Component) transform.GetChild(3).GetChild(0)).GetComponent<ImageEx>();
    ((Component) ((Component) transform.GetChild(4)).GetComponent<ImageEx>()).gameObject.SetActive(true);
    Object.DestroyImmediate((Object) ((Component) transform).GetComponent<ToolTip>());
    ToolTip component3 = ((Component) transform).GetComponent<ToolTip>();
    component1._controlName = page.Name;
    if (func != null)
    {
      this.BUTTONCLICKED_EVENT_0 = ((Button) component1).onClick;
      this.BUTTONCLICKED_EVENT_0 = new Button.ButtonClickedEvent();
      ((UnityEvent) this.BUTTONCLICKED_EVENT_0).AddListener(UnityAction.op_Implicit(func));
    }
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    this.TMPro = componentInChildren;
    if (component3.GetType() == typeof (ToolTip))
      component3._localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) component2).sprite = sprite;
  }

  public void Invoke() => ((UnityEvent) this.BUTTONCLICKED_EVENT_0)?.Invoke();

  public TextMeshProUGUIEx SetText(string text)
  {
    ((TMP_Text) this.TMPro).text = text;
    return this.TMPro;
  }

  public VRCButton(
    VRCGroupBox parent,
    string? name,
    string? tooltip,
    Action func,
    bool submenu = false,
    Sprite? sprite = null)
    : this(parent.container, name, tooltip, func, Object.op_Implicit((Object) sprite))
  {
  }

  public VRCButton(
    VRCGroupLayout parent,
    string? name,
    string? tooltip,
    Action func,
    bool submenu = false,
    Sprite? sprite = null)
    : this(parent.container, name, tooltip, func, submenu, sprite)
  {
  }
}
