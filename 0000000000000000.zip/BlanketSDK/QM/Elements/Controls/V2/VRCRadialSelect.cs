
using BlanketSDK.Core;
using BlanketSDK.QM.Elements.V2;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI.Elements;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.QM.Elements.Controls.V2;

internal class VRCRadialSelect : IQuickMenuElements
{
  private RadialSelector radialSelector;
  private TextMeshProUGUIEx titleText;
  private List<VRCRadialSelect.ChoiceOption> choices = new List<VRCRadialSelect.ChoiceOption>();
  private int currentIndex;

  public VRCRadialSelect(
    VRCPanel parent,
    string name,
    [Optional] string? tooltip,
    [Optional] bool isChild,
    Action callback = null)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QM()) || !Object.op_Implicit((Object) IQuickMenuElements.QMParent()) || !Object.op_Implicit((Object) IQuickMenuElements.QMMenus.QMSubmenus.Menu_QM_GeneralSettings()))
      throw new Exception($"{name} element has moved to a different location or index contact: {Resources.D_Contact}");
    VRCPanel vrcPanel = parent;
    if (vrcPanel.obj == null)
      vrcPanel.obj = IQuickMenuElements.QMFallbacks._Fallback_Dashboard_Group_QM_UI_ChoiceSelection_Element();
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMControls.OperatorRadialSelection(), parent.container);
    ((Object) transform).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.QM_CHOICE_SELECTION>";
    transform.GetChild(0);
    transform.GetChild(1);
    this.radialSelector = ((Component) transform).GetComponent<RadialSelector>();
    this.titleText = ((MonoBehaviour1PublicOb_tGa_c_tGa_mOb_sStUnique) this.radialSelector)._title;
    ((TMP_Text) this.titleText).text = name;
    ((TMP_Text) this.titleText).richText = true;
    this.radialSelector._optionTooltip._localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    ((MonoBehaviour1PublicOb_tGa_c_tGa_mOb_sStUnique) this.radialSelector)._childIndicator.SetActive(isChild);
    ((UnityEvent) ((Button) this.radialSelector._leftButton).onClick).AddListener(UnityAction.op_Implicit(new Action(this.PreviousChoice)));
    ((UnityEvent) ((Button) this.radialSelector._rightButton).onClick).AddListener(UnityAction.op_Implicit(new Action(this.NextChoice)));
    if (callback == null)
      return;
    this.AddChoice("Default", callback);
  }

  public VRCRadialSelect AddChoice(string name, Action callback)
  {
    this.choices.Add(new VRCRadialSelect.ChoiceOption(name, callback));
    if (this.choices.Count == 1)
      this.UpdateDisplay();
    return this;
  }

  private void PreviousChoice()
  {
    if (this.choices.Count == 0)
      return;
    this.currentIndex = (this.currentIndex - 1 + this.choices.Count) % this.choices.Count;
    this.UpdateDisplay();
    this.ExecuteCurrentChoice();
  }

  private void NextChoice()
  {
    if (this.choices.Count == 0)
      return;
    this.currentIndex = (this.currentIndex + 1) % this.choices.Count;
    this.UpdateDisplay();
    this.ExecuteCurrentChoice();
  }

  private void UpdateDisplay()
  {
    if (this.choices.Count == 0)
      return;
    VRCRadialSelect.ChoiceOption choice = this.choices[this.currentIndex];
    if (!Object.op_Inequality((Object) this.radialSelector, (Object) null) || !Object.op_Inequality((Object) this.radialSelector._currentOptionText, (Object) null))
      return;
    ((TMP_Text) this.radialSelector._currentOptionText).text = choice.Name;
  }

  private void ExecuteCurrentChoice()
  {
    if (this.choices.Count == 0)
      return;
    VRCRadialSelect.ChoiceOption choice = this.choices[this.currentIndex];
    ((UIMenu) IQuickMenuElements.QM()).field_Private_ModalAlert_0.Method_Public_Void_LocalizableString_PDM_0(LocalizableStringExtensions.Localize(this.choices[this.currentIndex].Name, (Object) null, (Object) null, (Object) null));
    Action callback = choice.Callback;
    if (callback == null)
      return;
    callback();
  }

  public string GetCurrentChoiceName()
  {
    return this.choices.Count <= 0 ? "" : this.choices[this.currentIndex].Name;
  }

  public int GetCurrentIndex() => this.currentIndex;

  public void SetChoice(int index)
  {
    if (index < 0 || index >= this.choices.Count)
      return;
    this.currentIndex = index;
    this.UpdateDisplay();
  }

  public void SetChoice(string name)
  {
    for (int index = 0; index < this.choices.Count; ++index)
    {
      if (this.choices[index].Name == name)
      {
        this.currentIndex = index;
        this.UpdateDisplay();
        break;
      }
    }
  }

  public class ChoiceOption
  {
    public string Name { get; set; }

    public Action Callback { get; set; }

    public ChoiceOption(string name, Action callback)
    {
      this.Name = name;
      this.Callback = callback;
    }
  }
}
