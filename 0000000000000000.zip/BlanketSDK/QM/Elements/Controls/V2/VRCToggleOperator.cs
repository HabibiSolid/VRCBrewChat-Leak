
using BlanketSDK.Core;
using BlanketSDK.QM.Elements.V2;
using brewchat.hybridxcore.bep.Properties;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.QM.Elements.Controls.V2;

internal class VRCToggleOperator : IQuickMenuElements
{
  public VRCToggleOperator(VRCPanel panel, string name, Action<bool> func, bool state = false)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QM()) || !Object.op_Implicit((Object) IQuickMenuElements.QMElements.QMPanelGroup("Debug")) || !Object.op_Implicit((Object) IQuickMenuElements.QMControls.OperatorToggle()))
      throw new Exception("element has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMControls.OperatorToggle(), panel.container);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.QM_TOGGLE_OPERATOR_{name}";
    MonoBehaviour2PublicSiObSi_tCaOb_t_cBoObUnique component = ((Component) transform).GetComponent<MonoBehaviour2PublicSiObSi_tCaOb_t_cBoObUnique>();
    VRCToggleHandle toggle = component._toggle;
    RadioButton __1 = component._toggleSwitch;
    __1.field_Private_Single_0 = 27.4f;
    __1.field_Private_Single_1 = 95.4124f;
    Toggle.ToggleEvent onValueChanged = ((Toggle) toggle).onValueChanged;
    ((Toggle) toggle).isOn = state;
    ((UnityEvent<bool>) onValueChanged).AddListener(UnityAction<bool>.op_Implicit((Action<bool>) (x =>
    {
      __1.Method_Public_Void_Boolean_PDM_0(x);
      func(x);
    })));
    toggle._controlName = name;
    toggle.field_Private_Boolean_0 = true;
    toggle._sendAnalytics = false;
    TextMeshProUGUIEx title = ((MonoBehaviour1PublicOb_tGa_c_tGa_mOb_sStUnique) component)._title;
    ((TMP_Text) title).text = name;
    ((TMP_Text) title).richText = true;
  }
}
