
using BlanketSDK.Core;
using BlanketSDK.QM.Elements.Modals;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements.Controls;
using VRC.UI.Elements.Tooltips;

#nullable enable
namespace BlanketSDK.QM.Elements.Controls;

internal class VRCToggle : IQuickMenuElements
{
  private VRCToggleHandle Controller;
  private Action<bool> callback;

  public VRCToggle(
    Transform? parent,
    string? name,
    string? tooltip_on,
    string? tooltip_off,
    Action<bool> func,
    [Optional] bool state,
    [Optional] Sprite? sprite_on,
    [Optional] Sprite? sprite_off)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QuickMenu()) | !Object.op_Implicit((Object) IQuickMenuElements.QMControls.Buttons.ToggleButton()))
      throw new Exception("toggle has moved to a different location or index contact: " + Resources.D_Contact);
    if (parent == null)
      parent = IQuickMenuElements.QMFallbacks._Fallback_Dashboard_Group_QM_UI_Buttons();
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMControls.Buttons.ToggleButton(), parent);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.QM_TOGGLE_BUTTON-{name}";
    VRCToggleHandle component1 = ((Component) transform).GetComponent<VRCToggleHandle>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform).GetComponentInChildren<TextMeshProUGUIEx>();
    ImageEx component2 = ((Component) transform.GetChild(2).GetChild(1)).GetComponent<ImageEx>();
    ImageEx component3 = ((Component) transform.GetChild(2).GetChild(0)).GetComponent<ImageEx>();
    UiToggleTooltip component4 = ((Component) transform).GetComponent<UiToggleTooltip>();
    Toggle.ToggleEvent onValueChanged = ((Toggle) component1).onValueChanged;
    ((Toggle) component1).isOn = state;
    UnityAction<bool> unityAction = UnityAction<bool>.op_Implicit(func);
    ((UnityEvent<bool>) onValueChanged).AddListener(unityAction);
    this.callback = func;
    component1._controlName = name;
    this.Controller = component1;
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    ((ToolTip) component4)._localizableString = LocalizableStringExtensions.Localize(tooltip_on, (Object) null, (Object) null, (Object) null);
    ((ToolTip) component4)._alternateLocalizableString = LocalizableStringExtensions.Localize(tooltip_off, (Object) null, (Object) null, (Object) null);
    if (!Object.op_Implicit((Object) sprite_on) | !Object.op_Implicit((Object) sprite_off))
      return;
    ((Image) component2).sprite = sprite_on;
    ((Image) component3).sprite = sprite_off;
  }

  public void SetState(bool state) => ((Toggle) this.Controller).isOn = !state;

  public VRCToggle(
    VRCModalContainer parent,
    string? name,
    string? tooltip_on,
    string? tooltip_off,
    Action<bool> func,
    bool state = false,
    Sprite? sprite_on = null,
    Sprite? sprite_off = null)
    : this(parent._verticallayoutgroup, name, tooltip_on, tooltip_off, func, state, sprite_on, sprite_off)
  {
  }

  public VRCToggle(
    VRCGroupBox parent,
    string? name,
    string? tooltip_on,
    string? tooltip_off,
    Action<bool> func,
    bool state = false,
    Sprite? sprite_on = null,
    Sprite? sprite_off = null)
    : this(parent.container, name, tooltip_on, tooltip_off, func, state, sprite_on, sprite_off)
  {
  }

  public VRCToggle(
    VRCGroupLayout parent,
    string? name,
    string? tooltip_on,
    string? tooltip_off,
    Action<bool> func,
    bool state = false,
    Sprite? sprite_on = null,
    Sprite? sprite_off = null)
    : this(parent.container, name, tooltip_on, tooltip_off, func, state, sprite_on, sprite_off)
  {
  }
}
