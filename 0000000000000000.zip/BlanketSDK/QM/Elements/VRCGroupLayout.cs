
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.QM.Elements;

internal class VRCGroupLayout : IQuickMenuElements
{
  public Transform? container;
  public List<GameObject> gameobjects = new List<GameObject>();

  public VRCGroupLayout(VRCPage page, string name = null, bool isCollapsible = true, bool alwaysVisable = true)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Here()) || !Object.op_Implicit((Object) IQuickMenuElements.QMElements.QMLayoutGroup()))
      throw new Exception("element has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMElements.QMLayoutGroup(), page.box);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(0)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(1)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(2)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(5)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(6)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(7)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(8)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(9)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(10)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(11)).transform).gameObject);
    ((Object) transform).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.QM_GROUPLAYOUT";
    Transform child = transform.GetChild(3);
    Transform _container = transform.GetChild(4);
    _container.DestroyChildren();
    VRCToggleHandle componentInChildren1 = ((Component) child).GetComponentInChildren<VRCToggleHandle>();
    TextMeshProUGUIEx componentInChildren2 = ((Component) child).GetComponentInChildren<TextMeshProUGUIEx>();
    ((TMP_Text) componentInChildren2).text = name;
    ((TMP_Text) componentInChildren2).richText = true;
    ((Toggle) componentInChildren1).isOn = alwaysVisable;
    Toggle.ToggleEvent toggleEvent = ((Toggle) componentInChildren1).onValueChanged = new Toggle.ToggleEvent();
    ((UnityEventBase) toggleEvent).RemoveAllListeners();
    ((UnityEvent<bool>) toggleEvent).AddListener(UnityAction<bool>.op_Implicit((Action<bool>) (x => ((Component) _container).gameObject.SetActive(x))));
    if (name == null)
      Object.DestroyImmediate((Object) ((Component) componentInChildren2).gameObject);
    if (!isCollapsible)
      Object.DestroyImmediate((Object) child, true);
    this.container = _container;
  }
}
