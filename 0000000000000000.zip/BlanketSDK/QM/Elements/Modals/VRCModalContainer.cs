
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem.Collections.Generic;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements;
using VRC.UI.Elements.Controls;
using VRC.UI.Elements.Menus;

#nullable enable
namespace BlanketSDK.QM.Elements.Modals;

internal class VRCModalContainer : IQuickMenuElements
{
  public string Name;
  public Transform? _obj;
  public UIPage ModalLogic;
  public Transform? _verticallayoutgroup;
  public Transform? _rightLayout;

  public VRCModalContainer(string? header, Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QuickMenu()) | !Object.op_Implicit((Object) IQuickMenuElements.QMElements.FourButtons_Modal()))
      throw new Exception("modal or quickmenu has moved to a different location or been altered: " + Resources.D_Contact);
    this._obj = Object.Instantiate<Transform>(IQuickMenuElements.QMElements.FourButtons_Modal(), IQuickMenuElements.QMParent());
    ((Object) this._obj).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.MODAL_CONTAINER-{header}";
    this.Name = "Menu_" + header;
    this.ModalLogic = (UIPage) ((Component) this._obj).GetComponent<QMSafetyPage>();
    ((Behaviour) this.ModalLogic).enabled = false;
    this.ModalLogic.field_Public_String_0 = this.Name;
    this.ModalLogic.field_Private_Boolean_1 = true;
    this.ModalLogic.field_Private_List_1_UIPage_0.Add(this.ModalLogic);
    Dictionary<Behaviour, bool> behaviourBoolean0 = this.ModalLogic.field_Private_Dictionary_2_Behaviour_Boolean_0;
    behaviourBoolean0.Clear();
    behaviourBoolean0.Add((Behaviour) ((Component) this._obj).GetComponent<MenuPanelRect>(), true);
    behaviourBoolean0.Add((Behaviour) ((Component) this._obj).GetComponent<Canvas>(), true);
    behaviourBoolean0.Add((Behaviour) ((Component) this._obj).GetComponent<CanvasGroup>(), true);
    behaviourBoolean0.Add((Behaviour) ((Component) this._obj).GetComponent<GraphicRaycaster>(), true);
    List<RectMask2D> list1RectMask2D0 = this.ModalLogic.field_Private_List_1_RectMask2D_0;
    list1RectMask2D0.Clear();
    list1RectMask2D0.Add((RectMask2D) ((Component) this._obj).GetComponent<VRCRectMask2D>());
    ((Component) this._obj).GetComponent<VRCRectMask2D>().Method_Public_set_Void_Boolean_0(true);
    ((UIMenu) IQuickMenuElements.QM())?.field_Protected_MenuStateController_0.field_Private_Dictionary_2_String_UIPage_0.Add(this.Name, this.ModalLogic);
    Transform child1 = this._obj.GetChild(1).GetChild(0);
    Transform child2 = child1.GetChild(1);
    Transform child3 = child1.GetChild(2);
    TextMeshProUGUIEx componentInChildren = ((Component) child2).GetComponentInChildren<TextMeshProUGUIEx>();
    if (Object.op_Inequality((Object) sprite, (Object) null))
      ((Component) child2.GetChild(0)).gameObject.SetActive(true);
    Transform transform = child3;
    transform.DestroyChildren();
    this._rightLayout = ((Component) transform).transform;
    this._verticallayoutgroup = ((Component) this._obj.GetChild(1).GetChild(2).DestroyChildren()).transform;
    ((TMP_Text) componentInChildren).text = header;
    ((TMP_Text) componentInChildren).richText = true;
    Button.ButtonClickedEvent onClick = ((Button) ((Component) this._obj.GetChild(1).GetChild(3).GetChild(0)).GetComponent<VRCButtonHandle>()).onClick;
  }

  public void Open()
  {
    ((UIMenu) IQuickMenuElements.QM())?.field_Protected_MenuStateController_0.Method_Public_Void_UIPage_UIContext_Boolean_TransitionType_0(this.ModalLogic, (UIContext) null, true, (UIPage.TransitionType) 9058);
  }
}
