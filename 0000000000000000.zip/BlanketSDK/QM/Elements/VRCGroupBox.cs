
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using System;
using TMPro;
using UnityEngine;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.QM.Elements;

[Obsolete("use VRCGroupLayout instead")]
internal class VRCGroupBox : IQuickMenuElements
{
  public Transform? container;

  public VRCGroupBox(VRCPage page, string name = null)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Dashboard()) || !Object.op_Implicit((Object) IQuickMenuElements.QMElements.QMButtonGrp()))
      throw new Exception("element has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMElements.QMButtonGrp(), page.box);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(1)).transform).gameObject);
    Object.Destroy((Object) ((Component) ((Component) transform.GetChild(2)).transform).gameObject);
    ((Object) transform).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.QM_GROUPBOX";
    Transform child1 = transform.GetChild(3);
    if (name == null)
      Object.Destroy((Object) ((Component) ((Component) child1).transform).gameObject);
    Transform child2 = transform.GetChild(4);
    child2.DestroyChildren();
    TextMeshProUGUIEx componentInChildren = ((Component) child1).GetComponentInChildren<TextMeshProUGUIEx>();
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    this.container = child2;
  }
}
