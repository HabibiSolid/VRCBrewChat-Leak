
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using System;
using UnityEngine;
using UnityEngine.UI;

#nullable enable
namespace BlanketSDK.QM.Elements.V2;

internal class VRCPanel : IQuickMenuElements
{
  public Transform obj;
  public Transform container;

  public VRCPanel()
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QM()) || !Object.op_Implicit((Object) IQuickMenuElements.QMElements.QMPanel("Sharing")))
      throw new Exception("panel has moved to a different location or index contact: " + Resources.D_Contact);
    this.obj = Object.Instantiate<Transform>(IQuickMenuElements.QMElements.QMPanel($"{IQuickMenuElements.QUICKMENU_FLAGS.Panels.Sharing}"), IQuickMenuElements.QMElements.QMPanel($"{IQuickMenuElements.QUICKMENU_FLAGS.Panels.Sharing}").parent);
    ((Object) this.obj).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.QM_PANEL";
    VerticalLayoutGroup componentInChildren = ((Component) this.obj).GetComponentInChildren<VerticalLayoutGroup>();
    if (((Component) componentInChildren).transform.childCount != 0)
      ((Component) componentInChildren).transform.DestroyChildren((Func<Transform, bool>) (child => child.GetSiblingIndex() != 0));
    this.container = ((Component) componentInChildren).transform;
  }
}
