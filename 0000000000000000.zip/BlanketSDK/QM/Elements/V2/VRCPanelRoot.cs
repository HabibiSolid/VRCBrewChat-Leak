
using BlanketSDK.Core;
using brewchat.hybridxcore.bep.Properties;
using System;
using UnityEngine;

#nullable enable
namespace BlanketSDK.QM.Elements.V2;

internal class VRCPanelRoot : IQuickMenuElements
{
  public Transform container;

  public VRCPanelRoot()
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QM()) || !Object.op_Implicit((Object) IQuickMenuElements.QMElements.QMPanel("Sharing")))
      throw new Exception("panel has moved to a different location or index contact: " + Resources.D_Contact);
    ((Object) Object.Instantiate<Transform>(IQuickMenuElements.QMElements.QMPanelGroup($"{IQuickMenuElements.QUICKMENU_FLAGS.Panels.Sharing}"), IQuickMenuElements.QMElements.QMPanelGroup($"{IQuickMenuElements.QUICKMENU_FLAGS.Panels.Sharing}").parent)).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.QM_PANEL";
  }
}
