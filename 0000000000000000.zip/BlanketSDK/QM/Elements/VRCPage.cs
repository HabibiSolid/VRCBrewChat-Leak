
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using Brewchat;
using brewchat.hybridxcore.bep.Properties;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Syrup.IMGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI;
using VRC.UI.Elements;
using VRC.UI.Elements.Controls;
using VRC.UI.Elements.Menus;

#nullable enable
namespace BlanketSDK.QM.Elements;

internal class VRCPage : IQuickMenuElements
{
  private Transform? _obj;
  private static UIPage page;
  public string Name;
  public Transform? box;

  public VRCPage(string name, bool isScrollable = true, bool ShowScrollWheel = true)
  {
    if (!Object.op_Implicit((Object) IQuickMenuElements.QMParent()) || !Object.op_Implicit((Object) IQuickMenuElements.QMMenus.QMSubmenus.Menu_DevTools()))
      throw new Exception("element has moved to a different location or index contact: " + Resources.D_Contact);
    this._obj = Object.Instantiate<Transform>(IQuickMenuElements.QMMenus.QMSubmenus.Menu_DevTools(), IQuickMenuElements.QMParent());
    ((Component) this._obj).gameObject.SetActive(false);
    this._obj.SetSiblingIndex(5);
    this.Name = "Menu_" + name;
    ((Object) this._obj).name = this.Name;
    DevMenu component1 = ((Component) this._obj).GetComponent<DevMenu>();
    ((Behaviour) ((Component) this._obj).GetComponent<Canvas>()).enabled = true;
    ((Behaviour) ((Component) this._obj).GetComponent<CanvasGroup>()).enabled = true;
    ((Behaviour) ((Component) this._obj).GetComponent<GraphicRaycaster>()).enabled = true;
    TextMeshProUGUIEx componentInChildren1 = ((Component) this._obj.GetChild(0).GetChild(1)).GetComponentInChildren<TextMeshProUGUIEx>();
    VRCScrollRect component2 = ((Component) this._obj.GetChild(1)).GetComponent<VRCScrollRect>();
    ((TMP_Text) componentInChildren1).text = name;
    ((TMP_Text) componentInChildren1).richText = true;
    VRCPage.page = (UIPage) component1;
    ((Behaviour) VRCPage.page).enabled = true;
    VRCPage.page.field_Private_Boolean_1 = true;
    VRCPage.page.field_Public_String_0 = this.Name;
    VRCPage.page.field_Private_List_1_UIPage_0.Add(VRCPage.page);
    if (Object.op_Inequality((Object) ((UIMenu) IQuickMenuElements.QM())?.field_Protected_MenuStateController_0, (Object) null) && ((UIMenu) IQuickMenuElements.QM())?.field_Protected_MenuStateController_0.field_Public_Il2CppReferenceArray_1_UIPage_0 != null)
    {
      ((UIMenu) IQuickMenuElements.QM())?.field_Protected_MenuStateController_0.field_Private_Dictionary_2_String_UIPage_0.Add(this.Name, VRCPage.page);
      VRC.UI.Elements.QuickMenu quickMenu = IQuickMenuElements.QM();
      List<UIPage> list = quickMenu != null ? ((IEnumerable<UIPage>) ((UIMenu) quickMenu).field_Protected_MenuStateController_0.field_Public_Il2CppReferenceArray_1_UIPage_0).ToList<UIPage>() : (List<UIPage>) null;
      list?.Add(VRCPage.page);
      ((UIMenu) IQuickMenuElements.QM()).field_Protected_MenuStateController_0.field_Public_Il2CppReferenceArray_1_UIPage_0 = Il2CppReferenceArray<UIPage>.op_Implicit(list.ToArray());
      if (Config.Advanced.DebugMode)
      {
        foreach (UIPage uiPage in ((IEnumerable<UIPage>) ((UIMenu) IQuickMenuElements.QM()).field_Protected_MenuStateController_0.field_Public_Il2CppReferenceArray_1_UIPage_0).ToList<UIPage>())
          sconsole.internal_log(uiPage.field_Public_String_0 ?? "");
        sconsole.internal_log(this.Name + " was created");
      }
    }
    VerticalLayoutGroup componentInChildren2 = ((Component) this._obj).GetComponentInChildren<VerticalLayoutGroup>();
    VRCRectMask2D component3 = ((Component) ((Component) componentInChildren2).transform.parent).GetComponent<VRCRectMask2D>();
    ((Behaviour) component3).enabled = true;
    component3.field_Private_Boolean_0 = true;
    ((Component) componentInChildren2).transform.DestroyChildren();
    this.box = ((Component) componentInChildren2).transform;
    if (!isScrollable)
      return;
    GameObject gameObject = ((Component) component2).gameObject;
    gameObject.SetActive(true);
    ((Behaviour) component2).enabled = true;
    component2.field_Public_Boolean_0 = isScrollable;
    Transform child = gameObject.gameObject.transform.FindChild("Scrollbar");
    ((Component) child).gameObject.SetActive(true);
    sconsole.internal_log(((Object) child).name + " was found");
    ((ScrollRect) component2).verticalScrollbar = ((Component) child).GetComponent<Scrollbar>();
    if (ShowScrollWheel)
      return;
    Object.Destroy((Object) ((Component) ((Component) child).gameObject.transform.FindChild("Sliding Area")).gameObject);
    Object.DestroyImmediate((Object) ((Component) child).GetComponent<ImageEx>());
  }

  public void Open()
  {
    ((Component) this._obj).gameObject.SetActive(true);
    ((Behaviour) ((Component) this._obj).GetComponent<Canvas>()).enabled = true;
    ((Behaviour) ((Component) this._obj).GetComponent<CanvasGroup>()).enabled = true;
    ((Behaviour) ((Component) this._obj).GetComponent<GraphicRaycaster>()).enabled = true;
    VRCPage.page.Method_Protected_Void_Boolean_TransitionType_0(true, (UIPage.TransitionType) 9058);
  }

  private void Close()
  {
  }
}
