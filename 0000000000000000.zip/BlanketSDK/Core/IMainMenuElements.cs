
using UnityEngine;

#nullable enable
namespace BlanketSDK.Core;

internal class IMainMenuElements
{
  internal static GameObject MainMenu()
  {
    return ((Component) ((Component) Object.FindObjectOfType<VRC.UI.Elements.MainMenu>()).transform.GetChild(0)).gameObject;
  }

  protected static VRC.UI.Elements.MainMenu? MM() => Object.FindObjectOfType<VRC.UI.Elements.MainMenu>();

  public static Transform MMParent()
  {
    return IMainMenuElements.MainMenu().transform.FindChild(nameof (MMParent));
  }

  public interface MMMenus
  {
    static Transform WingMenu(string position)
    {
      return IMainMenuElements.MainMenu().transform.FindChild($"Wing_{position}/Container/InnerContainer");
    }

    interface MMSubmenus
    {
      static Transform Menu_Setting()
      {
        return ((Component) IMainMenuElements.MMParent()).transform.FindChild("HeaderOffset/Menu_Settings");
      }

      static Transform Menu_WorldInfo()
      {
        return ((Component) IMainMenuElements.MMParent()).transform.FindChild("HeaderOffset/Menu_MM_WorldInformation");
      }

      static Transform Menu_Worlds()
      {
        return ((Component) IMainMenuElements.MMParent()).transform.FindChild("HeaderOffset/Menu_MM_Worlds");
      }

      static Transform MenuUser_Details()
      {
        return ((Component) IMainMenuElements.MMParent()).transform.FindChild("HeaderOffset/Menu_UserDetail");
      }

      static Transform MenuAvatar_AVM()
      {
        return ((Component) IMainMenuElements.MMParent()).transform.FindChild("HeaderOffset/Menu_MM_Avatars_AVM");
      }
    }
  }

  protected interface MMElements
  {
    static Transform WorldRow()
    {
      return ((Component) IMainMenuElements.MMMenus.MMSubmenus.Menu_WorldInfo()).transform.FindChild("Panel_World_Information/Content/Viewport/BodyContainer_World_Details/ScrollRect/Viewport/VerticalLayoutGroup/Actions");
    }

    static Transform ProfileRow()
    {
      return ((Component) IMainMenuElements.MMMenus.MMSubmenus.MenuUser_Details()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup/Row3");
    }

    static Transform CellContainer(string Name)
    {
      return ((Component) IMainMenuElements.MMMenus.MMSubmenus.Menu_Setting()).transform.FindChild("Menu_MM_DynamicSidePanel/Panel_SectionList/ScrollRect_Navigation_Container/ScrollRect_Content/Viewport/VerticalLayoutGroup/" + Name);
    }

    static Transform Panel()
    {
      return ((Component) IMainMenuElements.MMElements.CellContainer("Debug")).transform.FindChild("Debug");
    }
  }

  protected interface MMControls
  {
    static Transform Tab()
    {
      return IMainMenuElements.MainMenu().transform.FindChild("PageButtons/HorizontalLayoutGroup/Launch_Pad_Button_Tab");
    }

    static Transform OperatorRadialSelection()
    {
      return ((Component) IMainMenuElements.MMElements.CellContainer("ComfortAndSafety")).transform.FindChild("Sharing/QM_Settings_Panel/VerticalLayoutGroup/DirectSharingVisibility");
    }

    static Transform OperatorToggle()
    {
      return ((Component) IMainMenuElements.MMElements.CellContainer("Debug")).transform.FindChild("AvatarDebugging/Settings_Panel_1/VerticalLayoutGroup/AvatarDebug");
    }

    interface Buttons
    {
      static Transform SingleButton()
      {
        return ((Component) IMainMenuElements.MMMenus.MMSubmenus.Menu_Setting()).transform.FindChild("Menu_MM_DynamicSidePanel/Panel_SectionList/ScrollRect_Navigation_Container/ScrollRect_Navigation/Viewport/VerticalLayoutGroup/Cell_MM_Debug");
      }

      static Transform WingButton(string position)
      {
        return ((Component) IMainMenuElements.MMMenus.WingMenu(position)).transform.FindChild("WingMenu/ScrollRect/Viewport/VerticalLayoutGroup/Button_Explore");
      }

      static Transform ProfileButton()
      {
        return ((Component) IMainMenuElements.MMMenus.MMSubmenus.MenuUser_Details()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup/Row3/CellGrid_MM_Content/ModBtn");
      }

      static Transform ExpandButton()
      {
        return ((Component) IMainMenuElements.MMParent()).transform.FindChild("Panel_MM_Header/HeaderRight/Button_Settings");
      }

      interface AvatarMenuRelated
      {
        static Transform AvatarButtonSmall()
        {
          return ((Component) IMainMenuElements.MMMenus.MMSubmenus.MenuAvatar_AVM()).transform.FindChild("Dynamic_Content_Container/Viewport/Panel_SelectedAvatar/Avatar_Marketplace_Panel/Avatar_Functions_Container/Favorite_Avatar_Button");
        }

        static Transform AvatarButton()
        {
          return ((Component) IMainMenuElements.MMMenus.MMSubmenus.MenuAvatar_AVM()).transform.FindChild("Dynamic_Content_Container/Viewport/Panel_SelectedAvatar/Avatar_Marketplace_Panel/Avatar_Details_Button");
        }
      }

      interface WorldMenuRelated
      {
        static Transform CellButton()
        {
          return ((Component) IMainMenuElements.MMMenus.MMSubmenus.Menu_Worlds()).transform.Find("Panel_SectionList/ScrollRect_Navigation_Container/ScrollRect_Content/Viewport/Header_MM_H2/RightItemContainer/Button_CellSize");
        }
      }
    }
  }

  internal interface MMFallbacks
  {
    static Transform _Fallback_Dashboard_Group_MM_UI_Buttons_TAB()
    {
      return IMainMenuElements.MainMenu().transform.FindChild("PageButtons/HorizontalLayoutGroup");
    }

    static Transform _Fallback_Dashboard_Group_MM_UI_ExpandButtons()
    {
      return ((Component) IMainMenuElements.MMParent()).transform.FindChild("Panel_MM_Header/HeaderRight");
    }

    static Transform _Fallback_Dashboard_Group_MM_UI_Buttons()
    {
      return ((Component) IMainMenuElements.MMMenus.MMSubmenus.Menu_Setting()).transform.FindChild("Menu_MM_DynamicSidePanel/Panel_SectionList/ScrollRect_Navigation_Container/ScrollRect_Navigation/Viewport/VerticalLayoutGroup");
    }

    static Transform _Fallback_Dashboard_Group_MM_UI_WingButtons(string position)
    {
      return ((Component) IMainMenuElements.MMMenus.WingMenu(position)).transform.FindChild("WingMenu/ScrollRect/Viewport/VerticalLayoutGroup");
    }

    static Transform _Fallback_Dashboard_Group_MM_UI_ProfileButtons()
    {
      return ((Component) IMainMenuElements.MMMenus.MMSubmenus.MenuUser_Details()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup/Row3/CellGrid_MM_Content");
    }

    static Transform _Fallback_Dashboard_Group_MM_UI_ProfileRows()
    {
      return ((Component) IMainMenuElements.MMMenus.MMSubmenus.MenuUser_Details()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup");
    }
  }

  internal interface MENUMENU_FLAGS
  {
    enum Menus
    {
      Here,
      Dashboard,
      DevTools,
      SelectedUser_Local,
      QM_GeneralSettings,
    }

    enum Panels
    {
      Sharing,
      Debug,
      DevTools,
    }
  }
}
