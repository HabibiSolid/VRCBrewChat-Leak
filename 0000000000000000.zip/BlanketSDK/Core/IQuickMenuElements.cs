
using System;
using System.Runtime.InteropServices;
using UnityEngine;

#nullable enable
namespace BlanketSDK.Core;

internal class IQuickMenuElements
{
  internal static GameObject QuickMenu()
  {
    return ((Component) ((Component) Object.FindObjectOfType<VRC.UI.Elements.QuickMenu>()).transform.GetChild(0)).gameObject;
  }

  protected static VRC.UI.Elements.QuickMenu? QM() => Object.FindObjectOfType<VRC.UI.Elements.QuickMenu>();

  public static Transform QMParent()
  {
    return IQuickMenuElements.QuickMenu().transform.FindChild("Container/Window/QMParent");
  }

  public static Transform QMWidgetParent()
  {
    return ((Component) IQuickMenuElements.QMParent().parent).transform.FindChild("Panel_QM_Widget");
  }

  protected interface QMMenus
  {
    static Transform WingMenu(string position)
    {
      return IQuickMenuElements.QuickMenu().transform.FindChild($"Container/Window/Wing_{position}/Container/InnerContainer");
    }

    interface QMSubmenus
    {
      static Transform Menu_Dashboard()
      {
        return ((Component) IQuickMenuElements.QMParent()).transform.FindChild(nameof (Menu_Dashboard));
      }

      static Transform Menu_Here()
      {
        return ((Component) IQuickMenuElements.QMParent()).transform.FindChild(nameof (Menu_Here));
      }

      static Transform Menu_DevTools()
      {
        return ((Component) IQuickMenuElements.QMParent()).transform.FindChild(nameof (Menu_DevTools));
      }

      static Transform SelectedUser_Local()
      {
        return ((Component) IQuickMenuElements.QMParent()).transform.FindChild("Menu_SelectedUser_Local");
      }

      static Transform Menu_QM_GeneralSettings()
      {
        return ((Component) IQuickMenuElements.QMParent()).transform.FindChild(nameof (Menu_QM_GeneralSettings));
      }
    }
  }

  internal interface QMElements
  {
    [Obsolete("QMButtonContainer is not QMButtonGroup")]
    static Transform QMButtonGrp()
    {
      return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Dashboard()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup");
    }

    static Transform QMLayoutGroup()
    {
      return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Here()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup");
    }

    static Transform QMSpace()
    {
      return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Here()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup/Spacer");
    }

    static Transform FourButtons_Modal()
    {
      return ((Component) IQuickMenuElements.QMParent()).transform.FindChild("Modal_QM_ChangeShieldLevel");
    }

    static Transform QMPanelGroup(string MenuName)
    {
      return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_QM_GeneralSettings()).transform.FindChild("Panel_QM_ScrollRect/Viewport/VerticalLayoutGroup/" + MenuName);
    }

    static Transform QMPanel(string name)
    {
      return ((Component) IQuickMenuElements.QMElements.QMPanelGroup(name)).transform.FindChild("QM_Settings_Panel");
    }

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    struct Widgets
    {
      public static Transform QMWidgetHeader()
      {
        return ((Component) IQuickMenuElements.QMWidgetParent()).transform.FindChild("Header_StreamerMode");
      }
    }

    [StructLayout(LayoutKind.Sequential, Size = 1)]
    struct QMPanelElements
    {
      public static Transform QMSeparator()
      {
        return ((Component) IQuickMenuElements.QMElements.QMPanel("Sharing")).transform.FindChild("VerticalLayoutGroup/Separator");
      }
    }

    interface SelectedUser
    {
      static Transform SelectedUser_ButtonContainer()
      {
        return IQuickMenuElements.QMMenus.QMSubmenus.SelectedUser_Local().FindChild("ScrollRect/Viewport/VerticalLayoutGroup/Buttons_UserActions");
      }
    }
  }

  internal interface QMControls
  {
    static Transform Tab()
    {
      return IQuickMenuElements.QuickMenu().transform.FindChild("Container/Window/Page_Buttons_QM/HorizontalLayoutGroup/Page_Settings");
    }

    static Transform OperatorRadialSelection()
    {
      return ((Component) IQuickMenuElements.QMElements.QMPanel("Sharing")).transform.FindChild("VerticalLayoutGroup/DirectSharingVisibility");
    }

    static Transform OperatorToggle()
    {
      return ((Component) IQuickMenuElements.QMElements.QMPanel("Debug")).transform.FindChild("VerticalLayoutGroup/PinFPS&Ping");
    }

    static Transform OperatorButton()
    {
      return ((Component) IQuickMenuElements.QMElements.QMPanel("Debug")).transform.FindChild("VerticalLayoutGroup/DebugButtons");
    }

    interface Buttons
    {
      static Transform SingleButton()
      {
        return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Dashboard()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions/Button_Respawn");
      }

      static Transform ExpandButton()
      {
        return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Dashboard()).transform.FindChild("Header_H1/RightItemContainer/Button_QM_Expand");
      }

      static Transform ToggleButton()
      {
        return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_DevTools()).transform.FindChild("Scrollrect/Viewport/VerticalLayoutGroup/Buttons/Button_Tag");
      }

      static Transform CarouselButton()
      {
        return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.SelectedUser_Local()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup/Buttons_AvatarActions");
      }

      static Transform WingButton(string position)
      {
        return ((Component) IQuickMenuElements.QMMenus.WingMenu(position)).transform.FindChild("WingMenu/ScrollRect/Viewport/VerticalLayoutGroup/Button_Explore");
      }
    }
  }

  internal interface QMFallbacks
  {
    static Transform _Fallback_Dashboard_Group_QM_UI_Buttons_TAB()
    {
      return IQuickMenuElements.QuickMenu().transform.FindChild("Container/Window/Page_Buttons_QM/HorizontalLayoutGroup");
    }

    static Transform _Fallback_Dashboard_Group_QM_UI_ExpandButtons()
    {
      return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Dashboard()).transform.FindChild("Header_H1/RightItemContainer");
    }

    static Transform _Fallback_Dashboard_Group_QM_UI_Buttons()
    {
      return ((Component) IQuickMenuElements.QMMenus.QMSubmenus.Menu_Dashboard()).transform.FindChild("ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickActions");
    }

    static Transform _Fallback_Dashboard_Group_QM_UI_WingButtons(string position)
    {
      return ((Component) IQuickMenuElements.QMMenus.WingMenu(position)).transform.FindChild("WingMenu/ScrollRect/Viewport/VerticalLayoutGroup");
    }

    static Transform _Fallback_Dashboard_Group_QM_UI_ChoiceSelection_Element()
    {
      return IQuickMenuElements.QMMenus.QMSubmenus.Menu_QM_GeneralSettings();
    }
  }

  internal interface QUICKMENU_FLAGS
  {
    enum Menus
    {
      Here,
      Dashboard,
      DevTools,
      SelectedUser_Local,
      QM_GeneralSettings,
    }

    enum Panels
    {
      Sharing,
      Debug,
      DevTools,
    }
  }
}
