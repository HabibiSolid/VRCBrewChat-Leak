
using System.Runtime.InteropServices;
using UnityEngine;

#nullable enable
namespace BlanketSDK.Core;

public class IActionMenuElements
{
  public static Transform[] ActionMenus()
  {
    return new Transform[2]
    {
      GameObject.Find("ActionMenu/Container/MenuR/ActionMenu")?.transform,
      GameObject.Find("ActionMenu/Container/MenuL/ActionMenu")?.transform
    };
  }

  private global::ActionMenu ActionMenu()
  {
    return ((Component) IActionMenuElements.ActionMenus()[0]).GetComponentInChildren<global::ActionMenu>();
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  protected struct AcMenus
  {
    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct AcSubmenus
    {
    }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  protected struct AcControls
  {
    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct Buttons
    {
    }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  protected struct QMElements
  {
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  protected struct QMFallbacks
  {
  }
}
