
using System.Runtime.InteropServices;

#nullable disable
namespace BlanketSDK.Core;

public class VRCOriginElements
{
  [StructLayout(LayoutKind.Sequential, Size = 1)]
  protected struct OMenus
  {
    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct OSubmenus
    {
    }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  protected struct OMControls
  {
    [StructLayout(LayoutKind.Sequential, Size = 1)]
    public struct Buttons
    {
    }
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  protected struct OElements
  {
  }

  [StructLayout(LayoutKind.Sequential, Size = 1)]
  protected struct OFallbacks
  {
  }
}
