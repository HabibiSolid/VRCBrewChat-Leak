
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI;

#nullable enable
namespace BlanketSDK.Core;

public class iVRCAssets
{
  private interface Sprites
  {
    static Sprite? Get(iVRCAssets.Sprites.Sprites _sprites)
    {
      using (IEnumerator<ImageEx> enumerator = Object.FindObjectsOfType<ImageEx>().GetEnumerator())
      {
        if (enumerator.MoveNext())
        {
          ImageEx current = enumerator.Current;
          ((Object) current).name.Contains($"Icon/{_sprites}");
          return ((Image) current).sprite;
        }
      }
      return (Sprite) null;
    }

    enum Sprites
    {
      Rocket,
      Ban,
      Kick,
      People,
    }
  }
}
