
using UnityEngine;
using VRC.UI.Elements;

#nullable enable
namespace BlanketSDK.Utilities;

internal class Templates
{
  public static GameObject[] AdvancedMenus = new GameObject[2]
  {
    ((Component) ((Component) Object.FindObjectOfType<QuickMenu>()).transform.GetChild(0)).gameObject,
    ((Component) ((Component) Object.FindObjectOfType<MainMenu>()).transform.GetChild(0)).gameObject
  };

  protected static GameObject USERINTERFACE()
  {
    return ((Component) Object.FindObjectOfType<UserInterface>()).gameObject;
  }

  protected static Transform ORIGIN_BUTTON()
  {
    return GameObject.Find("MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress/GoButton").transform;
  }

  protected static GameObject ORIGIN_BUTTON_PARENT()
  {
    return GameObject.Find("MenuContent/Popups/LoadingPopup/ProgressPanel/Parent_Loading_Progress");
  }

  protected static GameObject SCREENSPACE_OVERLAY_UNSCALEDUI() => GameObject.Find("UnscaledUI");
}
