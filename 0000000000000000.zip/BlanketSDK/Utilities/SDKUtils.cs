
#nullable disable
namespace BlanketSDK.Utilities;

public static class SDKUtils
{
  public class Wing
  {
    public enum Position
    {
      Left,
      Right,
      Both,
    }
  }
}
