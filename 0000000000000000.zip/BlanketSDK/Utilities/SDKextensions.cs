
using BlanketSDK.QM.Elements;
using BlanketSDK.QM.Elements.Controls;
using BlanketSDK.QM.Elements.Modals;
using System;
using UnityEngine;

#nullable enable
namespace BlanketSDK.Utilities;

internal static class SDKextensions
{
  public static VRCButton AddButton(
    this Transform parent,
    string name,
    string? tooltip,
    Action func,
    Sprite? sprite = null)
  {
    return new VRCButton(parent, name, tooltip, func, Object.op_Implicit((Object) sprite));
  }

  public static VRCButton AddButton(
    this VRCGroupBox group,
    string name,
    string? tooltip,
    Action func,
    Sprite? sprite = null)
  {
    return new VRCButton(group, name, tooltip, func, Object.op_Implicit((Object) sprite));
  }

  public static VRCButton AddButton(
    this VRCGroupLayout group,
    string name,
    string? tooltip,
    Action func,
    bool submenu,
    Sprite? sprite = null)
  {
    return new VRCButton(group, name, tooltip, func, submenu, sprite);
  }

  [Obsolete("I have no clue what i did.")]
  public static VRCToggle AddToggle(
    this Transform? parent,
    string? name,
    string? tooltip_on,
    string? tooltip_off,
    Action<bool> func,
    bool state = false,
    Sprite? sprite_on = null,
    Sprite? sprite_off = null)
  {
    return new VRCToggle(parent, name, tooltip_on, tooltip_off, func, state, sprite_on, sprite_off);
  }

  public static VRCToggle AddToggle(
    this VRCGroupBox group,
    string? name,
    string? tooltip_on,
    string? tooltip_off,
    Action<bool> func,
    bool state = false,
    Sprite? sprite_on = null,
    Sprite? sprite_off = null)
  {
    return new VRCToggle(group, name, tooltip_on, tooltip_off, func, state, sprite_on, sprite_off);
  }

  public static VRCToggle AddToggle(
    this VRCGroupLayout group,
    string? name,
    string? tooltip_on,
    string? tooltip_off,
    Action<bool> func,
    bool state = false,
    Sprite? sprite_on = null,
    Sprite? sprite_off = null)
  {
    return new VRCToggle(group, name, tooltip_on, tooltip_off, func, state, sprite_on, sprite_off);
  }

  public static VRCButton AddButton(
    this VRCModalContainer modal,
    string name,
    string? tooltip,
    Action func,
    Sprite? sprite = null)
  {
    return new VRCButton(modal, name, tooltip, func, sprite);
  }

  public static VRCToggle AddToggle(
    this VRCModalContainer modal,
    string? name,
    string? tooltip_on,
    string? tooltip_off,
    Action<bool> func,
    bool state = false,
    Sprite? sprite_on = null,
    Sprite? sprite_off = null)
  {
    return new VRCToggle(modal, name, tooltip_on, tooltip_off, func, state, sprite_on, sprite_off);
  }

  public static VRCSmallButton AddMiniButton(
    this VRCModalContainer modal,
    string? tooltip,
    Action func,
    Sprite? sprite = null)
  {
    return new VRCSmallButton(modal, tooltip, func, sprite);
  }

  public static VRCButton OpenModal(
    this VRCModalContainer modal,
    string name,
    string? tooltip,
    Sprite? sprite = null)
  {
    return new VRCButton(modal, name, tooltip, new Action(modal.Open), sprite);
  }
}
