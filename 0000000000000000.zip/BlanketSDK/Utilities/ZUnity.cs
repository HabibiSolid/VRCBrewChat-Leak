
using System;
using System.Collections.Generic;
using UnityEngine;

#nullable enable
namespace BlanketSDK.Utilities;

public static class ZUnity
{
  public static Transform DestroyChildren(this Transform transform, Func<Transform, bool> exclude = null)
  {
    for (int index = transform.childCount - 1; index >= 0; --index)
    {
      if (exclude == null || exclude(transform.GetChild(index)))
        Object.DestroyImmediate((Object) ((Component) transform.GetChild(index)).gameObject);
    }
    return transform;
  }

  public static List<GameObject> GetChildren(this Transform transform)
  {
    List<GameObject> children = new List<GameObject>();
    for (int index = 0; index < transform.childCount; ++index)
    {
      GameObject gameObject = ((Component) transform.GetChild(index)).gameObject;
      children.Add(gameObject);
    }
    return children;
  }

  public static Transform DestroyChildren(this GameObject gameObj, Func<Transform, bool> exclude = null)
  {
    return gameObj.transform.DestroyChildren(exclude);
  }
}
