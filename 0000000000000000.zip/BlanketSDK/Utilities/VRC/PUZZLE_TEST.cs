
using BlanketSDK.Core;
using BlanketSDK.QM.Elements.V2;
using UnityEngine;

#nullable enable
namespace BlanketSDK.Utilities.VRC;

internal static class PUZZLE_TEST
{
  public static VRCPanel? AddSeperator(this VRCPanel panel)
  {
    Object.Instantiate<Transform>(IQuickMenuElements.QMElements.QMPanelElements.QMSeparator(), panel.container);
    return panel;
  }

  public static Transform? AddSpacer(this Transform parent)
  {
    Object.Instantiate<Transform>(IQuickMenuElements.QMElements.QMSpace(), parent);
    return parent;
  }
}
