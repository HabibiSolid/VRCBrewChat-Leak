
using BlanketSDK.Core;
using System;
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.Utilities.VRC.QM.Widgets;

internal class VRCWidgets : IQuickMenuElements
{
  public bool state;

  public GameObject _obj { get; set; }

  public TextMeshProUGUIEx header_txt { get; set; }

  public static VRCWidgets Create(
    Sprite? sprite,
    string text,
    [Optional] Action func,
    [Optional] Color color,
    [Optional] float duration)
  {
    Transform transform = Object.Instantiate<Transform>(IQuickMenuElements.QMElements.Widgets.QMWidgetHeader(), IQuickMenuElements.QMElements.Widgets.QMWidgetHeader().parent);
    ((Object) transform).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.QM_WIDGET";
    Transform child1 = transform.GetChild(0);
    Transform child2 = child1.GetChild(1);
    Transform child3 = child1.GetChild(2);
    Transform child4 = child1.GetChild(3);
    ImageEx component = ((Component) child2).GetComponent<ImageEx>();
    TextMeshProUGUIEx componentInChildren1 = ((Component) child3).GetComponentInChildren<TextMeshProUGUIEx>();
    ImageEx componentInChildren2 = ((Component) child3).GetComponentInChildren<ImageEx>();
    VRCButtonHandle componentInChildren3 = ((Component) child4).GetComponentInChildren<VRCButtonHandle>();
    ((Component) child4).GetComponentInChildren<TextMeshProUGUIEx>();
    Button.ButtonClickedEvent onClick = ((Button) componentInChildren3).onClick;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    if (func == null)
      ((Component) componentInChildren3).gameObject.SetActive(false);
    ((TMP_Text) componentInChildren1).text = text;
    ((TMP_Text) componentInChildren1).richText = true;
    if (!Object.op_Implicit((Object) sprite))
      return (VRCWidgets) null;
    Object.op_Implicit((Object) sprite);
    ((Image) componentInChildren2).sprite = sprite;
    if ((double) color.r == 0.0 || (double) color.b == 0.0 || (double) color.g == 0.0 || (double) color.a == 0.0)
      ((Graphic) component).canvasRenderer.SetColor(Color.white);
    ((Graphic) component).canvasRenderer.SetColor(color);
    return new VRCWidgets()
    {
      _obj = ((Component) transform).gameObject,
      header_txt = componentInChildren1
    };
  }

  public void SetState(bool state)
  {
    ((Behaviour) this._obj.GetComponent<LayoutElement>()).enabled = state;
    ((Component) this._obj.transform.GetChild(0)).gameObject.SetActive(state);
  }

  public void SetText(string text, [Optional] TextMeshProUGUIEx? properties)
  {
    ((TMP_Text) this.header_txt).text = text;
    properties = this.header_txt;
  }

  public GameObject GetObject() => this._obj;
}
