
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using System;
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.MM.Elements;

internal class VRCCellContainer : IMainMenuElements
{
  public GameObject Object;
  public Transform? _panelContainer;

  public VRCCellContainer(VRCPage page, string name, [Optional] int priority)
  {
    if (!UnityEngine.Object.op_Implicit((UnityEngine.Object) IMainMenuElements.MMMenus.MMSubmenus.Menu_Setting()) || !UnityEngine.Object.op_Implicit((UnityEngine.Object) IMainMenuElements.MMElements.CellContainer("Debug")))
      throw new Exception("element has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform1 = UnityEngine.Object.Instantiate<Transform>(IMainMenuElements.MMElements.CellContainer("Debug"), page._content_container);
    this.Object = ((Component) transform1).gameObject;
    ((UnityEngine.Object) transform1).name = "Cell_" + name;
    ((Component) transform1).gameObject.SetActive(false);
    transform1.SetSiblingIndex(priority);
    ((Component) transform1).GetComponent<MonoBehaviour2PublicOb_r_cOb_o_s_aOb_l_tUnique>();
    TextMeshProUGUIEx componentInChildren = ((Component) ((Component) transform1).transform.GetChild(0).GetChild(1)).GetComponentInChildren<TextMeshProUGUIEx>();
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    transform1.DestroyChildren((Func<Transform, bool>) (child => child.GetSiblingIndex() != 0));
    Transform transform2 = ((Component) ((Component) ((Component) transform1).transform.GetChild(0).GetChild(2)).GetComponentInChildren<VerticalLayoutGroup>()).transform;
    transform2.DestroyChildren((Func<Transform, bool>) (child => child.GetSiblingIndex() != 0));
    this._panelContainer = transform2;
  }
}
