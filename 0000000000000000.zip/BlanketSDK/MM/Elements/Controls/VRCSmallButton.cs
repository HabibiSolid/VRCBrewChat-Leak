
using BlanketSDK.Core;
using BlanketSDK.QM.Elements.Modals;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.MM.Elements.Controls;

internal class VRCSmallButton : IMainMenuElements
{
  public VRCSmallButton(
    Transform parent,
    string? tooltip,
    int priority,
    Action func,
    Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MainMenu()) | !Object.op_Implicit((Object) IMainMenuElements.MMControls.Buttons.ExpandButton()))
      throw new Exception("button has moved to a different location or index contact: " + Resources.D_Contact);
    if (parent == null)
      parent = IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_ExpandButtons();
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMControls.Buttons.ExpandButton(), parent);
    ((Object) transform).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.MM_SMALL_BUTTON";
    transform.SetSiblingIndex(priority - 1);
    MenuTab component1 = ((Component) transform).GetComponent<MenuTab>();
    ImageEx component2 = ((Component) transform.GetChild(1)).GetComponent<ImageEx>();
    ToolTip component3 = ((Component) transform).GetComponent<ToolTip>();
    ((VRCButtonHandle) component1)._controlName = "SmallButton_" + tooltip;
    Button.ButtonClickedEvent onClick = ((Button) component1).onClick;
    component1.field_Private_MenuStateController_0 = ((UIMenu) IMainMenuElements.MM())?.field_Protected_MenuStateController_0;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    LocalizableString localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    component3._localizableString = localizableString;
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) component2).sprite = sprite;
  }

  public VRCSmallButton(
    VRCModalContainer parent,
    string? tooltip,
    int priority,
    Action func,
    Sprite? sprite = null)
    : this(parent._rightLayout, tooltip, priority, func, sprite)
  {
  }
}
