
using BlanketSDK.Core;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.MM.Elements.Controls;

internal class VRCCellButton : IMainMenuElements
{
  public VRCCellButton(Transform parent, string? name, string? tooltip, Action func, Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MainMenu()) | !Object.op_Implicit((Object) IMainMenuElements.MMControls.Buttons.SingleButton()))
      throw new Exception("button has moved to a different location or index contact: " + Resources.D_Contact);
    if (parent == null)
      parent = IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_Buttons();
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMControls.Buttons.SingleButton(), parent);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.MM_SINGLE_BUTTON-{name}";
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform.GetChild(2)).GetComponentInChildren<TextMeshProUGUIEx>(true);
    ImageEx component2 = ((Component) transform.GetChild(6)).GetComponent<ImageEx>();
    ToolTip component3 = ((Component) transform).GetComponent<ToolTip>();
    component1._controlName = (string) null;
    Button.ButtonClickedEvent onClick = ((Button) component1).onClick;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    LocalizableString localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    component3._localizableString = localizableString;
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) component2).sprite = sprite;
  }

  public VRCCellButton(
    VRCPage page,
    VRCCellContainer Menu,
    string? name,
    string? tooltip,
    Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MainMenu()) | !Object.op_Implicit((Object) IMainMenuElements.MMControls.Buttons.SingleButton()))
      throw new Exception("button has moved to a different location or index contact: " + Resources.D_Contact);
    VRCPage vrcPage = page;
    if (vrcPage.navigation_buttons == null)
      vrcPage.navigation_buttons = IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_Buttons();
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMControls.Buttons.SingleButton(), page.navigation_buttons);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.MM_SINGLE_BUTTON-{name}";
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    CellButtonHandler component2 = ((Component) transform).GetComponent<CellButtonHandler>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform.GetChild(2)).GetComponentInChildren<TextMeshProUGUIEx>(true);
    ImageEx component3 = ((Component) transform.GetChild(6)).GetComponent<ImageEx>();
    ToolTip component4 = ((Component) transform).GetComponent<ToolTip>();
    component1._controlName = ((Object) Menu.Object.gameObject).name;
    if (Menu != null)
      component2._targetObjectToEnable = Menu.Object;
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    LocalizableString localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    component4._localizableString = localizableString;
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) component3).sprite = sprite;
  }
}
