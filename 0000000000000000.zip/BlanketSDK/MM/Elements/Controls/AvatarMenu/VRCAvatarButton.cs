
using BlanketSDK.Core;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using System.Runtime.InteropServices;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.MM.Elements.Controls.AvatarMenu;

internal class VRCAvatarButton : IMainMenuElements
{
  public VRCAvatarButton(string name, string tooltip, Action func, [Optional] Sprite? sprite, [Optional] int priority)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MM()) || !Object.op_Implicit((Object) IMainMenuElements.MMParent()) || !Object.op_Implicit((Object) IMainMenuElements.MMControls.Buttons.AvatarMenuRelated.AvatarButton()))
      throw new Exception("avatar button element has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMControls.Buttons.AvatarMenuRelated.AvatarButton(), IMainMenuElements.MMControls.Buttons.AvatarMenuRelated.AvatarButton().parent);
    ((Object) transform).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.MM_AVATAR_BUTTON";
    transform.SetSiblingIndex(priority);
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    ToolTip component2 = ((Component) transform).GetComponent<ToolTip>();
    Transform child = transform.GetChild(1);
    ImageEx component3 = ((Component) child.GetChild(0)).GetComponent<ImageEx>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform).GetComponentInChildren<TextMeshProUGUIEx>();
    component1._controlName = "BlanketSDK_AvatarButton_" + name;
    Button.ButtonClickedEvent onClick = ((Button) component1).onClick;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    component2._localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    if (!Object.op_Implicit((Object) sprite) || Object.op_Equality((Object) sprite, (Object) null))
      return;
    ((Component) child).gameObject.SetActive(true);
    ((Image) component3).sprite = sprite;
  }
}
