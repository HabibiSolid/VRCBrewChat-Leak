
using BlanketSDK.Core;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.MM.Elements.Controls.AvatarMenu;

internal class VRCAvatarButtonSmall : IMainMenuElements
{
  public VRCAvatarButtonSmall(
    string identifier,
    string tooltip,
    Action func,
    [Optional] Sprite? sprite,
    [Optional] int priority)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MM()) || !Object.op_Implicit((Object) IMainMenuElements.MMParent()) || !Object.op_Implicit((Object) IMainMenuElements.MMControls.Buttons.AvatarMenuRelated.AvatarButtonSmall()))
      throw new Exception("avatar button element has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMControls.Buttons.AvatarMenuRelated.AvatarButtonSmall(), IMainMenuElements.MMControls.Buttons.AvatarMenuRelated.AvatarButtonSmall().parent);
    ((Object) transform).name = Guid.NewGuid().ToString() + "-<Blanket.SDK.MM_AVATAR_BUTTON";
    transform.SetSiblingIndex(priority);
    Object.DestroyImmediate((Object) ((Component) transform).GetComponent<MonoBehaviourPublicLoInLoBoInLoInLoLoLoUnique>());
    Object.DestroyImmediate((Object) ((Component) transform).GetComponent<MonoBehaviourPublicSt_sStObBoStObLoAcObUnique>());
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    ToolTip component2 = ((Component) transform).GetComponent<ToolTip>();
    ImageEx component3 = ((Component) transform.GetChild(1)).GetComponent<ImageEx>();
    component1._controlName = "BlanketSDK_AvatarButton_" + identifier;
    Button.ButtonClickedEvent onClick = ((Button) component1).onClick;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    component2._localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    if (!Object.op_Implicit((Object) sprite) || Object.op_Equality((Object) sprite, (Object) null))
      return;
    ((Image) component3).sprite = sprite;
  }
}
