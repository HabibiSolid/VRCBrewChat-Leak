
using BlanketSDK.Core;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.MM.Elements.Controls;

internal class VRCBigButton : IMainMenuElements
{
  public VRCBigButton(Transform parent, string? name, string? tooltip, Action func = null, Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MainMenu()) || !Object.op_Implicit((Object) IMainMenuElements.MMControls.Buttons.ProfileButton()))
      throw new Exception("profile button has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMControls.Buttons.ProfileButton(), parent);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.MM_SINGLE_BUTTON-{name}";
    VRCButtonHandle component1 = ((Component) transform).GetComponent<VRCButtonHandle>();
    component1._controlName = name;
    TextMeshProUGUIEx component2 = ((Component) transform.GetChild(1)).GetComponent<TextMeshProUGUIEx>();
    ImageEx componentInChildren = ((Component) transform.GetChild(1)).GetComponentInChildren<ImageEx>();
    ToolTip component3 = ((Component) transform).GetComponent<ToolTip>();
    Button.ButtonClickedEvent onClick = ((Button) component1).onClick;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    ((TMP_Text) component2).text = name;
    ((TMP_Text) component2).richText = true;
    LocalizableString localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    component3._localizableString = localizableString;
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) componentInChildren).sprite = sprite;
  }

  public VRCBigButton(
    VRCRowGroup parent,
    string? name,
    string? tooltip,
    Action func = null,
    Sprite? sprite = null)
    : this(parent.container, name, tooltip, func, sprite)
  {
  }
}
