
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using System;
using UnityEngine;

#nullable enable
namespace BlanketSDK.MM.Elements.Controls;

internal class VRCPanel : IMainMenuElements
{
  public static Transform _panel;

  private VRCPanel(VRCCellContainer cell, string name)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MM()) || !Object.op_Implicit((Object) IMainMenuElements.MMElements.CellContainer("Debug")))
      throw new Exception("element has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMElements.Panel(), cell._panelContainer);
    transform.GetChild(0);
    Transform child = transform.GetChild(1);
    child.DestroyChildren();
    VRCPanel._panel = child;
  }
}
