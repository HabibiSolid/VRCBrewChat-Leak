
using BlanketSDK.Core;
using brewchat.hybridxcore.bep.Properties;
using Il2CppSystem;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.Localization;
using VRC.UI;
using VRC.UI.Elements;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.MM.Elements.Controls;

internal class VRCTab : IMainMenuElements
{
  public VRCTab(VRCPage page, string? name, string? tooltip, Action func = null, Sprite? sprite = null)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MainMenu()) | !Object.op_Implicit((Object) IMainMenuElements.MMControls.Tab()))
      throw new Exception("button has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform1 = IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_Buttons_TAB();
    Transform transform2 = Object.Instantiate<Transform>(IMainMenuElements.MMControls.Tab(), transform1);
    ((Object) transform2).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.MM_TAB_BUTTON-{name}";
    MenuTab component1 = ((Component) transform2).GetComponent<MenuTab>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform2).GetComponentInChildren<TextMeshProUGUIEx>();
    ImageEx component2 = ((Component) transform2.GetChild(2)).GetComponent<ImageEx>();
    ToolTip component3 = ((Component) transform2).GetComponent<ToolTip>();
    ((VRCButtonHandle) component1)._controlName = page.Name;
    Button.ButtonClickedEvent onClick = ((Button) component1).onClick;
    component1.field_Private_MenuStateController_0 = ((UIMenu) IMainMenuElements.MM())?.field_Protected_MenuStateController_0;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    LocalizableString localizableString = LocalizableStringExtensions.Localize(tooltip, (Object) null, (Object) null, (Object) null);
    component3._localizableString = localizableString;
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) component2).sprite = sprite;
    ((Image) component2).overrideSprite = sprite;
  }
}
