
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using System;
using TMPro;
using UnityEngine;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.MM.Elements;

internal class VRCRowGroup : IMainMenuElements
{
  public Transform? container;

  public VRCRowGroup(Transform parent, string header, bool alwaysVisable = true)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MainMenu()) || !Object.op_Implicit((Object) IMainMenuElements.MMControls.Buttons.ProfileButton()))
      throw new Exception("profile row element has moved to a different location or index contact: " + Resources.D_Contact);
    if (parent == null)
      parent = IMainMenuElements.MMFallbacks._Fallback_Dashboard_Group_MM_UI_ProfileRows();
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMElements.ProfileRow(), parent);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.MM_PROFILE_ROW_{header}";
    transform.SetSiblingIndex(3);
    Transform child1 = transform.GetChild(0);
    Transform child2 = transform.GetChild(1);
    TextMeshProUGUIEx componentInChildren = ((Component) child1.GetChild(1)).GetComponentInChildren<TextMeshProUGUIEx>();
    ((Component) transform).GetComponent<RectTransform>();
    ((TMP_Text) componentInChildren).text = header;
    ((TMP_Text) componentInChildren).richText = true;
    if (header == null)
      Object.Destroy((Object) ((Component) ((Component) child1).transform).gameObject);
    child2.DestroyChildren();
    this.container = child2;
  }
}
