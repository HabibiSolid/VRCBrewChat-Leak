
using BlanketSDK.Core;
using BlanketSDK.Utilities;
using Brewchat;
using brewchat.hybridxcore.bep.Properties;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Syrup.IMGUI;
using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI;
using VRC.UI.Elements;
using VRC.UI.Elements.Controls;
using VRC.UI.Elements.Menus;

#nullable enable
namespace BlanketSDK.MM.Elements;

internal class VRCPage : IMainMenuElements
{
  public SettingsPage page;
  public string Name;
  public Transform? navigation_buttons;
  public Transform? _content_container;

  public VRCPage(string name, Sprite? sprite)
  {
    if (!Object.op_Implicit((Object) IMainMenuElements.MMParent()) || !Object.op_Implicit((Object) IMainMenuElements.MMMenus.MMSubmenus.Menu_Setting()))
      throw new Exception("element has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(IMainMenuElements.MMMenus.MMSubmenus.Menu_Setting(), IMainMenuElements.MMParent().GetChild(2));
    ((Component) transform).gameObject.SetActive(false);
    transform.SetSiblingIndex(5);
    Transform child1 = transform.GetChild(0).GetChild(0).GetChild(2);
    Transform child2 = child1.FindChild("DynamicSidePanel_Header");
    Transform child3 = child1.FindChild("ScrollRect_Navigation");
    Transform child4 = child1.FindChild("ScrollRect_Content");
    this.Name = "Menu_" + name;
    ((Object) transform).name = this.Name;
    SettingsPage component = ((Component) transform).GetComponent<SettingsPage>();
    ((Behaviour) ((Component) transform).GetComponent<Canvas>()).enabled = true;
    ((Behaviour) ((Component) transform).GetComponent<CanvasGroup>()).enabled = true;
    ((Behaviour) ((Component) transform).GetComponent<GraphicRaycaster>()).enabled = true;
    TextMeshProUGUIEx componentInChildren1 = ((Component) child2).GetComponentInChildren<TextMeshProUGUIEx>();
    ImageEx componentInChildren2 = ((Component) child2).GetComponentInChildren<ImageEx>();
    ((TMP_Text) componentInChildren1).text = name;
    ((TMP_Text) componentInChildren1).richText = true;
    this.page = component;
    ((Behaviour) this.page).enabled = true;
    ((UIPage) this.page).field_Private_Boolean_1 = true;
    ((UIPage) this.page).field_Public_String_0 = this.Name;
    ((UIPage) this.page).field_Private_List_1_UIPage_0.Add((UIPage) this.page);
    if (Object.op_Inequality((Object) ((UIMenu) IMainMenuElements.MM())?.field_Protected_MenuStateController_0, (Object) null) && ((UIMenu) IMainMenuElements.MM())?.field_Protected_MenuStateController_0.field_Public_Il2CppReferenceArray_1_UIPage_0 != null)
    {
      ((UIMenu) IMainMenuElements.MM())?.field_Protected_MenuStateController_0.field_Private_Dictionary_2_String_UIPage_0.Add(this.Name, (UIPage) this.page);
      VRC.UI.Elements.MainMenu mainMenu = IMainMenuElements.MM();
      List<UIPage> list = mainMenu != null ? ((IEnumerable<UIPage>) ((UIMenu) mainMenu).field_Protected_MenuStateController_0.field_Public_Il2CppReferenceArray_1_UIPage_0).ToList<UIPage>() : (List<UIPage>) null;
      list?.Add((UIPage) this.page);
      ((UIMenu) IMainMenuElements.MM()).field_Protected_MenuStateController_0.field_Public_Il2CppReferenceArray_1_UIPage_0 = Il2CppReferenceArray<UIPage>.op_Implicit(list.ToArray());
      if (Config.Advanced.DebugMode)
      {
        foreach (UIPage uiPage in ((IEnumerable<UIPage>) ((UIMenu) IMainMenuElements.MM()).field_Protected_MenuStateController_0.field_Public_Il2CppReferenceArray_1_UIPage_0).ToList<UIPage>())
          sconsole.internal_log(uiPage.field_Public_String_0 ?? "");
        sconsole.internal_log(this.Name + " was created");
      }
    }
    ((Component) child3).GetComponent<VRCScrollRect>().field_Public_Boolean_0 = true;
    VerticalLayoutGroup componentInChildren3 = ((Component) child3).GetComponentInChildren<VerticalLayoutGroup>();
    ((Component) componentInChildren3).transform.DestroyChildren();
    ((Behaviour) ((Component) componentInChildren3).GetComponent<Canvas>()).enabled = true;
    ((Behaviour) ((Component) componentInChildren3).GetComponent<GraphicRaycaster>()).enabled = true;
    ((Component) ((Component) componentInChildren3).transform.parent).GetComponentInChildren<VRCRectMask2D>().field_Private_Boolean_0 = true;
    this.navigation_buttons = ((Component) componentInChildren3).transform;
    ((Component) child4).GetComponent<VRCScrollRect>().field_Public_Boolean_0 = true;
    VerticalLayoutGroup componentInChildren4 = ((Component) child4).GetComponentInChildren<VerticalLayoutGroup>();
    ((Component) componentInChildren4).transform.DestroyChildren();
    ((Component) ((Component) componentInChildren4).transform.parent).GetComponentInChildren<VRCRectMask2D>().field_Private_Boolean_0 = true;
    this._content_container = ((Component) componentInChildren4).transform;
    if (!Object.op_Implicit((Object) sprite))
      return;
    ((Image) componentInChildren2).sprite = sprite;
  }
}
