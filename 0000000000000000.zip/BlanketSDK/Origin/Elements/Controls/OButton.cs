
using BlanketSDK.Utilities;
using brewchat.hybridxcore.bep.Properties;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using VRC.UI.Elements.Controls;

#nullable enable
namespace BlanketSDK.Origin.Elements.Controls;

internal class OButton : Templates
{
  public OButton(Transform parent, float piviot_x, float piviot_y, string? name, Action func)
  {
    if (!Object.op_Implicit((Object) Templates.USERINTERFACE()) | !Object.op_Implicit((Object) Templates.ORIGIN_BUTTON()))
      throw new Exception("button has moved to a different location or index contact: " + Resources.D_Contact);
    Transform transform = Object.Instantiate<Transform>(Templates.ORIGIN_BUTTON(), parent);
    ((Object) transform).name = $"{Guid.NewGuid().ToString()}-<Blanket.SDK.ORIGIN_BUTTON-{name}";
    Button component1 = ((Component) transform).GetComponent<Button>();
    TextMeshProUGUIEx componentInChildren = ((Component) transform).GetComponentInChildren<TextMeshProUGUIEx>();
    RectTransform component2 = ((Component) transform).GetComponent<RectTransform>();
    ((TMP_Text) componentInChildren).text = name;
    ((TMP_Text) componentInChildren).richText = true;
    Button.ButtonClickedEvent onClick = component1.onClick;
    ((UnityEventBase) onClick).RemoveAllListeners();
    ((UnityEvent) onClick).AddListener(UnityAction.op_Implicit(func));
    if ((double) piviot_x == 0.0 || (double) piviot_y == 0.0)
      component2.pivot = new Vector2(0.5f, 0.5f);
    component2.pivot = new Vector2(piviot_x, piviot_y);
  }
}
