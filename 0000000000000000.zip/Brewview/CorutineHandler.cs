
using System.Collections;
using UnityEngine;
using UNIXEngine.IL2CPPModding.Utils.Collections;

#nullable enable
namespace Brewview;

public static class CorutineHandler
{
  public static IEnumerator Start(IEnumerator routine)
  {
    ((MonoBehaviour) VRCUiManager.field_Private_Static_VRCUiManager_0).StartCoroutine(CollectionExtensions.WrapToIl2Cpp(routine));
    return routine;
  }
}
