
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Il2CppSystem;
using Il2CppSystem.IO;
using Il2CppSystem.Runtime.Serialization.Formatters.Binary;
using System;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;

#nullable enable
namespace Pasted.WTFBlaze.Utils.Managers;

public static class SerializationManager
{
  public static byte[] ToByteArray(Object obj)
  {
    if (obj == null)
      return (byte[]) null;
    try
    {
      BinaryFormatter binaryFormatter = new BinaryFormatter();
      MemoryStream memoryStream1 = new MemoryStream();
      MemoryStream memoryStream2 = memoryStream1;
      Object @object = obj;
      binaryFormatter.Serialize((Stream) memoryStream2, @object);
      return Il2CppArrayBase<byte>.op_Implicit((Il2CppArrayBase<byte>) memoryStream1.ToArray());
    }
    catch (Exception ex)
    {
      Entry.Console.LogMessage((object) ex);
      return (byte[]) null;
    }
  }

  [Obsolete("Obsolete")]
  public static byte[] ToByteArray(object obj)
  {
    if (obj == null)
      return (byte[]) null;
    try
    {
      BinaryFormatter binaryFormatter = new BinaryFormatter();
      MemoryStream memoryStream = new MemoryStream();
      MemoryStream serializationStream = memoryStream;
      object graph = obj;
      binaryFormatter.Serialize((Stream) serializationStream, graph);
      return memoryStream.ToArray();
    }
    catch (Exception ex)
    {
      Entry.Console.LogMessage((object) ex);
      return (byte[]) null;
    }
  }

  [Obsolete("Obsolete")]
  public static T FromByteArray<T>(byte[] data)
  {
    if (data == null)
      return default (T);
    try
    {
      using (MemoryStream serializationStream = new MemoryStream(data))
        return (T) new BinaryFormatter().Deserialize((Stream) serializationStream);
    }
    catch (Exception ex)
    {
      Entry.Console.LogMessage((object) ex);
      return default (T);
    }
  }

  public static T IL2CPPFromByteArray<T>(byte[] data)
  {
    if (data == null)
      return default (T);
    try
    {
      return (T) new BinaryFormatter().Deserialize((Stream) new MemoryStream(Il2CppStructArray<byte>.op_Implicit(data)));
    }
    catch (Exception ex)
    {
      Entry.Console.LogMessage((object) ex);
      return default (T);
    }
  }

  public static T FromIL2CPPToManaged<T>(Object obj)
  {
    return SerializationManager.FromByteArray<T>(SerializationManager.ToByteArray(obj));
  }

  public static T FromManagedToIL2CPP<T>(object obj)
  {
    return SerializationManager.IL2CPPFromByteArray<T>(SerializationManager.ToByteArray(obj));
  }

  public static object[] FromIL2CPPArrayToManagedArray(Object[] obj)
  {
    object[] managedArray = new object[obj.Length];
    for (int index = 0; index < obj.Length; ++index)
      managedArray[index] = obj[index].GetIl2CppType().Attributes != 8192 /*0x2000*/ ? (object) obj[index] : SerializationManager.FromIL2CPPToManaged<object>(obj[index]);
    return managedArray;
  }

  public static Object[] FromManagedArrayToIL2CPPArray(object[] obj)
  {
    Object[] il2CppArray = new Object[obj.Length];
    for (int index = 0; index < obj.Length; ++index)
      il2CppArray[index] = obj[index].GetType().Attributes != TypeAttributes.Serializable ? (Object) obj[index] : SerializationManager.FromManagedToIL2CPP<Object>(obj[index]);
    return il2CppArray;
  }
}
